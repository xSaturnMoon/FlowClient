package com.flowclient.compat;

import java.util.Set;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2514;
import net.minecraft.class_2519;
import net.minecraft.class_2520;

public final class NbtCompat {
    private NbtCompat() {}

    public static class_2487 getCompoundOrEmpty(class_2487 tag, String key) {
        return tag.method_10573(key, class_2520.field_33260) ? tag.method_10562(key) : new class_2487();
    }

    public static class_2499 getListOrEmpty(class_2487 tag, String key) {
        return tag.method_10573(key, class_2520.field_33259) ? tag.method_10554(key, class_2520.field_33260) : new class_2499();
    }

    public static class_2499 getListOrEmpty(class_2487 tag, String key, int elementType) {
        return tag.method_10573(key, class_2520.field_33259) ? tag.method_10554(key, elementType) : new class_2499();
    }

    public static class_2487 getCompoundOrEmpty(class_2499 list, int index) {
        if (index < 0 || index >= list.size()) {
            return new class_2487();
        }
        return list.method_10602(index);
    }

    public static int getIntOr(class_2487 tag, String key, int fallback) {
        return tag.method_10573(key, class_2520.field_33263) ? tag.method_10550(key) : fallback;
    }

    public static int getShortOr(class_2487 tag, String key, short fallback) {
        return tag.method_10573(key, class_2520.field_33263) ? tag.method_10568(key) : fallback;
    }

    public static String getStringOr(class_2487 tag, String key, String fallback) {
        return tag.method_10573(key, class_2520.field_33258) ? tag.method_10558(key) : fallback;
    }

    public static int getIntOr(class_2499 list, int index, int fallback) {
        if (index < 0 || index >= list.size()) {
            return fallback;
        }
        class_2520 tag = list.method_10534(index);
        return tag instanceof class_2514 numeric ? numeric.method_10701() : fallback;
    }

    public static Set<String> keySet(class_2487 tag) {
        return tag.method_10541();
    }

    public static int intValue(class_2514 tag) {
        return tag.method_10701();
    }

    public static String stringValue(class_2519 tag) {
        return tag.method_10714();
    }

    public static int[] getIntArrayOrEmpty(class_2487 tag, String key) {
        return tag.method_10573(key, class_2520.field_33261) ? tag.method_10561(key) : new int[0];
    }

    public static byte[] getByteArrayOrEmpty(class_2487 tag, String key) {
        return tag.method_10573(key, class_2520.field_33257) ? tag.method_10547(key) : new byte[0];
    }

    public static long[] getLongArrayOrEmpty(class_2487 tag, String key) {
        return tag.method_10573(key, class_2520.field_33262) ? tag.method_10565(key) : new long[0];
    }
}

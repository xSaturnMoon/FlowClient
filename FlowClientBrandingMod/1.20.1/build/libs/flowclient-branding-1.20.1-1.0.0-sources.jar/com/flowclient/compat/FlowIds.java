package com.flowclient.compat;

import net.minecraft.class_2960;

public final class FlowIds {
    private FlowIds() {}

    public static class_2960 id(String path) {
        return new class_2960("flowclient", path);
    }

    public static class_2960 id(String ns, String path) {
        return new class_2960(ns, path);
    }
}

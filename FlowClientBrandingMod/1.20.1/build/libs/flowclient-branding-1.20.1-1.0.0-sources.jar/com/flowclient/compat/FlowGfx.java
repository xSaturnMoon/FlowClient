package com.flowclient.compat;

import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5481;

public final class FlowGfx {
    private FlowGfx() {}

    public static void fill(class_332 graphics, int x1, int y1, int x2, int y2, int color) {
        graphics.method_25294(x1, y1, x2, y2, color);
    }

    public static void text(class_332 graphics, class_327 font, class_2561 text, int x, int y, int color) {
        graphics.method_51439(font, text, x, y, color, false);
    }

    public static void text(class_332 graphics, class_327 font, class_2561 text, int x, int y, int color, boolean shadow) {
        graphics.method_51439(font, text, x, y, color, shadow);
    }

    public static void text(class_332 graphics, class_327 font, String text, int x, int y, int color) {
        graphics.method_51433(font, text, x, y, color, false);
    }

    public static void text(class_332 graphics, class_327 font, String text, int x, int y, int color, boolean shadow) {
        graphics.method_51433(font, text, x, y, color, shadow);
    }

    public static void text(class_332 graphics, class_327 font, class_5481 text, int x, int y, int color, boolean shadow) {
        graphics.method_51430(font, text, x, y, color, shadow);
    }

    public static void item(class_332 graphics, class_1799 stack, int x, int y) {
        graphics.method_51427(stack, x, y);
    }

    public static void item(class_332 graphics, class_1799 stack, int x, int y, int size) {
        if (size == 16) {
            graphics.method_51427(stack, x, y);
            return;
        }

        float scale = size / 16.0F;
        var pose = graphics.method_51448();
        pose.method_22903();
        pose.method_22904(x, y, 0.0D);
        pose.method_22905(scale, scale, 1.0F);
        graphics.method_51427(stack, 0, 0);
        pose.method_22909();
    }

    public static void centeredText(class_332 graphics, class_327 font, class_2561 text, int x, int y, int color) {
        graphics.method_27534(font, text, x, y, color);
    }

    public static void centeredText(class_332 graphics, class_327 font, String text, int x, int y, int color) {
        graphics.method_25300(font, text, x, y, color);
    }

    public static void blit(
            class_332 graphics,
            class_2960 texture,
            int x,
            int y,
            int width,
            int height,
            float u,
            float v,
            float uSize,
            float vSize
    ) {
        graphics.method_25293(texture, x, y, width, height, (int) (u * width), (int) (v * height), (int) (uSize * width), (int) (vSize * height), width, height);
    }
}

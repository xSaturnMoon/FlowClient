package com.flowclient.compat;

import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import org.joml.Vector3f;
import org.joml.Vector4f;

public final class WorldProjection {
    private WorldProjection() {}

    public static class_243 projectPointToScreen(class_310 client, class_243 worldPos) {
        class_4184 camera = client.field_1773.method_19418();
        class_243 camPos = camera.method_19326();
        Vector3f relative = new Vector3f(
                (float) (worldPos.field_1352 - camPos.field_1352),
                (float) (worldPos.field_1351 - camPos.field_1351),
                (float) (worldPos.field_1350 - camPos.field_1350)
        );

        relative.rotate(camera.method_23767());
        if (relative.z() >= 0.0F) {
            return new class_243(0.0D, 0.0D, -1.0D);
        }

        float fov = client.field_1690.method_41808().method_41753();
        float halfHeight = client.method_22683().method_4507() / 2.0F;
        float scale = halfHeight / (relative.z() * (float) Math.tan(Math.toRadians(fov / 2.0F)));

        float screenX = relative.x() * scale + client.method_22683().method_4480() / 2.0F;
        float screenY = -relative.y() * scale + client.method_22683().method_4507() / 2.0F;

        double ndcX = (screenX / client.method_22683().method_4480()) * 2.0D - 1.0D;
        double ndcY = 1.0D - (screenY / client.method_22683().method_4507()) * 2.0D;
        double depth = -relative.z() / 1000.0D;
        return new class_243(ndcX, ndcY, depth);
    }
}

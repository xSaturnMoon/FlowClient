package com.flowclient.f3;

import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;

public final class F3Fonts {
    public static final class_2960 F3 = new class_2960("flowclient", "f3");
    private static final class_2583 F3_STYLE = class_2583.field_24360.method_27704(F3);

    private F3Fonts() {
    }

    public static class_2561 text(String value) {
        return class_2561.method_43470(value).method_27696(F3_STYLE);
    }

    public static class_2561 text(class_2561 value) {
        return value.method_27661().method_27696(F3_STYLE);
    }
}

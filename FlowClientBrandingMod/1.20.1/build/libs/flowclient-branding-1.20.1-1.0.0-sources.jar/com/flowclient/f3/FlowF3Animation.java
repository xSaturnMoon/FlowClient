package com.flowclient.f3;

import com.flowclient.mods.ModifyF3Mod;
import net.minecraft.class_310;
import net.minecraft.class_3532;

public final class FlowF3Animation {
    public static final int SLIDE_DISTANCE = 56;
    private static final long OPEN_DURATION_MS = 280L;
    private static final long CLOSE_DURATION_MS = 140L;

    private static float linearProgress;
    private static long lastFrameMs;

    private FlowF3Animation() {
    }

    public static void frame(class_310 client) {
        if (!ModifyF3Mod.isEnabled()) {
            linearProgress = 0f;
            lastFrameMs = 0L;
            return;
        }

        long now = System.currentTimeMillis();
        if (lastFrameMs == 0L) {
            lastFrameMs = now;
            return;
        }

        boolean opening = client.field_1690.field_1866;
        long duration = opening ? OPEN_DURATION_MS : CLOSE_DURATION_MS;
        float delta = Math.min((now - lastFrameMs) / (float) duration, 0.25f);
        lastFrameMs = now;

        if (opening) {
            linearProgress = class_3532.method_15363(linearProgress + delta, 0f, 1f);
        } else {
            linearProgress = class_3532.method_15363(linearProgress - delta, 0f, 1f);
        }
    }

    public static boolean shouldRender() {
        return linearProgress > 0f;
    }

    public static float easedProgress() {
        return easeOut(linearProgress);
    }

    private static float easeOut(float progress) {
        float inverse = 1f - progress;
        return 1f - inverse * inverse * inverse;
    }
}

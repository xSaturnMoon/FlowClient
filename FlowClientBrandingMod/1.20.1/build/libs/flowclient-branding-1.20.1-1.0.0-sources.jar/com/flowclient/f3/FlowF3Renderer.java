package com.flowclient.f3;

import com.flowclient.compat.FlowGfx;
import com.flowclient.mixin.ParticleEngineAccessor;
import com.mojang.blaze3d.platform.GLX;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_155;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_3568;
import net.minecraft.class_3965;
import net.minecraft.class_4076;
import net.minecraft.class_638;
import net.minecraft.class_7923;

public final class FlowF3Renderer {
    private static final int MARGIN = 2;
    private static final int LINE_HEIGHT = 9;

    private FlowF3Renderer() {
    }

    public static void render(class_310 client, class_332 graphics) {
        render(client, graphics, client.field_1772);
    }

    public static void render(class_310 client, class_332 graphics, class_327 font) {
        if (!FlowF3Animation.shouldRender()) {
            return;
        }

        int screenWidth = graphics.method_51421();
        float eased = FlowF3Animation.easedProgress();
        int slide = (int) (FlowF3Animation.SLIDE_DISTANCE * (1f - eased));

        renderColumn(font, graphics, buildLeftLines(client), screenWidth, false, -slide);
        renderColumn(font, graphics, buildRightLines(client), screenWidth, true, slide);
    }

    private static void renderColumn(
            class_327 font,
            class_332 graphics,
            List<F3Line> lines,
            int screenWidth,
            boolean rightAlign,
            int offsetX
    ) {
        int y = MARGIN;
        for (F3Line line : lines) {
            if (!line.isBlank()) {
                drawLineBackground(font, graphics, y, line, rightAlign, screenWidth, offsetX);
                drawLine(font, graphics, y, line, rightAlign, screenWidth, offsetX);
            }
            y += LINE_HEIGHT;
        }
    }

    private static void drawLineBackground(
            class_327 font,
            class_332 graphics,
            int y,
            F3Line line,
            boolean rightAlign,
            int screenWidth,
            int offsetX
    ) {
        int textWidth = line.width(font);
        int left;
        int right;
        if (rightAlign) {
            left = screenWidth - MARGIN - textWidth - 1 + offsetX;
            right = screenWidth - MARGIN + 1 + offsetX;
        } else {
            left = MARGIN - 1 + offsetX;
            right = MARGIN + textWidth + 1 + offsetX;
        }

        graphics.method_25294(left, y - 1, right, y + LINE_HEIGHT - 1, FlowF3Colors.LINE_BACKGROUND);
    }

    private static void drawLine(
            class_327 font,
            class_332 graphics,
            int y,
            F3Line line,
            boolean rightAlign,
            int screenWidth,
            int offsetX
    ) {
        int totalWidth = line.width(font);
        int drawX = rightAlign ? screenWidth - MARGIN - totalWidth + offsetX : MARGIN + offsetX;

        for (F3Segment segment : line.segments()) {
            FlowGfx.text(graphics, font, segment.text(), drawX, y, segment.color(), true);
            drawX += font.method_1727(segment.text());
        }
    }

    private static List<F3Line> buildLeftLines(class_310 client) {
        List<F3Line> lines = new ArrayList<>();
        String version = class_155.method_16673().method_48019();

        lines.add(F3Line.labeled("Minecraft ", version, FlowF3Colors.HEADER_LABEL, FlowF3Colors.HEADER_VALUE));
        lines.add(F3Line.labeled("FPS: ", String.valueOf(client.method_47599()), FlowF3Colors.HEADER_LABEL, FlowF3Colors.HEADER_VALUE));
        lines.add(F3Line.labeled("Server: ", resolveServerName(client), FlowF3Colors.HEADER_LABEL, FlowF3Colors.HEADER_VALUE));
        lines.add(F3Line.spacer());

        class_638 level = client.field_1687;
        if (level != null && client.method_1560() != null) {
            var entity = client.method_1560();
            class_2338 blockPos = entity.method_24515();
            class_2350 direction = entity.method_5735();
            class_1923 chunkPos = new class_1923(blockPos);

            lines.add(F3Line.location(
                    "XYZ: ",
                    String.format(
                            Locale.ROOT,
                            "%.3f %.5f %.3f",
                            entity.method_23317(),
                            entity.method_23318(),
                            entity.method_23321()
                    )
            ));
            lines.add(F3Line.location(
                    "Block: ",
                    String.format(
                            Locale.ROOT,
                            "%d %d %d",
                            blockPos.method_10263(),
                            blockPos.method_10264(),
                            blockPos.method_10260()
                    )
            ));
            lines.add(F3Line.location(
                    "Facing: ",
                    String.format(
                            Locale.ROOT,
                            "%s (%.1f / %.1f)",
                            facingLabel(direction),
                            class_3532.method_15393(entity.method_36454()),
                            class_3532.method_15393(entity.method_36455())
                    )
            ));
            lines.add(F3Line.location("World: ", level.method_27983().method_29177().toString()));
            lines.add(F3Line.location(
                    "Chunk: ",
                    String.format(
                            Locale.ROOT,
                            "%d %d %d",
                            chunkPos.field_9181,
                            class_4076.method_18675(blockPos.method_10264()),
                            chunkPos.field_9180
                    )
            ));
            lines.add(F3Line.location(
                    "Section Relative: ",
                    String.format(
                            Locale.ROOT,
                            "%d %d %d",
                            class_4076.method_18684(blockPos.method_10263()),
                            class_4076.method_18684(blockPos.method_10264()),
                            class_4076.method_18684(blockPos.method_10260())
                    )
            ));
            lines.add(F3Line.location("Biome: ", biomeName(level, blockPos)));
            lines.add(F3Line.location("Client Light: ", clientLightValues(level, blockPos)));

            lines.add(F3Line.stat("Entities: ", entityValues(client)));
            lines.add(F3Line.stat("Particles: ", String.valueOf(particleCount(client))));
            lines.add(F3Line.stat("Day: ", String.valueOf(dayCount(level))));
            lines.add(F3Line.stat("Sounds: ", soundsValues(client)));
            lines.add(F3Line.stat("Render Distance: ", String.valueOf(client.field_1690.method_38521())));
            lines.add(F3Line.stat("Simulation Distance: ", String.valueOf(simulationDistance(client))));
        }

        return lines;
    }

    private static List<F3Line> buildRightLines(class_310 client) {
        List<F3Line> lines = new ArrayList<>();
        long usedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        long maxMemory = Runtime.getRuntime().maxMemory();
        int memoryPercent = maxMemory == 0L ? 0 : (int) (usedMemory * 100L / maxMemory);
        long usedMb = usedMemory / (1024L * 1024L);
        long maxMb = maxMemory / (1024L * 1024L);

        var window = client.method_22683();

        lines.add(F3Line.hardware("GPU: ", GLX.getOpenGLVersionString()));
        lines.add(F3Line.hardware("RAM Usage: ", memoryPercent + "%"));
        lines.add(F3Line.solid(usedMb + "/" + maxMb + " MB", FlowF3Colors.HW_VALUE));
        lines.add(F3Line.hardware("Java ", System.getProperty("java.version")));
        lines.add(F3Line.hardware("CPU: ", GLX._getCpuInfo()));
        lines.add(F3Line.hardware(
                "Display: ",
                String.format(
                        Locale.ROOT,
                        "%dx%d",
                        window.method_4489(),
                        window.method_4506()
                )
        ));
        lines.add(F3Line.hardware("OpenGL: ", GLX.getOpenGLVersionString()));
        lines.add(F3Line.spacer());

        appendTargetBlockLines(client, lines);
        return lines;
    }

    private static void appendTargetBlockLines(class_310 client, List<F3Line> lines) {
        class_638 level = client.field_1687;
        class_239 hitResult = client.field_1765;
        if (level == null || !(hitResult instanceof class_3965 blockHit) || blockHit.method_17783() != class_239.class_240.field_1332) {
            return;
        }

        class_2338 pos = blockHit.method_17777();
        class_2680 state = level.method_8320(pos);
        lines.add(F3Line.target(
                "Target Block: ",
                String.format(Locale.ROOT, "%d %d %d", pos.method_10263(), pos.method_10264(), pos.method_10260())
        ));
        lines.add(F3Line.solid(class_7923.field_41175.method_10221(state.method_26204()).toString(), FlowF3Colors.TARGET_VALUE));

        for (class_2769<?> property : state.method_28501()) {
            lines.add(F3Line.target(
                    property.method_11899() + ": ",
                    String.valueOf(state.method_11654(property))
            ));
        }
    }

    private static String clientLightValues(class_638 level, class_2338 blockPos) {
        class_3568 lightEngine = level.method_2935().method_12130();
        int blockLight = level.method_8314(class_1944.field_9282, blockPos);
        int skyLight = level.method_8314(class_1944.field_9284, blockPos);
        int combined = lightEngine.method_22363(blockPos, 0);
        return String.format(Locale.ROOT, "%d (%d sky, %d block)", combined, skyLight, blockLight);
    }

    private static String resolveServerName(class_310 client) {
        if (client.method_1542()) {
            return "Integrated Server";
        }

        if (client.method_1558() != null && client.method_1558().field_3752 != null) {
            return client.method_1558().field_3752;
        }

        return "Unknown";
    }

    private static String facingLabel(class_2350 direction) {
        return switch (direction) {
            case field_11043 -> "North -Z";
            case field_11035 -> "South +Z";
            case field_11034 -> "East +X";
            case field_11039 -> "West -X";
            case field_11036 -> "Up +Y";
            case field_11033 -> "Down -Y";
        };
    }

    private static String biomeName(class_638 level, class_2338 blockPos) {
        return level.method_23753(blockPos)
                .method_40230()
                .map(key -> key.method_29177().toString())
                .orElse("unknown");
    }

    private static String entityValues(class_310 client) {
        if (client.field_1687 == null) {
            return "0/0";
        }

        int rendered = 0;
        for (var ignored : client.field_1687.method_18112()) {
            rendered++;
        }

        return rendered + "/?";
    }

    private static int particleCount(class_310 client) {
        var groups = ((ParticleEngineAccessor) client.field_1713).flowclient$getParticles();
        int total = 0;
        for (var queue : groups.values()) {
            total += queue.size();
        }
        return total;
    }

    private static int dayCount(class_1937 level) {
        return (int) (level.method_8532() / 24000L);
    }

    private static String soundsValues(class_310 client) {
        String debug = client.method_1483().method_20305();
        if (debug.startsWith("Sounds: ")) {
            String payload = debug.substring("Sounds: ".length());
            String[] parts = payload.split(" \\+ ");
            if (parts.length == 2) {
                String[] left = parts[0].split("/");
                String[] right = parts[1].split("/");
                if (left.length == 2 && right.length == 2) {
                    int used = Integer.parseInt(left[0]) + Integer.parseInt(right[0]);
                    int max = Integer.parseInt(left[1]) + Integer.parseInt(right[1]);
                    return used + "/" + max;
                }
            }

            return payload;
        }

        return debug;
    }

    private static int simulationDistance(class_310 client) {
        return client.field_1690.method_38521();
    }

    private record F3Segment(String text, int color) {
    }

    private record F3Line(List<F3Segment> segments) {
        static F3Line solid(String text, int color) {
            return new F3Line(List.of(new F3Segment(text, color)));
        }

        static F3Line labeled(String label, String value, int labelColor, int valueColor) {
            return new F3Line(List.of(
                    new F3Segment(label, labelColor),
                    new F3Segment(value, valueColor)
            ));
        }

        static F3Line location(String label, String value) {
            return labeled(label, value, FlowF3Colors.LOC_LABEL, FlowF3Colors.LOC_VALUE);
        }

        static F3Line stat(String label, String value) {
            return labeled(label, value, FlowF3Colors.STAT_LABEL, FlowF3Colors.STAT_VALUE);
        }

        static F3Line hardware(String label, String value) {
            return labeled(label, value, FlowF3Colors.HW_LABEL, FlowF3Colors.HW_VALUE);
        }

        static F3Line target(String label, String value) {
            return labeled(label, value, FlowF3Colors.TARGET_LABEL, FlowF3Colors.TARGET_VALUE);
        }

        static F3Line spacer() {
            return new F3Line(List.of());
        }

        boolean isBlank() {
            return this.segments.isEmpty();
        }

        int width(class_327 font) {
            int total = 0;
            for (F3Segment segment : this.segments) {
                total += font.method_1727(segment.text());
            }
            return total;
        }
    }
}

package com.flowclient.mixin;

import com.flowclient.mods.otherclient.ClientDetector;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import net.minecraft.class_1071;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1071.class)
public abstract class SkinManagerMixin {
    @ModifyVariable(
            method = "registerSkins(Lcom/mojang/authlib/GameProfile;Lnet/minecraft/client/resources/SkinManager$SkinTextureCallback;Z)V",
            at = @At("HEAD"),
            index = 2
    )
    private class_1071.class_1072 flowclient$wrapSkinCallback(
            class_1071.class_1072 original,
            GameProfile profile
    ) {
        return (MinecraftProfileTexture.Type type, class_2960 location, MinecraftProfileTexture profileTexture) -> {
            original.onSkinTextureAvailable(type, location, profileTexture);
            class_310.method_1551().execute(() -> {
                var connection = class_310.method_1551().method_1562();
                if (connection == null || profile == null) {
                    return;
                }
                class_640 info = connection.method_2871(profile.getId());
                if (info != null) {
                    ClientDetector.inspectTextures(profile.getId(), info);
                }
            });
        };
    }
}

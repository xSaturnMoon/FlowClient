package com.flowclient.mixin;

import com.flowclient.mods.render.BlockAnimationController;
import com.flowclient.mods.render.BlockOverlayMod;
import com.flowclient.mods.render.BlockOverlayRenderer;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class LevelRendererMixin {
    @Inject(method = "renderHitOutline", at = @At("HEAD"), cancellable = true)
    private void flowclient$customBlockOutline(
            class_4587 poseStack,
            class_4588 consumer,
            class_1297 entity,
            double camX,
            double camY,
            double camZ,
            class_2338 pos,
            class_2680 state,
            CallbackInfo ci
    ) {
        if (!BlockOverlayMod.isEnabled()) {
            return;
        }

        ci.cancel();
        BlockOverlayRenderer.render(poseStack, consumer, camX, camY, camZ, pos, state);
    }

    @Inject(method = "renderLevel", at = @At("TAIL"))
    private void flowclient$renderBlockAnimations(
            class_4587 poseStack,
            float partialTick,
            long finishNanoTime,
            boolean renderBlockOutline,
            class_4184 camera,
            class_757 gameRenderer,
            class_765 lightTexture,
            Matrix4f projectionMatrix,
            CallbackInfo ci
    ) {
        BlockAnimationController.render(poseStack, camera, partialTick);
    }
}
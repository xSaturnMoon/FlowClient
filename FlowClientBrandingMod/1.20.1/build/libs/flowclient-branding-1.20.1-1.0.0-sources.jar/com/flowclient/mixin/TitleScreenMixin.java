package com.flowclient.mixin;

import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_442.class)
public abstract class TitleScreenMixin extends class_437 {
    protected TitleScreenMixin(class_2561 title) {
        super(title);
    }
}

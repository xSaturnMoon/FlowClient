package com.flowclient.mixin;

import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_636.class)
public interface MultiPlayerGameModeAccessor {
    @Accessor("destroyProgress")
    float flowclient$getDestroyProgress();

    @Accessor("isDestroying")
    boolean flowclient$isDestroying();
}

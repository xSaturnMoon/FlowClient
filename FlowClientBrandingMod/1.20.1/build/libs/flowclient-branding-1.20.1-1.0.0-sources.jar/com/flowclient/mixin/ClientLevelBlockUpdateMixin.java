package com.flowclient.mixin;

import com.flowclient.mods.render.BlockAnimationController;
import com.flowclient.mods.render.BlockAnimationMod;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_638.class)
public abstract class ClientLevelBlockUpdateMixin {
    @Inject(method = "sendBlockUpdated", at = @At("HEAD"))
    private void flowclient$onBlockUpdated(class_2338 pos, class_2680 oldState, class_2680 newState, int flags, CallbackInfo ci) {
        if (BlockAnimationMod.isEnabled() && (oldState.method_26215() || oldState.method_45474()) && !newState.method_26215() && newState.method_26217() != class_2464.field_11455) {
            BlockAnimationController.onBlockPlaced(pos, newState);
        }
    }
}
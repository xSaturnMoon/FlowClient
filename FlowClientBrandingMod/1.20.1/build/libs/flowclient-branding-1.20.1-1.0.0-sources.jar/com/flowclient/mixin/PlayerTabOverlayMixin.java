package com.flowclient.mixin;

import com.flowclient.mods.otherclient.ClientBadgeHelper;
import com.flowclient.mods.otherclient.OtherClientMod;
import com.flowclient.mods.tab.FlowTabBridge;
import com.flowclient.mods.tab.FlowTabCinematicController;
import com.flowclient.mods.tab.FlowTabMod;
import com.flowclient.mods.tab.FlowTabRenderer;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_355;
import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_355.class)
public abstract class PlayerTabOverlayMixin implements FlowTabBridge {

    @Shadow
    @Final
    private class_310 minecraft;

    @Shadow
    private class_2561 footer;

    @Shadow
    private class_2561 header;

    @Shadow
    protected abstract void renderPingIcon(class_332 graphics, int width, int x, int y, class_640 info);

    @Invoker("getPlayerInfos")
    protected abstract List<class_640> flowclient$getPlayerInfos();

    @Invoker("renderTablistHearts")
    protected abstract void flowclient$renderTablistHearts(
            int x,
            int y,
            int width,
            UUID playerId,
            class_332 graphics,
            int rowIndex
    );

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void flowclient$renderCustomTab(
            class_332 graphics,
            int width,
            class_269 scoreboard,
            class_266 objective,
            CallbackInfo ci
    ) {
        if (!FlowTabMod.isEnabled()) {
            return;
        }

        FlowTabCinematicController.onTabRendered();
        FlowTabRenderer.render(this, graphics, width, scoreboard, objective);
        ci.cancel();
    }

    @Inject(method = "getNameForDisplay", at = @At("RETURN"), cancellable = true)
    private void flowclient$triggerTabDetection(class_640 info, CallbackInfoReturnable<class_2561> cir) {
        if (!OtherClientMod.isEnabled() || info == null) {
            return;
        }

        class_2561 base = cir.getReturnValue() != null
                ? cir.getReturnValue()
                : class_2561.method_43470(info.method_2966().getName());
        cir.setReturnValue(ClientBadgeHelper.createTabListName(info, base));
    }

    @Override
    public class_355 overlay() {
        return (class_355) (Object) this;
    }

    @Override
    public class_310 minecraft() {
        return this.minecraft;
    }

    @Override
    public List<class_640> players() {
        return this.flowclient$getPlayerInfos();
    }

    @Override
    public class_2561 header() {
        return this.header;
    }

    @Override
    public class_2561 footer() {
        return this.footer;
    }

    @Override
    public class_2561 nameForDisplay(class_640 info) {
        return this.overlay().method_1918(info);
    }

    @Override
    public void drawPingIcon(class_332 graphics, int columnWidth, int rowX, int rowY, class_640 info) {
        this.renderPingIcon(graphics, columnWidth, rowX, rowY, info);
    }

    @Override
    public void drawHearts(int x, int y, int columnWidth, UUID playerId, class_332 graphics, int rowIndex) {
        this.flowclient$renderTablistHearts(x, y, columnWidth, playerId, graphics, rowIndex);
    }

    @Override
    public void drawObjectiveScore(
            class_266 objective,
            int x,
            int y,
            int columnWidth,
            class_640 info,
            class_332 graphics
    ) {
        // Scores are rendered directly in FlowTabRenderer using public scoreboard APIs.
    }
}

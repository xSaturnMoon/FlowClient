package com.flowclient.mixin;

import com.flowclient.mods.ModKeybindCategoryFilter;
import org.apache.commons.lang3.ArrayUtils;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.Arrays;
import net.minecraft.class_304;
import net.minecraft.class_459;

@Mixin(class_459.class)
public abstract class KeyBindsListMixin {
    @Redirect(
            method = "<init>(Lnet/minecraft/client/gui/screens/controls/KeyBindsScreen;Lnet/minecraft/client/Minecraft;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lorg/apache/commons/lang3/ArrayUtils;clone([Ljava/lang/Object;)[Ljava/lang/Object;"
            )
    )
    private Object[] flowclient$filterKeyMappingsForDisabledMods(Object[] array) {
        ModKeybindCategoryFilter.logKnownCategoriesOnce();
        class_304[] original = (class_304[]) array;
        return Arrays.stream((class_304[]) ArrayUtils.clone(original))
                .filter(mapping -> !ModKeybindCategoryFilter.shouldHideKeyMapping(mapping))
                .toArray(class_304[]::new);
    }
}

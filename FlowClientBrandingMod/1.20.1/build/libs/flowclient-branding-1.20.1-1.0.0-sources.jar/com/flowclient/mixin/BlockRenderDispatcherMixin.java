package com.flowclient.mixin;

import com.flowclient.mods.render.BlockAnimationController;
import com.flowclient.mods.render.BlockAnimationMod;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import net.minecraft.class_776;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_776.class)
public abstract class BlockRenderDispatcherMixin {
    @Inject(method = "renderBatched", at = @At("HEAD"), cancellable = true)
    private void flowclient$cancelAnimatingBatched(class_2680 state, class_2338 pos, class_1920 level, class_4587 poseStack, class_4588 consumer, boolean checkSides, class_5819 random, CallbackInfo ci) {
        if (BlockAnimationMod.isEnabled() && BlockAnimationController.isAnimating(pos)) {
            ci.cancel();
        }
    }
}
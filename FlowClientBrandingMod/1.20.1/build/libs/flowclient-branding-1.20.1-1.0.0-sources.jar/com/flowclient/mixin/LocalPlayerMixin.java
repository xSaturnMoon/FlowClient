package com.flowclient.mixin;

import com.flowclient.mods.freelook.FreelookController;
import com.flowclient.mods.otherclient.ClientDetector;
import com.flowclient.mods.otherclient.OtherClientMod;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_746.class)
public abstract class LocalPlayerMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void flowclient$freelookLockBody(CallbackInfo ci) {
        FreelookController.maintainBodyOrientation();
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void flowclient$otherClientScan(CallbackInfo ci) {
        if (!OtherClientMod.isEnabled()) return;
        class_746 player = (class_746) (Object) this;
        if (player.field_6012 % 200 != 0) return;
        ClientDetector.scanOnlinePlayers();
    }
}

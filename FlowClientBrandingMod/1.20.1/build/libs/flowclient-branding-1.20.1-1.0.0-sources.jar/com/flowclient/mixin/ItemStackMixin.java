package com.flowclient.mixin;

import com.flowclient.mods.tooltip.ShulkerBoxTooltip;
import com.flowclient.mods.tooltip.ShulkerTooltipHelper;
import com.flowclient.mods.tooltip.ShulkerTooltipMod;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_5632;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1799.class)
public abstract class ItemStackMixin {
    @Inject(method = "getTooltipImage", at = @At("RETURN"), cancellable = true)
    private void flowclient$injectShulkerTooltip(CallbackInfoReturnable<Optional<class_5632>> cir) {
        if (!ShulkerTooltipMod.isEnabled() || cir.getReturnValue().isPresent()) {
            return;
        }

        class_1799 stack = (class_1799) (Object) this;
        if (!ShulkerTooltipHelper.isShulkerBox(stack)) {
            return;
        }

        var contents = ShulkerTooltipHelper.readContents(stack);
        if (contents == null) {
            return;
        }

        cir.setReturnValue(Optional.of(new ShulkerBoxTooltip(contents)));
    }
}

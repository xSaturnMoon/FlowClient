package com.flowclient.mixin.voicechat;

import com.flowclient.mods.voicechat.VoiceChatDisableGuard;
import de.maxhenkel.voicechat.voice.client.RenderEvents;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = RenderEvents.class, remap = false)
public abstract class VoiceChatRenderEventsMixin {
    @Inject(method = "onRenderHUD", at = @At("HEAD"), cancellable = true, remap = false)
    private void flowclient$blockHud(class_332 graphics, float partialTicks, CallbackInfo ci) {
        VoiceChatDisableGuard.cancelVoid(ci);
    }

    @Inject(method = "onRenderName", at = @At("HEAD"), cancellable = true, remap = false)
    private void flowclient$blockNameplate(class_1297 entity, class_2561 component, class_4587 poseStack,
            class_4597 bufferSource, int packedLight, CallbackInfo ci) {
        VoiceChatDisableGuard.cancelVoid(ci);
    }
}

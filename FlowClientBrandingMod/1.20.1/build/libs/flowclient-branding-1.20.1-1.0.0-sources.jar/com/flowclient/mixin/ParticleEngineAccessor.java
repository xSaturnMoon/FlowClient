package com.flowclient.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import java.util.Queue;
import net.minecraft.class_3999;
import net.minecraft.class_702;
import net.minecraft.class_703;

@Mixin(class_702.class)
public interface ParticleEngineAccessor {
    @Accessor("particles")
    Map<class_3999, Queue<class_703>> flowclient$getParticles();
}

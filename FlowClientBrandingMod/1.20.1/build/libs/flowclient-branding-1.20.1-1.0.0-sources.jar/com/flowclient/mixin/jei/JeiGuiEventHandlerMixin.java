package com.flowclient.mixin.jei;

import com.flowclient.mods.jei.JeiDisableGuard;
import mezz.jei.gui.events.GuiEventHandler;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = GuiEventHandler.class, remap = false)
public abstract class JeiGuiEventHandlerMixin {
    @Inject(method = "onDrawBackgroundPost", at = @At("HEAD"), cancellable = true, remap = false)
    private void flowclient$blockBackgroundDraw(class_437 screen, class_332 graphics, CallbackInfo ci) {
        JeiDisableGuard.cancelVoid(ci);
    }

    @Inject(method = "onDrawForeground", at = @At("HEAD"), cancellable = true, remap = false)
    private void flowclient$blockForegroundDraw(class_465<?> screen, class_332 graphics, int mouseX,
            int mouseY, CallbackInfo ci) {
        JeiDisableGuard.cancelVoid(ci);
    }

    @Inject(method = "onDrawScreenPost", at = @At("HEAD"), cancellable = true, remap = false)
    private void flowclient$blockScreenDraw(class_437 screen, class_332 graphics, int mouseX, int mouseY,
            CallbackInfo ci) {
        JeiDisableGuard.cancelVoid(ci);
    }

    @Inject(method = "onClientTick", at = @At("HEAD"), cancellable = true, remap = false)
    private void flowclient$blockClientTick(CallbackInfo ci) {
        JeiDisableGuard.cancelVoid(ci);
    }
}

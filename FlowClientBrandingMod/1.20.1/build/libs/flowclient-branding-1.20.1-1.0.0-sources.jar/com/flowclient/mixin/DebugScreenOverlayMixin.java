package com.flowclient.mixin;

import com.flowclient.mods.ModifyF3Mod;
import net.minecraft.class_332;
import net.minecraft.class_340;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_340.class)
public abstract class DebugScreenOverlayMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void flowclient$skipVanillaF3(class_332 graphics, CallbackInfo ci) {
        if (ModifyF3Mod.isEnabled()) {
            ci.cancel();
        }
    }
}

package com.flowclient.mixin;

import com.flowclient.mods.otherclient.ClientBadgeHelper;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
public abstract class PlayerMixin {

    @Inject(method = "getDisplayName", at = @At("RETURN"), cancellable = true)
    private void flowclient$addClientBadgeToNametag(CallbackInfoReturnable<class_2561> cir) {
        class_1657 self = (class_1657) (Object) this;
        cir.setReturnValue(ClientBadgeHelper.decorateDisplayName(self, cir.getReturnValue()));
    }
}

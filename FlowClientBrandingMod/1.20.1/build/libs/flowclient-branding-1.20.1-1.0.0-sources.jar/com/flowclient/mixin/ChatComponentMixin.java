package com.flowclient.mixin;

import com.flowclient.mods.chat.ChatTweaksMod;
import com.flowclient.mods.chat.ChatTweaksSettings;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_338;

@Mixin(class_338.class)
public abstract class ChatComponentMixin {
    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm");

    @ModifyVariable(
            method = "addMessage(Lnet/minecraft/network/chat/Component;)V",
            at = @At("HEAD"),
            argsOnly = true
    )
    private class_2561 flowclient$prependTimestamp(class_2561 message) {
        if (!ChatTweaksMod.isEnabled() || !ChatTweaksSettings.get().timestamps()) {
            return message;
        }
        return class_2561.method_43470("[" + LocalTime.now().format(TIME_FORMAT) + "] ").method_10852(message);
    }

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/GuiGraphics;fill(IIIII)V"
            )
    )
    private void flowclient$hideChatBackground(class_332 graphics, int x1, int y1, int x2, int y2, int color) {
        if (ChatTweaksMod.isEnabled() && ChatTweaksSettings.get().hideBackground()) {
            return;
        }
        graphics.method_25294(x1, y1, x2, y2, color);
    }
}

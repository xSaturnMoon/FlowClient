package com.flowclient.mixin;

import com.flowclient.modpanel.ModPanelKeys;
import com.flowclient.mods.quiet.FlowQuietController;
import com.flowclient.mods.schematics.AllSchematicsKeys;
import net.minecraft.class_309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public abstract class KeyboardHandlerMixin {
    @Inject(method = "keyPress", at = @At("TAIL"))
    private void flowclient$openModPanelOnRightShift(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        if (action != 0) {
            FlowQuietController.notifyInput();
        }
        if (ModPanelKeys.isOpenKey(key, action)) {
            ModPanelKeys.onRightShiftPressed();
        }
        if (AllSchematicsKeys.isMenuKey(key, scancode, action, modifiers)) {
            AllSchematicsKeys.onMenuKeyPressed();
        }
    }
}

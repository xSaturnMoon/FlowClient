package com.flowclient.mixin;

import com.flowclient.mods.tab.FlowTabCinematicController;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_337;
import net.minecraft.class_338;
import net.minecraft.class_355;
import net.minecraft.class_359;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_329.class, priority = 1100)
public abstract class HudCinematicMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @Shadow
    @Final
    private class_355 tabList;

    @Shadow
    private int screenWidth;

    @Inject(method = "render", at = @At("HEAD"))
    private void flowclient$beginHudFrame(class_332 graphics, float partialTick, CallbackInfo ci) {
        FlowTabCinematicController.beginHudFrame();
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void flowclient$finishCinematicFrame(class_332 graphics, float partialTick, CallbackInfo ci) {
        if (!FlowTabCinematicController.shouldHideHud() || !FlowTabCinematicController.wasTabRenderedThisFrame()) {
            return;
        }

        FlowTabCinematicController.renderCoverOverlay(graphics, this.minecraft);

        if (this.minecraft.field_1687 == null) {
            return;
        }

        class_269 scoreboard = this.minecraft.field_1687.method_8428();
        class_266 objective = scoreboard.method_1189(class_269.field_31886);
        this.tabList.method_1919(graphics, this.screenWidth, scoreboard, objective);
    }

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/components/BossHealthOverlay;render(Lnet/minecraft/client/gui/GuiGraphics;)V"
            )
    )
    private void flowclient$hideBossOverlay(class_337 overlay, class_332 graphics) {
        if (!FlowTabCinematicController.shouldHideHud()) {
            overlay.method_1796(graphics);
        }
    }

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/components/SubtitleOverlay;render(Lnet/minecraft/client/gui/GuiGraphics;)V"
            )
    )
    private void flowclient$hideSubtitles(class_359 overlay, class_332 graphics) {
        if (!FlowTabCinematicController.shouldHideHud()) {
            overlay.method_1957(graphics);
        }
    }

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/components/ChatComponent;render(Lnet/minecraft/client/gui/GuiGraphics;III)V"
            )
    )
    private void flowclient$hideChat(class_338 chat, class_332 graphics, int tickCount, int mouseX, int mouseY) {
        if (!FlowTabCinematicController.shouldHideHud()) {
            chat.method_1805(graphics, tickCount, mouseX, mouseY);
        }
    }

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void flowclient$hideCrosshair(class_332 graphics, CallbackInfo ci) {
        if (FlowTabCinematicController.shouldHideHud()) {
            ci.cancel();
        }
    }

    @Inject(method = "displayScoreboardSidebar", at = @At("HEAD"), cancellable = true)
    private void flowclient$hideScoreboard(class_332 graphics, class_266 objective, CallbackInfo ci) {
        if (FlowTabCinematicController.shouldHideHud()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderEffects", at = @At("HEAD"), cancellable = true)
    private void flowclient$hideEffects(class_332 graphics, CallbackInfo ci) {
        if (FlowTabCinematicController.shouldHideHud()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderHotbar", at = @At("HEAD"), cancellable = true)
    private void flowclient$hideHotbar(float partialTick, class_332 graphics, CallbackInfo ci) {
        if (FlowTabCinematicController.shouldHideHud()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderSelectedItemName", at = @At("HEAD"), cancellable = true)
    private void flowclient$hideSelectedItemName(class_332 graphics, CallbackInfo ci) {
        if (FlowTabCinematicController.shouldHideHud()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderDemoOverlay", at = @At("HEAD"), cancellable = true)
    private void flowclient$hideDemoOverlay(class_332 graphics, CallbackInfo ci) {
        if (FlowTabCinematicController.shouldHideHud()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderPlayerHealth", at = @At("HEAD"), cancellable = true)
    private void flowclient$hidePlayerHealth(class_332 graphics, CallbackInfo ci) {
        if (FlowTabCinematicController.shouldHideHud()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderVehicleHealth", at = @At("HEAD"), cancellable = true)
    private void flowclient$hideVehicleHealth(class_332 graphics, CallbackInfo ci) {
        if (FlowTabCinematicController.shouldHideHud()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderSavingIndicator", at = @At("HEAD"), cancellable = true)
    private void flowclient$hideSavingIndicator(class_332 graphics, CallbackInfo ci) {
        if (FlowTabCinematicController.shouldHideHud()) {
            ci.cancel();
        }
    }
}

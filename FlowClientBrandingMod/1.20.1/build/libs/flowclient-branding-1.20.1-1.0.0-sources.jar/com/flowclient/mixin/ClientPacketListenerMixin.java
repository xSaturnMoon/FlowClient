package com.flowclient.mixin;

import com.flowclient.mods.otherclient.ClientDetector;
import com.flowclient.mods.otherclient.OtherClientMod;
import com.mojang.authlib.GameProfile;
import net.minecraft.class_2703;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public abstract class ClientPacketListenerMixin {

    @Inject(method = "handlePlayerInfoUpdate", at = @At("TAIL"))
    private void flowclient$onPlayerInfoUpdate(class_2703 packet, CallbackInfo ci) {
        if (!OtherClientMod.isEnabled()) return;

        for (class_2703.class_2705 entry : packet.method_46330()) {
            GameProfile profile = entry.comp_1107();
            if (profile == null) continue;
            ClientDetector.inspectProfileTextures(profile.getId(), profile);
        }
    }
}

package com.flowclient.mixin;

import com.flowclient.mods.advancements.AdvancementsUnlockController;
import com.flowclient.mods.advancements.AdvancementsUnlockMod;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_636.class)
public abstract class MultiPlayerGameModeMixin {
    @Inject(method = "destroyBlock", at = @At("RETURN"))
    private void flowclient$trackBlockBreak(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        if (!AdvancementsUnlockMod.isEnabled() || !cir.getReturnValue()) {
            return;
        }
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            return;
        }
        AdvancementsUnlockController.get().onBlockBroken(client.field_1687.method_8320(pos));
    }

    @Inject(method = "useItemOn", at = @At("RETURN"))
    private void flowclient$trackItemUsedOn(CallbackInfoReturnable<net.minecraft.class_1269> cir) {
        if (!AdvancementsUnlockMod.isEnabled()) {
            return;
        }
        if (cir.getReturnValue().method_23665()) {
            AdvancementsUnlockController.get().onItemUsed();
        }
    }
}

package com.flowclient.mixin;

import com.flowclient.mods.immersion.PortalFxController;
import net.minecraft.class_1937;
import net.minecraft.class_2724;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_634;
import com.flowclient.mods.advancements.AdvancementsUnlockController;
import com.flowclient.mods.advancements.AdvancementsUnlockMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public abstract class ClientPacketListenerRespawnMixin {
    @Unique
    private class_5321<class_1937> flowclient$dimensionBeforeRespawn;

    @Inject(method = "handleRespawn", at = @At("HEAD"))
    private void flowclient$captureDimension(class_2724 packet, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            this.flowclient$dimensionBeforeRespawn = client.field_1724.method_37908().method_27983();
        }
    }

    @Inject(method = "handleRespawn", at = @At("TAIL"))
    private void flowclient$trackDimensionChange(class_2724 packet, CallbackInfo ci) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || this.flowclient$dimensionBeforeRespawn == null) {
            return;
        }
        class_5321<class_1937> to = client.field_1724.method_37908().method_27983();
        if (!this.flowclient$dimensionBeforeRespawn.equals(to)) {
            if (AdvancementsUnlockMod.isEnabled()) {
                AdvancementsUnlockController.get().onDimensionChange(this.flowclient$dimensionBeforeRespawn, to);
            }
            PortalFxController.onDimensionChange(this.flowclient$dimensionBeforeRespawn, to);
        }
        this.flowclient$dimensionBeforeRespawn = null;
    }
}

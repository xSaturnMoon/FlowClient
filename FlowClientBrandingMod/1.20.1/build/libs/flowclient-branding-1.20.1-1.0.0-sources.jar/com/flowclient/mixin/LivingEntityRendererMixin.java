package com.flowclient.mixin;

import com.flowclient.mods.NametagMod;
import net.minecraft.class_1309;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_922.class)
public abstract class LivingEntityRendererMixin<T extends class_1309> {
    @Inject(method = "shouldShowName", at = @At("RETURN"), cancellable = true)
    private void flowclient$forcePlayerNametag(T entity, CallbackInfoReturnable<Boolean> cir) {
        if (NametagMod.shouldForceNametag(entity)) {
            cir.setReturnValue(true);
        }
    }
}

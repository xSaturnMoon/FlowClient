package com.flowclient.mixin;

import com.flowclient.mods.tooltip.ClientShulkerTooltip;
import com.flowclient.mods.tooltip.ShulkerBoxTooltip;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5684.class)
public interface ClientTooltipComponentMixin {
    @Inject(
            method = "create(Lnet/minecraft/world/inventory/tooltip/TooltipComponent;)Lnet/minecraft/client/gui/screens/inventory/tooltip/ClientTooltipComponent;",
            at = @At("HEAD"),
            cancellable = true
    )
    private static void flowclient$createShulkerTooltip(
            class_5632 component,
            CallbackInfoReturnable<class_5684> cir
    ) {
        if (component instanceof ShulkerBoxTooltip shulkerTooltip) {
            cir.setReturnValue(new ClientShulkerTooltip(shulkerTooltip.contents()));
        }
    }
}

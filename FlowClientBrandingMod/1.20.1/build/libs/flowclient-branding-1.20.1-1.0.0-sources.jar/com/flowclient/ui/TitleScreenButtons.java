package com.flowclient.ui;

import com.flowclient.mixin.ScreenAccessor;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_442;
import net.minecraft.class_526;

public final class TitleScreenButtons {
    private TitleScreenButtons() {
    }

    public static void replaceSingleplayer(class_442 screen) {
        ScreenAccessor accessor = (ScreenAccessor) screen;

        for (class_364 child : screen.method_25396()) {
            if (!(child instanceof class_4185 button) || !isSingleplayer(button)) {
                continue;
            }

            int width = button.method_25368();
            int height = Math.max(button.method_25364(), FlowSidebarButton.HEIGHT);
            int x = button.method_46426();
            int y = button.method_46427() - (height - button.method_25364()) / 2;

            accessor.flowclient$removeWidget(button);
            accessor.flowclient$addRenderableWidget(new FlowSidebarButton(
                    x,
                    y,
                    width,
                    height,
                    button.method_25369(),
                    () -> class_310.method_1551().method_1507(new class_526(screen))
            ));
            return;
        }
    }

    public static boolean isSingleplayer(class_4185 button) {
        class_2561 message = button.method_25369();
        if (message.method_10851() instanceof class_2588 contents) {
            return "menu.singleplayer".equals(contents.method_11022());
        }
        return false;
    }
}

package com.flowclient.ui;

import com.flowclient.compat.FlowGfx;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

public final class LunarQuestCard extends class_339 {
    private final LunarButton actionButton;

    public LunarQuestCard(int x, int y, int width, int height, Runnable onQuestPress) {
        super(x, y, width, height, class_2561.method_43473());
        this.actionButton = new LunarButton(
                x + 10,
                y + height - 28,
                width - 20,
                20,
                class_2561.method_43470("Complete Quest"),
                null,
                LunarButton.Style.QUEST_ACTION,
                null,
                onQuestPress
        );
    }

    public LunarButton getActionButton() {
        return this.actionButton;
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        UiColors.fillRounded(graphics, this.method_46426(), this.method_46427(), this.field_22758, this.field_22759, 10, UiColors.CARD_BG);
        UiColors.drawRoundedOutline(graphics, this.method_46426(), this.method_46427(), this.field_22758, this.field_22759, 10, 2, UiColors.STORE_BORDER);

        int headX = this.method_46426() + 10;
        int headY = this.method_46427() + 10;
        UiSprites.drawIcon(graphics, UiSprites.IconType.GIFT, headX, headY, 14, UiColors.STORE_TEXT);

        class_327 font = class_310.method_1551().field_1772;
        FlowGfx.text(graphics, font, UiFonts.text("Free Medal Quest"), headX + 18, headY + 2, UiColors.BTN_TEXT);
        UiSprites.drawIcon(graphics, UiSprites.IconType.HELP, this.method_46426() + this.field_22758 - 20, headY + 2, 10, UiColors.TEXT_MUTED);

        int slotW = 44;
        int slotH = 44;
        int slotY = headY + 20;
        int startX = this.method_46426() + 10;
        int gap = 8;

        for (int i = 0; i < 3; i++) {
            int sx = startX + i * (slotW + gap);
            UiColors.fillRounded(graphics, sx, slotY, slotW, slotH, 6, UiColors.CARD_BG_HOVER);

            if (i == 0) {
                UiSprites.drawIcon(graphics, UiSprites.IconType.SHIRT, sx + (slotW - 18) / 2, slotY + (slotH - 18) / 2, 18, UiColors.TEXT_MUTED);
            } else if (i == 1) {
                UiSprites.drawIcon(graphics, UiSprites.IconType.SINGLEPLAYER, sx + (slotW - 18) / 2, slotY + (slotH - 18) / 2, 18, UiColors.STORE_TEXT);
            } else {
                UiSprites.drawIcon(graphics, UiSprites.IconType.GEAR, sx + (slotW - 18) / 2, slotY + (slotH - 18) / 2, 18, UiColors.GOLD_COIN);
            }
        }

        int textY = slotY + slotH + 6;
        FlowGfx.text(graphics, font, UiFonts.text("Earn 1 of 3 cosmetics for a limited time!"), this.method_46426() + 10, textY, UiColors.TEXT_MUTED);

        this.actionButton.method_48579(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    protected void method_47399(class_6382 output) {
        this.method_37021(output);
    }
}

package com.flowclient.ui;

import com.flowclient.compat.FlowGfx;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_6382;

public final class FlowSidebarButton extends class_4264 {
    public static final int HEIGHT = 40;

    private final Runnable onPress;

    public FlowSidebarButton(int x, int y, int width, int height, class_2561 message, Runnable onPress) {
        super(x, y, width, height, message);
        this.onPress = onPress;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        boolean hovered = this.method_25367();
        UiColors.fillRounded(
                graphics,
                this.method_46426(),
                this.method_46427(),
                this.field_22758,
                this.field_22759,
                hovered ? UiColors.SIDEBAR_HOVER : UiColors.SIDEBAR_IDLE
        );

        int textColor = hovered ? UiColors.SIDEBAR_TEXT_HOVER : UiColors.SIDEBAR_TEXT;
        int iconSize = 16;
        int iconX = this.method_46426() + 14;
        int iconY = this.method_46427() + (this.field_22759 - iconSize) / 2;
        UiSprites.blitIcon(graphics, UiSprites.ICON_SINGLEPLAYER, iconX, iconY, iconSize);

        class_327 font = class_310.method_1551().field_1772;
        class_2561 label = UiFonts.text(this.method_25369());
        int textY = this.method_46427() + (this.field_22759 - font.field_2000) / 2;
        FlowGfx.text(graphics, font, label, iconX + iconSize + 10, textY, textColor);
    }

    @Override
    public void method_25306() {
        this.onPress.run();
    }

    @Override
    protected void method_47399(class_6382 output) {
        this.method_37021(output);
    }
}

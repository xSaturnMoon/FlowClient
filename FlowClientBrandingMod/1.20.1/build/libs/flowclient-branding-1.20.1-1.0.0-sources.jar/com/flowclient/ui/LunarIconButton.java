package com.flowclient.ui;

import com.flowclient.compat.FlowArgb;
import com.flowclient.compat.FlowGfx;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_6382;

public final class LunarIconButton extends class_4264 {
    // Single character labels for each icon type
    private static final String[] ICON_CHARS = {
        "\u2302", // HOME: ⌂
        "\u2665", // SHIRT: ♥ (cosmetics)
        "\u2764", // MESSAGE
        "\u0041", // FRIENDS: A (avatar)
        "\u2699", // GEAR: ⚙
        "\u0047", // LANGUAGE: G (globe)
        "\u0041", // ACCESSIBILITY
        "\u2261", // MENU: ≡
        "\u00D7", // CLOSE: ×
        "\u25CE", // COIN
        "\u0054", // SHIRT2
        "\u263D", // MOON
        "\u0048", // HOME2
        "\u2665", // FRIENDS2
        "\u2699", // GEAR2
        "\u25A0", // DEFAULT
    };

    private final UiSprites.IconType iconType;
    private final Runnable onPress;

    public LunarIconButton(int x, int y, int w, int h, UiSprites.IconType iconType, Runnable onPress) {
        super(x, y, w, h, class_2561.method_43473());
        this.iconType = iconType;
        this.onPress = onPress;
    }

    @Override
    protected void method_48579(class_332 g, int mx, int my, float pt) {
        boolean hov = method_25367();

        // Visible background - notably lighter than the dark pill background
        int bg = hov ? FlowArgb.color(255, 60, 70, 95) : FlowArgb.color(200, 35, 42, 58);
        int fg = hov ? FlowArgb.color(255, 255, 255, 255) : FlowArgb.color(220, 180, 195, 215);

        UiColors.fillRounded(g, method_46426(), method_46427(), field_22758, field_22759, 5, bg);

        class_327 font = class_310.method_1551().field_1772;
        String label = getIconChar();
        int lw = font.method_1727(label);
        int lx = method_46426() + (field_22758 - lw) / 2;
        int ly = method_46427() + (field_22759 - font.field_2000) / 2 + 1;
        FlowGfx.text(g, font, label, lx, ly, fg);
    }

    private String getIconChar() {
        return switch (iconType) {
            case HOME -> "\u2302";        // ⌂
            case SHIRT -> "C";
            case SINGLEPLAYER -> "S";
            case MULTIPLAYER -> "M";
            case FRIENDS -> "F";
            case GEAR -> "*";
            case LANGUAGE -> "L";
            case ACCESSIBILITY -> "A";
            case MENU -> "=";
            case CLOSE -> "\u00D7";       // ×
            case COIN -> "$";
            case GLOBE -> "D";
            case STORE_CART -> "B";
            default -> "?";
        };
    }

    @Override public void method_25306() { if (onPress != null) onPress.run(); }
    @Override protected void method_47399(class_6382 o) { method_37021(o); }
}

package com.flowclient.ui;

import com.flowclient.compat.FlowGfx;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;
import com.flowclient.compat.FlowArgb;

public final class LunarBannerCard extends class_339 {
    public LunarBannerCard(int x, int y, int width, int height) {
        super(x, y, width, height, class_2561.method_43473());
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int bgTop = FlowArgb.color(240, 20, 80, 100);
        UiColors.fillRounded(graphics, this.method_46426(), this.method_46427(), this.field_22758, this.field_22759, 8, bgTop);

        class_327 font = class_310.method_1551().field_1772;
        int textX = this.method_46426() + 10;
        int textY = this.method_46427() + 15;
        FlowGfx.text(graphics, font, UiFonts.text("30% OFF"), textX, textY, FlowArgb.color(255, 239, 68, 68));
        FlowGfx.text(graphics, font, UiFonts.text("VAULT SALE"), textX, textY + 12, FlowArgb.color(255, 255, 255, 255));

        int dotW = 20;
        int dotH = 3;
        int gap = 4;
        int totalDotsW = 4 * dotW + 3 * gap;
        int startDotX = this.method_46426() + (this.field_22758 - totalDotsW) / 2;
        int dotY = this.method_46427() + this.field_22759 - 8;

        for (int i = 0; i < 4; i++) {
            int dx = startDotX + i * (dotW + gap);
            int dotColor = (i == 0) ? FlowArgb.color(255, 255, 255, 255) : FlowArgb.color(120, 255, 255, 255);
            graphics.method_25294(dx, dotY, dx + dotW, dotY + dotH, dotColor);
        }
    }

    @Override
    protected void method_47399(class_6382 output) {
        this.method_37021(output);
    }
}

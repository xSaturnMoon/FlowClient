package com.flowclient.ui;

import com.flowclient.compat.FlowArgb;
import com.flowclient.compat.FlowGfx;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4264;
import net.minecraft.class_6382;

public final class LunarButton extends class_4264 {
    public enum Style { DEFAULT, STORE, QUEST_ACTION }

    private final Runnable onPress;
    private final Style style;
    private final String badgeText;

    public LunarButton(int x, int y, int w, int h, class_2561 message, Style style, String badgeText, Runnable onPress) {
        super(x, y, w, h, message);
        this.style = style;
        this.badgeText = badgeText;
        this.onPress = onPress;
    }

    public LunarButton(int x, int y, int w, int h, class_2561 message, Runnable onPress) {
        this(x, y, w, h, message, Style.DEFAULT, null, onPress);
    }

    // Kept for quest card compatibility
    public LunarButton(int x, int y, int w, int h, class_2561 message, UiSprites.IconType ignored, Style style, String badge, Runnable onPress) {
        this(x, y, w, h, message, style, badge, onPress);
    }

    @Override
    protected void method_48579(class_332 g, int mx, int my, float pt) {
        boolean hov = method_25367();
        class_327 font = class_310.method_1551().field_1772;

        int bgColor, textColor, borderColor = 0;
        int radius = 8;

        if (style == Style.STORE) {
            bgColor = hov ? FlowArgb.color(255, 22, 101, 52) : FlowArgb.color(220, 16, 64, 36);
            textColor = FlowArgb.color(255, 74, 222, 128);
            borderColor = FlowArgb.color(255, 34, 197, 94);
        } else if (style == Style.QUEST_ACTION) {
            bgColor = hov ? FlowArgb.color(255, 163, 230, 53) : FlowArgb.color(255, 132, 204, 22);
            textColor = FlowArgb.color(255, 15, 23, 42);
            radius = 6;
        } else {
            bgColor = hov ? FlowArgb.color(255, 45, 52, 70) : FlowArgb.color(220, 22, 26, 36);
            textColor = hov ? FlowArgb.color(255, 255, 255, 255) : FlowArgb.color(255, 200, 208, 220);
        }

        UiColors.fillRounded(g, method_46426(), method_46427(), field_22758, field_22759, radius, bgColor);

        // Left accent line for default buttons
        if (style == Style.DEFAULT) {
            int accent = hov ? FlowArgb.color(255, 99, 163, 255) : FlowArgb.color(180, 66, 120, 200);
            g.method_25294(method_46426(), method_46427() + 4, method_46426() + 2, method_46427() + field_22759 - 4, accent);
        }

        if (borderColor != 0) {
            UiColors.drawRoundedOutline(g, method_46426(), method_46427(), field_22758, field_22759, radius, 1, borderColor);
        }

        class_2561 label = this.method_25369();
        int textW = font.method_27525(label);

        // Badge text
        int badgeW = 0;
        if (badgeText != null) {
            badgeW = font.method_1727(badgeText) + 10;
        }

        int totalW = textW + (badgeW > 0 ? 6 + badgeW : 0);
        int textX = method_46426() + (field_22758 - totalW) / 2;
        int textY = method_46427() + (field_22759 - font.field_2000) / 2 + 1;
        FlowGfx.text(g, font, label, textX, textY, textColor);

        if (badgeText != null) {
            int bx = textX + textW + 6;
            int by = method_46427() + (field_22759 - 13) / 2;
            UiColors.fillRounded(g, bx, by, badgeW, 13, 4, FlowArgb.color(180, 40, 50, 70));
            FlowGfx.text(g, font, badgeText, bx + 5, by + (13 - font.field_2000) / 2 + 1, FlowArgb.color(255, 148, 163, 184));
        }
    }

    @Override public void method_25306() { if (onPress != null) onPress.run(); }
    @Override protected void method_47399(class_6382 o) { method_37021(o); }
}

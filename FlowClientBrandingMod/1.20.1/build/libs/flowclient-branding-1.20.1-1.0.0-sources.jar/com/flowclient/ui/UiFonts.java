package com.flowclient.ui;

import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;

public final class UiFonts {
    public static final class_2960 UI = new class_2960("flowclient", "ui");
    private static final class_2583 UI_STYLE = class_2583.field_24360.method_27704(UI);

    private UiFonts() {
    }

    public static class_2561 text(String value) {
        return class_2561.method_43470(value).method_27696(UI_STYLE);
    }

    public static class_2561 text(class_2561 value) {
        return value.method_27661().method_27696(UI_STYLE);
    }
}

package com.flowclient.ui;

import com.flowclient.compat.FlowGfx;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

public final class LunarAccountWidget extends class_339 {
    public LunarAccountWidget(int x, int y, int width, int height) {
        super(x, y, width, height, class_2561.method_43473());
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        boolean hovered = this.method_25367();

        int bgColor = hovered ? UiColors.CARD_BG_HOVER : UiColors.CARD_BG;
        UiColors.fillRounded(graphics, this.method_46426(), this.method_46427(), this.field_22758, this.field_22759, 8, bgColor);
        UiColors.drawRoundedOutline(graphics, this.method_46426(), this.method_46427(), this.field_22758, this.field_22759, 8, 1, UiColors.CARD_BORDER);

        class_310 mc = class_310.method_1551();
        String username = mc.method_1548() != null ? mc.method_1548().method_1676() : "Player";

        int avatarSize = 16;
        int avatarX = this.method_46426() + 6;
        int avatarY = this.method_46427() + (this.field_22759 - avatarSize) / 2;

        UiSprites.drawIcon(graphics, UiSprites.IconType.SINGLEPLAYER, avatarX, avatarY, avatarSize, UiColors.BTN_TEXT);

        class_327 font = mc.field_1772;
        class_2561 label = UiFonts.text(username);
        int textX = avatarX + avatarSize + 6;
        int textY = this.method_46427() + (this.field_22759 - font.field_2000) / 2 + 1;
        FlowGfx.text(graphics, font, label, textX, textY, UiColors.BTN_TEXT);

        int arrowX = this.method_46426() + this.field_22758 - 12;
        int arrowY = this.method_46427() + this.field_22759 / 2;
        graphics.method_25294(arrowX - 3, arrowY - 1, arrowX + 3, arrowY, UiColors.TEXT_MUTED);
        graphics.method_25294(arrowX - 2, arrowY, arrowX + 2, arrowY + 1, UiColors.TEXT_MUTED);
        graphics.method_25294(arrowX - 1, arrowY + 1, arrowX + 1, arrowY + 2, UiColors.TEXT_MUTED);
    }

    @Override
    protected void method_47399(class_6382 output) {
        this.method_37021(output);
    }
}

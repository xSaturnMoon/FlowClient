package com.flowclient.mods.explosion;

import net.minecraft.class_310;

public final class CrystalBedPreviewRenderer {
    private CrystalBedPreviewRenderer() {
    }

    public static boolean shouldRender() {
        return CrystalBedPreviewMod.isEnabled();
    }

    public static void render(class_310 client) {
    }
}

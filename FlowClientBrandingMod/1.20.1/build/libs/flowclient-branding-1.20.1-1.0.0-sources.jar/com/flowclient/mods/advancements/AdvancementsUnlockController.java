package com.flowclient.mods.advancements;

import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_5321;

/**
 * Client-side advancement unlock is not supported on 1.20.1; this controller is a no-op stub.
 */
public final class AdvancementsUnlockController {
    private static final AdvancementsUnlockController INSTANCE = new AdvancementsUnlockController();

    private AdvancementsUnlockController() {
    }

    public static AdvancementsUnlockController get() {
        return INSTANCE;
    }

    public void reset() {
    }

    public void onBlockBroken(class_2680 state) {
    }

    public void onItemPickup(class_1799 stack) {
    }

    public void onMobKill(class_1297 entity) {
    }

    public void onDeath(class_1282 source) {
    }

    public void onItemCrafted(class_5321<class_1860<?>> recipe) {
    }

    public void onItemUsed() {
    }

    public void onItemConsumed(class_1799 stack) {
    }

    public void onDimensionChange(class_5321<class_1937> from, class_5321<class_1937> to) {
    }

    public void tick(class_310 client) {
    }
}

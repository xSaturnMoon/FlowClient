package com.flowclient.mods.clock;

import com.flowclient.compat.FlowGfx;

import com.flowclient.mods.hud.HudElement;
import com.flowclient.mods.hud.HudLayoutManager;
import com.flowclient.mods.hud.HudRenderHelper;
import java.time.LocalDateTime;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class FlowClockRenderer {
    private FlowClockRenderer() {
    }

    public static int getWidth(class_327 font) {
        return getWidth(font, FlowClockSettings.get());
    }

    public static int getHeight(class_327 font) {
        return getHeight(font, FlowClockSettings.get());
    }

    public static int getWidth(class_327 font, FlowClockSettings settings) {
        return font.method_1727(settings.formatNow()) + settings.paddingX() * 2;
    }

    public static int getHeight(class_327 font, FlowClockSettings settings) {
        return font.field_2000 + settings.paddingY() * 2;
    }

    public static void render(class_310 mc, class_332 graphics, class_327 font) {
        render(mc, graphics, font, false);
    }

    public static void render(class_310 mc, class_332 graphics, class_327 font, boolean preview) {
        if (!preview && !FlowClockMod.isEnabled()) {
            return;
        }

        FlowClockSettings settings = FlowClockSettings.get();
        String text = preview ? settings.formatTime(LocalDateTime.of(2026, 7, 27, 14, 30, 45)) : settings.formatNow();
        int width = font.method_1727(text) + settings.paddingX() * 2;
        int height = font.field_2000 + settings.paddingY() * 2;
        int x = HudLayoutManager.get().resolveX(HudElement.FLOW_CLOCK, width, height);
        int y = HudLayoutManager.get().resolveY(HudElement.FLOW_CLOCK, width, height);
        float scale = HudLayoutManager.get().resolveScale(HudElement.FLOW_CLOCK);
        int color = settings.resolveColor();

        HudRenderHelper.withLayout(graphics, x, y, scale, () -> {
            if (settings.showBackground()) {
                int alpha = (int) (settings.backgroundOpacity() / 100.0f * 255.0f) << 24;
                graphics.method_25294(x, y, x + width, y + height, alpha | 0x08080C);
            }
            FlowGfx.text(graphics, font, text, settings.paddingX() + x, settings.paddingY() + y, color, settings.textShadow());
        });
    }
}

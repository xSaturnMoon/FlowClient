package com.flowclient.mods.schematics.parser;

import com.flowclient.compat.NbtCompat;
import net.minecraft.class_2487;

final class SchematicFormatDetector {
    private SchematicFormatDetector() {}

    static boolean isSpongeFormat(class_2487 root) {
        class_2487 schematic = SchematicNbt.resolveSchematicTag(root);
        if (schematic.method_33133()) {
            return false;
        }

        if (schematic.method_10545("Version")
                || schematic.method_10545("DataVersion")
                || schematic.method_10545("Palette")
                || schematic.method_10545("BlockData")) {
            return true;
        }

        class_2487 blocks = NbtCompat.getCompoundOrEmpty(schematic, "Blocks");
        return !blocks.method_33133() && (blocks.method_10545("Palette") || blocks.method_10545("Data"));
    }

    static boolean isAlphaFormat(class_2487 root) {
        class_2487 schematic = SchematicNbt.resolveSchematicTag(root);
        if (schematic.method_33133() || isSpongeFormat(root)) {
            return false;
        }

        byte[] blocks = NbtCompat.getByteArrayOrEmpty(schematic, "Blocks");
        if (blocks.length > 0) {
            return true;
        }

        return NbtCompat.getIntArrayOrEmpty(schematic, "Blocks").length > 0;
    }
}

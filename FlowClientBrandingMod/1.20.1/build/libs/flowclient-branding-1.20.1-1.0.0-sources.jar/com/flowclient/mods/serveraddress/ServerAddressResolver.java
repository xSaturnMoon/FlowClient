package com.flowclient.mods.serveraddress;

import net.minecraft.class_310;
import net.minecraft.class_642;

public final class ServerAddressResolver {
    private ServerAddressResolver() {
    }

    public static String resolve(class_310 mc, ServerAddressDisplayMode mode) {
        if (mc.method_1542()) {
            return "Singleplayer";
        }

        return switch (mode) {
            case SERVER_NAME -> resolveServerName(mc);
            case BRAND -> resolveBrand(mc);
            case ADDRESS -> resolveAddress(mc);
        };
    }

    private static String resolveServerName(class_310 mc) {
        class_642 server = mc.method_1558();
        if (server != null && server.field_3752 != null && !server.field_3752.isBlank()) {
            return server.field_3752;
        }
        return resolveBrand(mc);
    }

    private static String resolveBrand(class_310 mc) {
        class_642 server = mc.method_1558();
        if (server != null && server.field_3752 != null && !server.field_3752.isBlank()) {
            return server.field_3752;
        }
        return resolveAddress(mc);
    }

    private static String resolveAddress(class_310 mc) {
        class_642 server = mc.method_1558();
        if (server != null && server.field_3761 != null && !server.field_3761.isBlank()) {
            return server.field_3761;
        }
        return "Unknown";
    }
}

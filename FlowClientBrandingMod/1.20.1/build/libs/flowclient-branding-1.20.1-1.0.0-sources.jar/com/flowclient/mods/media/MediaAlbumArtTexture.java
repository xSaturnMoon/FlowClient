package com.flowclient.mods.media;

import com.flowclient.compat.FlowIds;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;

final class MediaAlbumArtTexture {
    private static final int MAX_STORED_SIZE = 64;
    private static final int MAX_GPU_SIZE = 128;

    private String loadedTrackId = "";
    private class_1011 artImage;
    private class_1043 gpuTexture;
    private class_2960 gpuTextureLocation;
    private boolean gpuReady;

    private static final MediaAlbumArtTexture INSTANCE = new MediaAlbumArtTexture();

    private MediaAlbumArtTexture() {
    }

    static MediaAlbumArtTexture get() {
        return INSTANCE;
    }

    class_1011 image() {
        return this.artImage;
    }

    class_2960 gpuTextureLocation() {
        return this.gpuTextureLocation;
    }

    class_1043 gpuTexture() {
        return this.gpuTexture;
    }

    boolean isReady() {
        return this.artImage != null;
    }

    boolean hasGpuTexture() {
        return this.gpuReady && this.gpuTexture != null;
    }

    void update(class_310 minecraft, MediaSessionState state) {
        String trackId = state.trackKey();
        if (trackId.isBlank()) {
            this.clear();
            return;
        }

        if (trackId.equals(this.loadedTrackId) && this.isReady()) {
            return;
        }

        Path artPath = resolveArtPath(state);
        if (artPath == null) {
            this.loadedTrackId = trackId;
            this.clearImage();
            return;
        }

        try (InputStream input = Files.newInputStream(artPath)) {
            class_1011 source = class_1011.method_4309(input);
            class_1011 square = toSquare(source, MAX_STORED_SIZE);
            source.close();
            this.replaceImage(square);
            this.loadedTrackId = trackId;
        } catch (Exception ignored) {
            this.loadedTrackId = trackId;
            this.clearImage();
        }
    }

    void clear() {
        this.loadedTrackId = "";
        this.clearImage();
    }

    private void replaceImage(class_1011 image) {
        this.clearImage();
        this.artImage = image;
        this.syncGpuTexture();
    }

    private void clearImage() {
        if (this.artImage != null) {
            this.artImage.close();
            this.artImage = null;
        }
        this.releaseGpuTexture();
    }

    private void syncGpuTexture() {
        if (this.artImage == null) {
            this.releaseGpuTexture();
            return;
        }

        class_1011 gpuImage = toGpuImage(this.artImage);
        if (this.gpuTexture == null) {
            this.gpuTextureLocation = FlowIds.id("media_album_art");
            this.gpuTexture = new class_1043(gpuImage);
            class_310.method_1551().method_1531().method_4616(this.gpuTextureLocation, this.gpuTexture);
        } else {
            this.gpuTexture.method_4526(gpuImage);
            this.gpuTexture.method_4524();
        }

        this.gpuReady = true;
    }

    private void releaseGpuTexture() {
        this.gpuReady = false;
        if (this.gpuTexture != null) {
            class_310.method_1551().method_1531().method_4615(this.gpuTextureLocation);
            this.gpuTexture.close();
            this.gpuTexture = null;
            this.gpuTextureLocation = null;
        }
    }

    private static class_1011 toGpuImage(class_1011 source) {
        int sourceWidth = source.method_4307();
        int sourceHeight = source.method_4323();
        int targetSize = Math.min(MAX_GPU_SIZE, Math.max(sourceWidth, sourceHeight));
        class_1011 image = new class_1011(targetSize, targetSize, false);

        for (int y = 0; y < targetSize; y++) {
            for (int x = 0; x < targetSize; x++) {
                int sx = (x * sourceWidth) / targetSize;
                int sy = (y * sourceHeight) / targetSize;
                image.method_4305(
                        x,
                        y,
                        source.method_4315(
                                Math.min(sourceWidth - 1, Math.max(0, sx)),
                                Math.min(sourceHeight - 1, Math.max(0, sy))
                        )
                );
            }
        }

        applyCircularMask(image);
        return image;
    }

    private static void applyCircularMask(class_1011 image) {
        int size = image.method_4307();
        float center = (size - 1) / 2.0F;
        float radiusSq = center * center;

        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                float dx = x - center;
                float dy = y - center;
                if (dx * dx + dy * dy > radiusSq) {
                    image.method_4305(x, y, 0);
                }
            }
        }
    }

    private static Path resolveArtPath(MediaSessionState state) {
        if (state.artPath() != null && !state.artPath().isBlank()) {
            Path path = Path.of(state.artPath());
            if (Files.isRegularFile(path)) {
                return path;
            }
        }

        String appData = System.getenv("APPDATA");
        if (appData != null && !appData.isBlank()) {
            Path fallback = Path.of(appData, "FlowLauncher", "bin", "FlowMediaProbe", "current-art.dat");
            if (Files.isRegularFile(fallback)) {
                return fallback;
            }
        }

        return null;
    }

    private static class_1011 toSquare(class_1011 source, int maxSize) {
        int sourceWidth = source.method_4307();
        int sourceHeight = source.method_4323();
        int squareSize = Math.max(sourceWidth, sourceHeight);
        int targetSize = Math.min(maxSize, squareSize);

        class_1011 square = new class_1011(targetSize, targetSize, false);
        for (int y = 0; y < targetSize; y++) {
            for (int x = 0; x < targetSize; x++) {
                int sx = (x * sourceWidth) / targetSize;
                int sy = (y * sourceHeight) / targetSize;
                square.method_4305(x, y, source.method_4315(
                        Math.min(sourceWidth - 1, Math.max(0, sx)),
                        Math.min(sourceHeight - 1, Math.max(0, sy))
                ));
            }
        }

        return square;
    }
}

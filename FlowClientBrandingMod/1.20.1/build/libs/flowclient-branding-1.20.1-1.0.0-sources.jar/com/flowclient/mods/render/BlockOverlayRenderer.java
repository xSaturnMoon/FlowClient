package com.flowclient.mods.render;

import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_761;

public final class BlockOverlayRenderer {
    private BlockOverlayRenderer() {
    }

    public static void render(
            class_4587 poseStack,
            class_4588 consumer,
            double camX,
            double camY,
            double camZ,
            class_2338 pos,
            class_2680 state
    ) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            return;
        }

        class_265 shape = state.method_26218(client.field_1687, pos);
        if (shape.method_1110()) {
            return;
        }

        BlockOverlaySettings settings = BlockOverlaySettings.get();
        int color = settings.resolveLineColorArgb();
        if ((color >>> 24) == 0) {
            return;
        }

        float red = ((color >> 16) & 0xFF) / 255.0F;
        float green = ((color >> 8) & 0xFF) / 255.0F;
        float blue = (color & 0xFF) / 255.0F;
        float alpha = ((color >>> 24) & 0xFF) / 255.0F;

        poseStack.method_22903();
        poseStack.method_22904(pos.method_10263() - camX, pos.method_10264() - camY, pos.method_10260() - camZ);
        class_761.method_22982(poseStack, consumer, shape.method_1107(), red, green, blue, alpha);
        poseStack.method_22909();
    }
}

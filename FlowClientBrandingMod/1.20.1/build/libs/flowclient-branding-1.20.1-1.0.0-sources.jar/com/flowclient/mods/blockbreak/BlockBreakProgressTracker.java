package com.flowclient.mods.blockbreak;

import com.flowclient.mixin.MultiPlayerGameModeAccessor;
import net.minecraft.class_310;
import net.minecraft.class_636;

public final class BlockBreakProgressTracker {
    private BlockBreakProgressTracker() {
    }

    public static float progress(class_310 mc) {
        class_636 gameMode = mc.field_1761;
        if (gameMode == null) {
            return 0.0f;
        }

        MultiPlayerGameModeAccessor accessor = (MultiPlayerGameModeAccessor) gameMode;
        if (!accessor.flowclient$isDestroying()) {
            return 0.0f;
        }

        return Math.max(0.0f, Math.min(1.0f, accessor.flowclient$getDestroyProgress()));
    }
}

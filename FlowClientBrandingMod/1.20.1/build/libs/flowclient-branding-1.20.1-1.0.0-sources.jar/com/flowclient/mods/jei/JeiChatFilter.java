package com.flowclient.mods.jei;

import java.util.Set;
import net.minecraft.class_2561;
import net.minecraft.class_2588;

public final class JeiChatFilter {
    private static final Set<String> SERVER_RECIPE_SYNC_KEYS = Set.of(
            "jei.message.server.recipe.sync.unavailable",
            "jei.message.server.recipe.sync.vanilla",
            "jei.message.server.recipe.sync.jei.missing",
            "jei.message.server.recipe.sync.error"
    );

    private JeiChatFilter() {
    }

    public static boolean isServerRecipeSyncWarning(class_2561 message) {
        String key = getTranslationKey(message);
        return key != null && (SERVER_RECIPE_SYNC_KEYS.contains(key) || key.startsWith("jei.message.server.recipe.sync"));
    }

    public static boolean shouldSuppress(class_2561 message) {
        return JeiDisableGuard.shouldBlock() || isServerRecipeSyncWarning(message);
    }

    public static boolean shouldSuppress(String translationKey) {
        return JeiDisableGuard.shouldBlock()
                || translationKey != null && (SERVER_RECIPE_SYNC_KEYS.contains(translationKey)
                || translationKey.startsWith("jei.message.server.recipe.sync"));
    }

    private static String getTranslationKey(class_2561 message) {
        if (message.method_10851() instanceof class_2588 contents) {
            return contents.method_11022();
        }
        return null;
    }
}

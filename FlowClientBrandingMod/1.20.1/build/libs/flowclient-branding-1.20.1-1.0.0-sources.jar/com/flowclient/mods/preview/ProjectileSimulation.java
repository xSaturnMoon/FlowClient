package com.flowclient.mods.preview;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_746;

public final class ProjectileSimulation {
    private ProjectileSimulation() {
    }

    public static SimulationResult simulate(
            class_1937 level,
            class_746 player,
            class_243 start,
            class_243 velocity,
            double gravity,
            double drag,
            int maxSteps
    ) {
        class_243 position = start;
        List<class_243> points = new ArrayList<>();
        points.add(position);

        for (int step = 0; step < maxSteps; step++) {
            class_243 next = position.method_1019(velocity);
            class_239 hit = level.method_17742(new class_3959(
                    position,
                    next,
                    class_3959.class_3960.field_17558,
                    class_3959.class_242.field_1348,
                    player
            ));
            if (hit.method_17783() != class_239.class_240.field_1333) {
                points.add(hit.method_17784());
                return new SimulationResult(points, hit.method_17784(), true);
            }

            points.add(next);
            position = next;
            velocity = velocity.method_1021(drag).method_1023(0.0D, gravity, 0.0D);
            if (position.field_1351 < level.method_31607() - 16) {
                break;
            }
        }

        return new SimulationResult(points, points.get(points.size() - 1), false);
    }

    public static SimulationResult simulateEnderPearl(class_1937 level, class_746 player) {
        class_243 start = player.method_33571();
        class_243 velocity = player.method_5828(1.0F).method_1021(1.5D);
        return simulate(level, player, start, velocity, 0.03D, 0.99D, 80);
    }

    public record SimulationResult(List<class_243> points, class_243 landing, boolean hitSurface) {
    }
}

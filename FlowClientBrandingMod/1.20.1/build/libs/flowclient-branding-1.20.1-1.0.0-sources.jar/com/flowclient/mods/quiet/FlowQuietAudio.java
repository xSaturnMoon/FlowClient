package com.flowclient.mods.quiet;

import java.util.EnumMap;
import java.util.Map;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_3419;
import net.minecraft.class_7172;

final class FlowQuietAudio {
    private static final Map<class_3419, Double> savedVolumes = new EnumMap<>(class_3419.class);
    private static boolean muted;

    private FlowQuietAudio() {
    }

    static void mute(class_310 client) {
        if (!FlowQuietSettings.get().isMuteAudio() || muted) {
            return;
        }

        muted = true;
        class_315 options = client.field_1690;
        savedVolumes.clear();

        for (class_3419 source : class_3419.values()) {
            class_7172<Double> volumeOption = options.method_45578(source);
            savedVolumes.put(source, volumeOption.method_41753());
            volumeOption.method_41748(0.0);
        }

        client.method_1483().method_4881();
        client.method_1538().method_4859();
    }

    static void unmute(class_310 client) {
        if (!muted) {
            return;
        }

        muted = false;
        class_315 options = client.field_1690;
        for (Map.Entry<class_3419, Double> entry : savedVolumes.entrySet()) {
            options.method_45578(entry.getKey()).method_41748(entry.getValue());
        }
        savedVolumes.clear();
    }

    static void forceUnmute(class_310 client) {
        if (client == null) {
            muted = false;
            savedVolumes.clear();
            return;
        }
        unmute(client);
    }
}

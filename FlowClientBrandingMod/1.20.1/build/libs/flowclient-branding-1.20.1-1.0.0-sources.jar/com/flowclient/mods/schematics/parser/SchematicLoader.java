package com.flowclient.mods.schematics.parser;

import com.flowclient.compat.NbtCompat;

import com.flowclient.mods.schematics.model.Schematic;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2514;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2680;

public final class SchematicLoader {
    private SchematicLoader() {}

    public static Schematic load(Path file) throws IOException {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        class_2487 root = SchematicNbt.readRoot(file);

        if (name.endsWith(".litematic")) {
            return LitematicParser.parse(root);
        }
        if (name.endsWith(".schematic")) {
            if (SchematicFormatDetector.isSpongeFormat(root)) {
                Schematic sponge = SpongeSchemParser.parse(root);
                if (sponge.blockCount() > 0) {
                    return sponge;
                }
            }
            if (SchematicFormatDetector.isAlphaFormat(root)) {
                Schematic classic = ClassicSchematicParser.parse(root);
                if (classic.blockCount() > 0) {
                    return classic;
                }
            }
            Schematic sponge = SpongeSchemParser.parse(root);
            if (sponge.blockCount() > 0) {
                return sponge;
            }
            return ClassicSchematicParser.parse(root);
        }
        if (name.endsWith(".schem")) {
            Schematic sponge = SpongeSchemParser.parse(root);
            if (sponge.blockCount() > 0) {
                return sponge;
            }
            return parseClassicWithoutSponge(root);
        }
        if (name.endsWith(".nbt")) {
            return StructureNbtParser.parse(root);
        }

        Schematic fromStructure = StructureNbtParser.parse(root);
        if (fromStructure.blockCount() > 0) {
            return fromStructure;
        }
        return SpongeSchemParser.parse(root);
    }

    static class_2680 stateFromId(String id) {
        return BlockStateReader.parse(id);
    }

    static Map<class_2338, class_2680> mapFromPalette(
            int width, int height, int length,
            Map<Integer, class_2680> palette,
            byte[] blockData
    ) {
        Map<class_2338, class_2680> blocks = new HashMap<>();
        int index = 0;
        for (int y = 0; y < height; y++) {
            for (int z = 0; z < length; z++) {
                for (int x = 0; x < width; x++) {
                    if (index >= blockData.length) {
                        return blocks;
                    }
                    int paletteId = blockData[index++] & 0xFF;
                    class_2680 state = palette.getOrDefault(paletteId, class_2246.field_10124.method_9564());
                    if (!state.method_26215()) {
                        blocks.put(new class_2338(x, y, z), state);
                    }
                }
            }
        }
        return blocks;
    }

    static Map<class_2338, class_2680> mapFromPaletteInts(
            int width, int height, int length,
            Map<Integer, class_2680> palette,
            int[] blockData
    ) {
        Map<class_2338, class_2680> blocks = new HashMap<>();
        int index = 0;
        for (int y = 0; y < height; y++) {
            for (int z = 0; z < length; z++) {
                for (int x = 0; x < width; x++) {
                    if (index >= blockData.length) {
                        return blocks;
                    }
                    int paletteId = blockData[index++];
                    class_2680 state = palette.getOrDefault(paletteId, class_2246.field_10124.method_9564());
                    if (!state.method_26215()) {
                        blocks.put(new class_2338(x, y, z), state);
                    }
                }
            }
        }
        return blocks;
    }

    static Map<Integer, class_2680> paletteFromSponge(class_2487 paletteTag) {
        Map<Integer, class_2680> palette = new HashMap<>();
        if (paletteTag.method_33133()) {
            return palette;
        }

        boolean inverted = NbtCompat.keySet(paletteTag).stream().allMatch(SchematicLoader::isNumericPaletteKey);
        if (inverted) {
            for (String key : NbtCompat.keySet(paletteTag)) {
                try {
                    int id = Integer.parseInt(key);
                    String blockId = readPaletteBlockName(paletteTag.method_10580(key));
                    if (blockId != null) {
                        palette.put(id, BlockStateReader.parse(blockId));
                    }
                } catch (NumberFormatException ignored) {
                }
            }
        } else {
            for (String blockId : NbtCompat.keySet(paletteTag)) {
                Integer id = readPaletteId(paletteTag.method_10580(blockId));
                if (id != null && id >= 0) {
                    palette.put(id, BlockStateReader.parse(blockId));
                }
            }
        }

        return palette;
    }

    private static Schematic parseClassicWithoutSponge(class_2487 root) {
        class_2487 schematic = SchematicNbt.resolveSchematicTag(root);
        if (schematic.method_10545("Palette") || schematic.method_10545("BlockData") || schematic.method_10545("Blocks")) {
            return Schematic.empty();
        }
        return ClassicSchematicParser.parse(root);
    }

    private static Integer readPaletteId(class_2520 tag) {
        if (tag instanceof class_2514 numeric) {
            return NbtCompat.intValue(numeric);
        }
        if (tag instanceof class_2519 stringTag) {
            try {
                return Integer.parseInt(NbtCompat.stringValue(stringTag));
            } catch (NumberFormatException ignored) {
            }
        }
        return null;
    }

    private static String readPaletteBlockName(class_2520 tag) {
        if (tag instanceof class_2519 stringTag) {
            return NbtCompat.stringValue(stringTag);
        }
        if (tag instanceof class_2487 compound) {
            String name = NbtCompat.getStringOr(compound, "Name", "");
            if (!name.isBlank()) {
                return name;
            }
        }
        return null;
    }

    private static boolean isNumericPaletteKey(String key) {
        if (key == null || key.isEmpty()) {
            return false;
        }
        for (int i = 0; i < key.length(); i++) {
            if (!Character.isDigit(key.charAt(i))) {
                return false;
            }
        }
        return true;
    }

}

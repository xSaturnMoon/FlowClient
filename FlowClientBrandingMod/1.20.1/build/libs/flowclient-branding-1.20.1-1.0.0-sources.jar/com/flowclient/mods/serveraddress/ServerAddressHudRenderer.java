package com.flowclient.mods.serveraddress;

import com.flowclient.compat.FlowGfx;

import com.flowclient.mods.hud.HudElement;
import com.flowclient.mods.hud.HudLayoutManager;
import com.flowclient.mods.hud.HudRenderHelper;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import com.flowclient.compat.FlowArgb;

public final class ServerAddressHudRenderer {
    private ServerAddressHudRenderer() {
    }

    public static int getWidth(class_327 font) {
        return getWidth(font, ServerAddressHudSettings.get(), "mc.example.net");
    }

    public static int getHeight(class_327 font) {
        return getHeight(font, ServerAddressHudSettings.get());
    }

    public static int getWidth(class_327 font, ServerAddressHudSettings settings, String text) {
        return font.method_1727(text) + settings.paddingX() * 2;
    }

    public static int getHeight(class_327 font, ServerAddressHudSettings settings) {
        return font.field_2000 + settings.paddingY() * 2;
    }

    public static void render(class_310 mc, class_332 graphics, class_327 font) {
        render(mc, graphics, font, false);
    }

    public static void render(class_310 mc, class_332 graphics, class_327 font, boolean preview) {
        if (!preview && !ServerAddressHudMod.isEnabled()) {
            return;
        }

        ServerAddressHudSettings settings = ServerAddressHudSettings.get();
        if (!preview && settings.hideSingleplayer() && mc.method_1542()) {
            return;
        }

        String text = preview
                ? "mc.hypixel.net"
                : ServerAddressResolver.resolve(mc, settings.displayMode());
        int width = getWidth(font, settings, text);
        int height = getHeight(font, settings);
        int x = HudLayoutManager.get().resolveX(HudElement.SERVER_ADDRESS_HUD, width, height);
        int y = HudLayoutManager.get().resolveY(HudElement.SERVER_ADDRESS_HUD, width, height);
        float scale = HudLayoutManager.get().resolveScale(HudElement.SERVER_ADDRESS_HUD);

        HudRenderHelper.withLayout(graphics, x, y, scale, () -> {
            if (settings.showBackground()) {
                int alpha = (settings.backgroundOpacity() * 255) / 100;
                graphics.method_25294(x, y, x + width, y + height, FlowArgb.color(alpha, 8, 8, 12));
            }
            FlowGfx.text(graphics, 
                    font,
                    text,
                    x + settings.paddingX(),
                    y + settings.paddingY(),
                    0xFFE0E6F0,
                    settings.textShadow()
            );
        });
    }
}

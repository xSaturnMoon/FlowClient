package com.flowclient.mods.render;

import com.flowclient.compat.FlowGfx;
import com.flowclient.compat.WorldProjection;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class DamageIndicatorRenderer {
    private DamageIndicatorRenderer() {
    }

    public static void render(class_310 client, class_332 graphics, class_327 font) {
        if (!DamageIndicatorMod.isEnabled() || client.field_1687 == null || client.field_1773 == null) {
            return;
        }

        DamageIndicatorTracker.advancePopups();
        DamageIndicatorSettings settings = DamageIndicatorSettings.get();
        long now = System.currentTimeMillis();

        for (DamageIndicatorTracker.DamagePopup popup : DamageIndicatorTracker.popups()) {
            class_1297 entity = client.field_1687.method_8469(popup.entityId());
            class_243 anchor = entity != null
                    ? entity.method_19538().method_1031(0.0D, entity.method_17682() + 0.35D, 0.0D)
                    : popup.worldPosition();
            class_243 projected = WorldProjection.projectPointToScreen(client, anchor.method_1031(0.0D, popup.rise(), 0.0D));
            if (projected.field_1350 <= 0.0D || projected.field_1350 >= 1.0D) {
                continue;
            }

            int screenWidth = client.method_22683().method_4486();
            int screenHeight = client.method_22683().method_4502();
            int x = (int) ((projected.field_1352 + 1.0D) * 0.5D * screenWidth);
            int y = (int) ((1.0D - projected.field_1351) * 0.5D * screenHeight);

            float life = (now - popup.spawnTimeMs()) / (float) settings.durationMs();
            int alpha = (int) ((1.0F - life) * 255.0F) << 24;
            int color = (alpha & 0xFF000000) | (settings.textColor() & 0x00FFFFFF);
            if (popup.healing()) {
                color = (alpha & 0xFF000000) | 0x0055FF55;
            }

            String text = popup.healing()
                    ? "+" + formatAmount(popup.amount())
                    : formatAmount(popup.amount());
            x -= font.method_1727(text) / 2;
            FlowGfx.text(graphics, font, class_2561.method_43470(text), x, y, color, true);
        }
    }

    private static String formatAmount(float amount) {
        if (amount >= 10.0F) {
            return String.valueOf(Math.round(amount));
        }
        return String.format("%.1f", amount);
    }
}

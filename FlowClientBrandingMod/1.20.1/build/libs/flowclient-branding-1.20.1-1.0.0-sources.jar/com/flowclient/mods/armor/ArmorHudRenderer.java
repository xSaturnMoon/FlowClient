package com.flowclient.mods.armor;

import com.flowclient.compat.FlowGfx;

import com.flowclient.mods.hud.HudElement;
import com.flowclient.mods.hud.HudLayoutManager;
import com.flowclient.mods.hud.HudRenderHelper;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * Equipment HUD with configurable slots, durability display, and panel styling.
 */
public final class ArmorHudRenderer {
    private static final int ICON_SIZE = 16;
    private static final int ROW_H = 18;
    private static final int TEXT_WIDTH = 36;

    private ArmorHudRenderer() {}

    public static int getWidth() {
        return getWidth(class_310.method_1551().field_1772, ArmorHudSettings.get(), previewSlots());
    }

    public static int getHeight() {
        return getHeight(ArmorHudSettings.get(), previewSlots());
    }

    public static int getWidth(class_327 font, ArmorHudSettings settings, List<class_1304> slots) {
        if (slots.isEmpty()) {
            return ICON_SIZE + TEXT_WIDTH + settings.paddingX() * 2;
        }
        return ICON_SIZE + TEXT_WIDTH + settings.paddingX() * 2;
    }

    public static int getHeight(ArmorHudSettings settings, List<class_1304> slots) {
        if (slots.isEmpty()) {
            return ROW_H + settings.paddingY() * 2;
        }
        return slots.size() * ROW_H + settings.paddingY() * 2;
    }

    public static void render(class_310 mc, class_332 graphics, class_327 font) {
        render(mc, graphics, font, false);
    }

    public static void render(class_310 mc, class_332 graphics, class_327 font, boolean preview) {
        if (!preview && (!ArmorHudMod.isEnabled() || mc.field_1724 == null)) {
            return;
        }

        ArmorHudSettings settings = ArmorHudSettings.get();
        class_1657 player = preview && mc.field_1724 == null ? null : mc.field_1724;
        List<class_1304> slots = preview ? previewSlots() : visibleSlots(player, settings);
        if (slots.isEmpty()) {
            return;
        }

        int width = getWidth(font, settings, slots);
        int height = getHeight(settings, slots);
        int x = HudLayoutManager.get().resolveX(HudElement.ARMOR_HUD, width, height);
        int y = HudLayoutManager.get().resolveY(HudElement.ARMOR_HUD, width, height);
        float scale = HudLayoutManager.get().resolveScale(HudElement.ARMOR_HUD);

        HudRenderHelper.withLayout(graphics, x, y, scale, () -> {
            if (settings.showBackground()) {
                int alpha = (settings.backgroundOpacity() * 255) / 100;
                graphics.method_25294(x, y, x + width, y + height, (alpha << 24) | 0x08080C);
            }

            if (settings.showOutline()) {
                graphics.method_25294(x, y, x + width, y + 1, 0xFF4A9EE0);
                graphics.method_25294(x, y + height - 1, x + width, y + height, 0xFF1E2A40);
                graphics.method_25294(x, y, x + 1, y + height, 0xFF4A9EE0);
                graphics.method_25294(x + width - 1, y, x + width, y + height, 0xFF1E2A40);
            }

            int iconX = x + settings.paddingX() + TEXT_WIDTH;
            int rowY = y + settings.paddingY();

            for (class_1304 slot : slots) {
                class_1799 stack = player != null ? player.method_6118(slot) : class_1799.field_8037;
                if (preview && stack.method_7960()) {
                    stack = previewStack(slot);
                }

                if (!stack.method_7960()) {
                    if (settings.showDurability() && stack.method_7963()) {
                        int remaining = stack.method_7936() - stack.method_7919();
                        String text = formatDurability(remaining, stack.method_7936(), settings.durabilityFormat());
                        int textW = font.method_1727(text);
                        int color = durabilityTextColor(remaining, stack.method_7936());
                        FlowGfx.text(graphics, font, text, iconX - 5 - textW, rowY + 5, color, settings.textShadow());
                    }

                    FlowGfx.item(graphics, stack, iconX, rowY);
                }

                rowY += ROW_H;
            }
        });
    }

    private static List<class_1304> visibleSlots(class_1657 player, ArmorHudSettings settings) {
        List<class_1304> slots = new ArrayList<>(5);
        if (settings.showMainHand()) {
            addIfEquipped(slots, player, class_1304.field_6173);
        }
        if (settings.showHelmet()) {
            addIfEquipped(slots, player, class_1304.field_6169);
        }
        if (settings.showChestplate()) {
            addIfEquipped(slots, player, class_1304.field_6174);
        }
        if (settings.showLeggings()) {
            addIfEquipped(slots, player, class_1304.field_6172);
        }
        if (settings.showBoots()) {
            addIfEquipped(slots, player, class_1304.field_6166);
        }
        return slots;
    }

    private static void addIfEquipped(List<class_1304> slots, class_1657 player, class_1304 slot) {
        if (player != null && !player.method_6118(slot).method_7960()) {
            slots.add(slot);
        }
    }

    private static List<class_1304> previewSlots() {
        ArmorHudSettings settings = ArmorHudSettings.get();
        List<class_1304> slots = new ArrayList<>(5);
        if (settings.showMainHand()) slots.add(class_1304.field_6173);
        if (settings.showHelmet()) slots.add(class_1304.field_6169);
        if (settings.showChestplate()) slots.add(class_1304.field_6174);
        if (settings.showLeggings()) slots.add(class_1304.field_6172);
        if (settings.showBoots()) slots.add(class_1304.field_6166);
        return slots;
    }

    private static String formatDurability(int remaining, int max, ArmorHudDurabilityFormat format) {
        if (format == ArmorHudDurabilityFormat.PERCENT) {
            int percent = max > 0 ? Math.round(remaining * 100f / max) : 0;
            return percent + "%";
        }
        return String.valueOf(remaining);
    }

    private static class_1799 previewStack(class_1304 slot) {
        class_1799 stack = switch (slot) {
            case field_6173 -> new class_1799(net.minecraft.class_1802.field_8802);
            case field_6169 -> new class_1799(net.minecraft.class_1802.field_8805);
            case field_6174 -> new class_1799(net.minecraft.class_1802.field_8058);
            case field_6172 -> new class_1799(net.minecraft.class_1802.field_8348);
            case field_6166 -> new class_1799(net.minecraft.class_1802.field_8285);
            default -> class_1799.field_8037;
        };
        if (!stack.method_7960() && stack.method_7963()) {
            stack.method_7974(stack.method_7936() / 4);
        }
        return stack;
    }

    private static int durabilityTextColor(int remaining, int max) {
        if (max <= 0) {
            return 0xFFFFFFFF;
        }
        float ratio = (float) remaining / max;
        if (ratio > 0.5f) {
            return 0xFFFFFFFF;
        }
        if (ratio > 0.25f) {
            return 0xFFFFEE58;
        }
        return 0xFFFF7043;
    }
}

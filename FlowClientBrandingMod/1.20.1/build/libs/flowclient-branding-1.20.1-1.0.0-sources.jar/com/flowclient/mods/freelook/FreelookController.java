package com.flowclient.mods.freelook;

import com.flowclient.mods.FreelookMod;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_5498;

public final class FreelookController {
    // --- state ---
    private static boolean keyHeld;
    private static boolean engaged;

    // The camera angles that freelook controls
    private static float cameraYaw;
    private static float cameraPitch;

    // The player body angles saved when freelook begins
    private static float bodyYaw;
    private static float bodyPitch;
    private static float bodyHeadYaw;

    // The perspective setting before freelook
    private static class_5498 savedCameraType;
    // Whether we forced a perspective change
    private static boolean forcedPerspective;

    private FreelookController() {
    }

    // ---------------------------------------------------------------
    // Called every tick from FreelookKeys
    // ---------------------------------------------------------------
    public static void updateKeyState(boolean held, boolean allowed) {
        if (!FreelookMod.isEnabled() || !allowed) {
            if (!held) disengage();
            keyHeld = false;
            return;
        }

        if (held && !keyHeld) {
            begin();
        } else if (!held && keyHeld) {
            disengage();
        }
        keyHeld = held;
    }

    // ---------------------------------------------------------------
    // Called from MouseHandlerMixin with the SCALED mouse deltas
    // (same values that would normally be fed into player.turn())
    // Returns true if freelook consumed the delta (skip normal turn)
    // ---------------------------------------------------------------
    public static boolean applyTurnDelta(double yawDelta, double pitchDelta) {
        if (!FreelookMod.isEnabled() || !engaged) {
            return false;
        }

        // The deltas arriving here are ALREADY multiplied by Minecraft's
        // mouse sensitivity (same path as normal player turning).
        // Apply 0.5x factor: in third-person the camera feels twice as fast
        // visually (camera is decoupled from the body), so we halve the delta
        // to match the same feel as first-person turning — identical to Lunar.
        cameraYaw  += (float) (yawDelta * 0.5);
        cameraPitch = class_3532.method_15363(cameraPitch + (float) (pitchDelta * 0.5), -90.0f, 90.0f);
        return true;
    }

    // ---------------------------------------------------------------
    // Called every tick from LocalPlayerMixin to lock the body
    // ---------------------------------------------------------------
    public static void maintainBodyOrientation() {
        if (!engaged) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        mc.field_1724.method_36456(bodyYaw);
        mc.field_1724.method_36457(bodyPitch);
        mc.field_1724.method_5847(bodyHeadYaw);
        mc.field_1724.field_5982 = bodyYaw;
        mc.field_1724.field_6004 = bodyPitch;
    }

    // ---------------------------------------------------------------
    // Getters for mixins
    // ---------------------------------------------------------------
    public static boolean isEngaged()      { return engaged; }
    public static float   getCameraYaw()   { return cameraYaw; }
    public static float   getCameraPitch() { return cameraPitch; }

    // ---------------------------------------------------------------
    // Internal
    // ---------------------------------------------------------------
    private static void begin() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        engaged = true;

        // Save body orientation
        bodyYaw      = mc.field_1724.method_36454();
        bodyPitch    = mc.field_1724.method_36455();
        bodyHeadYaw  = mc.field_1724.method_5791();

        // Init camera to current camera orientation
        var camera = mc.field_1773.method_19418();
        cameraYaw = camera.method_19330();
        cameraPitch = camera.method_19329();

        // Save current perspective and force 3rd-person (back) like Lunar
        savedCameraType = mc.field_1690.method_31044();
        if (savedCameraType == class_5498.field_26664) {
            mc.field_1690.method_31043(class_5498.field_26665);
            forcedPerspective = true;
        } else {
            forcedPerspective = false;
        }
    }

    private static void disengage() {
        if (!engaged) return;
        engaged = false;

        // Restore original perspective
        class_310 mc = class_310.method_1551();
        if (forcedPerspective && savedCameraType != null) {
            mc.field_1690.method_31043(savedCameraType);
        }
    }
}

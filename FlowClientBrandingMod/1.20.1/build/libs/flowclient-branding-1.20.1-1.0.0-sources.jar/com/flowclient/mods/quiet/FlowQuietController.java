package com.flowclient.mods.quiet;

import net.minecraft.class_310;

public final class FlowQuietController {
    private static final int TICKS_PER_SECOND = 20;

    private static int idleTicks;
    private static boolean quietActive;
    private static boolean quietFromUnfocus;
    private static boolean quietFromAfk;
    private static int appliedBackgroundFps = -1;

    private FlowQuietController() {
    }

    public static boolean isQuietActive() {
        return quietActive;
    }

    public static boolean isAfkActive() {
        if (!FlowQuietMod.isEnabled()) {
            return false;
        }

        FlowQuietSettings settings = FlowQuietSettings.get();
        if (!settings.isAfkEnabled()) {
            return false;
        }

        return idleTicks >= settings.getAfkTimeoutSeconds() * TICKS_PER_SECOND;
    }

    public static boolean isAfkQuiet() {
        return quietActive && quietFromAfk;
    }

    public static long getIdleMillis() {
        return idleTicks * 50L;
    }

    public static void notifyInput() {
        idleTicks = 0;
    }

    public static void onClientStarted(class_310 client) {
        if (!FlowQuietMod.isEnabled()) {
            resetQuietState(client);
            return;
        }

        repairPersistedMaxFps(client);
    }

    private static void resetQuietState(class_310 client) {
        quietActive = false;
        quietFromUnfocus = false;
        quietFromAfk = false;
        appliedBackgroundFps = -1;
        idleTicks = 0;
        FlowQuietAudio.forceUnmute(client);
        restoreStuckFps(client);
    }

    private static void restoreStuckFps(class_310 client) {
        if (client == null || client.field_1690 == null) {
            return;
        }

        FlowQuietSettings settings = FlowQuietSettings.get();
        int current = client.field_1690.method_42524().method_41753();
        int preserved = settings.getPreservedMaxFps();
        if (current <= settings.getBackgroundFps() && preserved > current) {
            client.field_1690.method_42524().method_41748(preserved);
        }
    }

    public static void tick(class_310 client) {
        if (client == null || !FlowQuietMod.isEnabled()) {
            if (quietActive) {
                deactivate(client);
            }
            return;
        }

        FlowQuietSettings settings = FlowQuietSettings.get();

        if (!quietActive) {
            rememberCurrentMaxFps(client, settings);
        }

        trackMovementInput(client);

        if (idleTicks < Integer.MAX_VALUE - 1) {
            idleTicks++;
        }

        boolean unfocusQuiet = settings.isUnfocusedEnabled() && !client.method_1569();
        boolean afkQuiet = settings.isAfkEnabled() && isAfkActive();
        boolean shouldQuiet = unfocusQuiet || afkQuiet;

        if (shouldQuiet && !quietActive) {
            quietFromUnfocus = unfocusQuiet;
            quietFromAfk = afkQuiet;
            activate(client, settings);
        } else if (!shouldQuiet && quietActive) {
            deactivate(client);
        } else if (quietActive) {
            quietFromUnfocus = unfocusQuiet;
            quietFromAfk = afkQuiet;
            ensureBackgroundFps(client, settings);
        }
    }

    public static void forceDeactivate() {
        deactivate(class_310.method_1551());
    }

    public static void prepareOptionsSave() {
        if (!quietActive) {
            return;
        }

        class_310 client = class_310.method_1551();
        if (client == null || client.field_1690 == null) {
            return;
        }

        int restore = FlowQuietSettings.get().getPreservedMaxFps();
        if (restore > FlowQuietSettings.get().getBackgroundFps()) {
            client.field_1690.method_42524().method_41748(restore);
        }
    }

    public static void restoreQuietFpsIfNeeded() {
        if (!quietActive) {
            return;
        }

        class_310 client = class_310.method_1551();
        if (client == null || client.field_1690 == null) {
            return;
        }

        ensureBackgroundFps(client, FlowQuietSettings.get());
    }

    private static void trackMovementInput(class_310 client) {
        if (client.field_1690 == null) {
            return;
        }

        var options = client.field_1690;
        if (options.field_1894.method_1434()
                || options.field_1881.method_1434()
                || options.field_1913.method_1434()
                || options.field_1849.method_1434()
                || options.field_1903.method_1434()
                || options.field_1832.method_1434()
                || options.field_1867.method_1434()
                || options.field_1886.method_1434()
                || options.field_1904.method_1434()) {
            notifyInput();
        }
    }

    private static void rememberCurrentMaxFps(class_310 client, FlowQuietSettings settings) {
        if (client == null || client.field_1690 == null) {
            return;
        }

        int current = client.field_1690.method_42524().method_41753();
        if (current > settings.getBackgroundFps()) {
            settings.rememberMaxFps(current);
        }
    }

    private static void repairPersistedMaxFps(class_310 client) {
        if (client == null || client.field_1690 == null || quietActive || !FlowQuietMod.isEnabled()) {
            return;
        }

        FlowQuietSettings settings = FlowQuietSettings.get();
        int current = client.field_1690.method_42524().method_41753();
        int preserved = settings.getPreservedMaxFps();
        if (current == settings.getBackgroundFps() && preserved > current) {
            client.field_1690.method_42524().method_41748(preserved);
        }
    }

    private static void activate(class_310 client, FlowQuietSettings settings) {
        if (client == null || client.field_1690 == null || quietActive) {
            return;
        }

        rememberCurrentMaxFps(client, settings);
        quietActive = true;
        ensureBackgroundFps(client, settings);
        FlowQuietAudio.mute(client);
    }

    private static void ensureBackgroundFps(class_310 client, FlowQuietSettings settings) {
        int target = settings.getBackgroundFps();
        if (appliedBackgroundFps == target && client.field_1690.method_42524().method_41753() == target) {
            return;
        }

        client.field_1690.method_42524().method_41748(target);
        appliedBackgroundFps = target;
    }

    private static void deactivate(class_310 client) {
        if (!quietActive) {
            return;
        }

        quietActive = false;
        quietFromUnfocus = false;
        quietFromAfk = false;
        appliedBackgroundFps = -1;

        if (client != null && client.field_1690 != null) {
            int restore = FlowQuietSettings.get().getPreservedMaxFps();
            client.field_1690.method_42524().method_41748(restore);
            FlowQuietSettings.get().rememberMaxFps(restore);
            FlowQuietSettings.get().persist();
            FlowQuietAudio.unmute(client);
        } else {
            FlowQuietAudio.forceUnmute(null);
        }
    }
}

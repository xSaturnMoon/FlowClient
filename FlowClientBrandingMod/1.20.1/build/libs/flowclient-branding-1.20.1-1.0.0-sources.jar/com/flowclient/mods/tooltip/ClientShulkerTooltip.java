package com.flowclient.mods.tooltip;

import com.flowclient.compat.FlowGfx;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;

public final class ClientShulkerTooltip implements class_5684 {
    private static final int SLOT_SIZE = 18;
    private static final int COLS = 9;
    private static final int ROWS = 3;
    private static final int PADDING = 4;

    private final List<class_1799> contents;

    public ClientShulkerTooltip(List<class_1799> contents) {
        this.contents = contents;
    }

    @Override
    public int method_32661() {
        return ROWS * SLOT_SIZE + PADDING * 2;
    }

    @Override
    public int method_32664(class_327 font) {
        return COLS * SLOT_SIZE + PADDING * 2;
    }

    @Override
    public void method_32666(class_327 font, int x, int y, class_332 graphics) {
        for (int slot = 0; slot < Math.min(this.contents.size(), COLS * ROWS); slot++) {
            int col = slot % COLS;
            int row = slot / COLS;
            int drawX = x + PADDING + col * SLOT_SIZE;
            int drawY = y + PADDING + row * SLOT_SIZE;

            graphics.method_25294(drawX, drawY, drawX + 16, drawY + 16, 0x66000000);
            class_1799 stack = this.contents.get(slot);
            if (!stack.method_7960()) {
                FlowGfx.item(graphics, stack, drawX, drawY);
                graphics.method_51431(font, stack, drawX, drawY);
            }
        }
    }
}

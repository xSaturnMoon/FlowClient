package com.flowclient.mods.schematics;

import com.flowclient.mods.schematics.model.PlacementTransform;
import com.flowclient.mods.schematics.model.Schematic;
import com.flowclient.mods.schematics.parser.SchematicLoader;
import java.io.IOException;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_310;

public final class PlacementManager {
    private static SchematicEntry loadedEntry;
    private static Schematic loadedSchematic;
    private static class_2338 anchor = class_2338.field_10980;
    private static final PlacementTransform transform = new PlacementTransform();

    private PlacementManager() {}

    public static boolean hasPlacement() {
        return loadedSchematic != null && loadedSchematic.blockCount() > 0;
    }

    public static Schematic getSchematic() {
        return loadedSchematic;
    }

    public static SchematicEntry getEntry() {
        return loadedEntry;
    }

    public static class_2338 getAnchor() {
        return anchor;
    }

    public static void setAnchor(class_2338 anchor) {
        PlacementManager.anchor = anchor == null ? class_2338.field_10980 : anchor;
    }

    public static PlacementTransform getTransform() {
        return transform;
    }

    public static void load(SchematicEntry entry) throws IOException {
        loadedEntry = entry;
        loadedSchematic = SchematicLoader.load(entry.getFile());
        if (loadedSchematic.blockCount() == 0) {
            loadedEntry = null;
            loadedSchematic = null;
            throw new IOException("No blocks found in schematic file.");
        }
        anchor = defaultAnchor();
        transform.setOffsetX(0);
        transform.setOffsetY(0);
        transform.setOffsetZ(0);
        transform.setRotation(class_2470.field_11467);
        transform.setMirror(class_2415.field_11302);
    }

    public static void clear() {
        loadedEntry = null;
        loadedSchematic = null;
        anchor = class_2338.field_10980;
    }

    public static class_2338 toWorldPos(class_2338 local) {
        if (!hasPlacement()) {
            return local;
        }
        class_2338 transformed = transform.transformLocal(local, loadedSchematic.getWidth(), loadedSchematic.getLength());
        return anchor.method_10081(transformed);
    }

    public static void nudge(int dx, int dy, int dz) {
        transform.setOffsetX(transform.getOffsetX() + dx);
        transform.setOffsetY(transform.getOffsetY() + dy);
        transform.setOffsetZ(transform.getOffsetZ() + dz);
    }

    private static class_2338 defaultAnchor() {
        class_310 client = class_310.method_1551();
        class_1657 player = client.field_1724;
        if (player == null) {
            return class_2338.field_10980;
        }
        return player.method_24515();
    }
}

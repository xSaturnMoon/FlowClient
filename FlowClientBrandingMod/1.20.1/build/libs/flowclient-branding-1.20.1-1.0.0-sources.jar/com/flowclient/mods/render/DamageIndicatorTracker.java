package com.flowclient.mods.render;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class DamageIndicatorTracker {
    private static final Map<Integer, Float> LAST_HEALTH = new HashMap<>();
    private static final List<DamagePopup> POPUPS = new ArrayList<>();

    private DamageIndicatorTracker() {
    }

    public static void clear() {
        LAST_HEALTH.clear();
        POPUPS.clear();
    }

    public static List<DamagePopup> popups() {
        return POPUPS;
    }

    public static void tick(class_310 client) {
        if (client == null || client.field_1687 == null || !DamageIndicatorMod.isEnabled()) {
            LAST_HEALTH.clear();
            return;
        }

        long now = System.currentTimeMillis();
        DamageIndicatorSettings settings = DamageIndicatorSettings.get();

        if (client.field_1724 == null) {
            return;
        }

        for (class_1309 entity : client.field_1687.method_18467(class_1309.class, client.field_1724.method_5829().method_1014(48.0D))) {
            if (entity == client.field_1724) {
                continue;
            }

            int id = entity.method_5628();
            float health = entity.method_6032();
            Float previous = LAST_HEALTH.get(id);
            if (previous != null) {
                float delta = previous - health;
                if (delta > 0.05F) {
                    spawn(entity, delta, false, now);
                } else if (settings.showHealing() && delta < -0.05F) {
                    spawn(entity, -delta, true, now);
                }
            }
            LAST_HEALTH.put(id, health);
        }

        POPUPS.removeIf(popup -> now - popup.spawnTimeMs() > settings.durationMs());
    }

    private static void spawn(class_1309 entity, float amount, boolean healing, long now) {
        class_243 position = entity.method_19538().method_1031(0.0D, entity.method_17682() + 0.35D, 0.0D);
        POPUPS.add(new DamagePopup(entity.method_5628(), amount, healing, position, now));
    }

    public record DamagePopup(
            int entityId,
            float amount,
            boolean healing,
            class_243 worldPosition,
            long spawnTimeMs,
            float rise
    ) {
        DamagePopup(int entityId, float amount, boolean healing, class_243 worldPosition, long spawnTimeMs) {
            this(entityId, amount, healing, worldPosition, spawnTimeMs, 0.0F);
        }

        DamagePopup withRise(float rise) {
            return new DamagePopup(this.entityId, this.amount, this.healing, this.worldPosition, this.spawnTimeMs, rise);
        }
    }

    static void advancePopups() {
        for (int i = 0; i < POPUPS.size(); i++) {
            DamagePopup popup = POPUPS.get(i);
            POPUPS.set(i, popup.withRise(popup.rise() + 0.04F));
        }
    }
}

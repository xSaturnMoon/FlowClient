package com.flowclient.mods.otherclient;

import com.flowclient.FlowClientMod;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1049;
import net.minecraft.class_1060;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3300;

public final class FlowEmblemTextures {
    private FlowEmblemTextures() {}

    public static void register() {
        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new SimpleSynchronousResourceReloadListener() {
            @Override
            public class_2960 getFabricId() {
                return new class_2960(FlowClientMod.MOD_ID, "flow_emblem_texture");
            }

            @Override
            public void method_14491(class_3300 manager) {
                load();
            }
        });
    }

    public static void load() {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return;
        }

        class_1060 textures = client.method_1531();
        textures.method_4616(FlowEmblem.TEXTURE, new class_1049(FlowEmblem.TEXTURE));
    }

    public static void ensureLoaded() {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return;
        }

        class_1060 textures = client.method_1531();
        if (textures.method_34590(FlowEmblem.TEXTURE, null) == null) {
            load();
        }
    }
}

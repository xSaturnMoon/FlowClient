package com.flowclient.mods.freelook;

import com.flowclient.FlowClientKeyCategories;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class FreelookKeys {
    public static final String FREELOOK_KEY = "key.flowclient.freelook";

    private static final class_304 FREELOOK = new class_304(
            FREELOOK_KEY,
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_LEFT_ALT,
            FlowClientKeyCategories.FLOWCLIENT
    );

    private FreelookKeys() {
    }

    public static void register() {
        KeyBindingHelper.registerKeyBinding(FREELOOK);
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            boolean allowed = isAllowed(client);
            FreelookController.updateKeyState(isFreelookHeld(client), allowed);
        });
    }

    private static boolean isAllowed(class_310 client) {
        return client.field_1724 != null
                && client.field_1687 != null
                && client.field_1755 == null;
    }

    private static boolean isFreelookHeld(class_310 client) {
        if (FREELOOK.method_1434()) {
            return true;
        }

        var window = client.method_22683();
        if (window == null) {
            return false;
        }

        return class_3675.method_15987(window.method_4490(), GLFW.GLFW_KEY_LEFT_ALT)
                || class_3675.method_15987(window.method_4490(), GLFW.GLFW_KEY_RIGHT_ALT);
    }
}

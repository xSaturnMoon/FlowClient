package com.flowclient.mods.immersion;

import net.minecraft.class_1937;
import net.minecraft.class_5321;

public final class PortalFxController {
    public enum PortalEffect {
        NONE,
        NETHER,
        END,
        OVERWORLD
    }

    private static PortalEffect activeEffect = PortalEffect.NONE;
    private static float intensity;
    private static int titleTicks;

    private PortalFxController() {
    }

    public static void reset() {
        activeEffect = PortalEffect.NONE;
        intensity = 0.0F;
        titleTicks = 0;
    }

    public static void onDimensionChange(class_5321<class_1937> from, class_5321<class_1937> to) {
        if (!PortalFxMod.isEnabled()) {
            return;
        }

        if (to.equals(class_1937.field_25180)) {
            activeEffect = PortalEffect.NETHER;
        } else if (to.equals(class_1937.field_25181)) {
            activeEffect = PortalEffect.END;
        } else if (from.equals(class_1937.field_25180) || from.equals(class_1937.field_25181)) {
            activeEffect = PortalEffect.OVERWORLD;
        } else {
            return;
        }

        intensity = 1.0F;
        titleTicks = 50;
    }

    public static void tick() {
        if (!PortalFxMod.isEnabled() || intensity <= 0.0F) {
            return;
        }
        intensity = Math.max(0.0F, intensity - 0.018F);
        if (titleTicks > 0) {
            titleTicks--;
        }
        if (intensity <= 0.0F) {
            activeEffect = PortalEffect.NONE;
        }
    }

    public static PortalEffect activeEffect() {
        return activeEffect;
    }

    public static float intensity() {
        return intensity;
    }

    public static boolean showTitle() {
        return titleTicks > 0;
    }
}

package com.flowclient.mods.fullbright;

import net.minecraft.class_310;
import net.minecraft.class_7172;

public final class FullbrightController {
    private static final double FULLBRIGHT_GAMMA = 16.0D;

    private static Double savedGamma;

    private FullbrightController() {
    }

    public static void sync() {
        class_310 client = class_310.method_1551();
        if (client == null) {
            return;
        }
        apply(client);
    }

    public static void apply(class_310 client) {
        class_7172<Double> gamma = client.field_1690.method_42473();
        if (FullbrightMod.isEnabled()) {
            if (savedGamma == null) {
                savedGamma = gamma.method_41753();
            }
            if (gamma.method_41753() < FULLBRIGHT_GAMMA) {
                gamma.method_41748(FULLBRIGHT_GAMMA);
            }
            return;
        }
        restore(gamma);
    }

    private static void restore(class_7172<Double> gamma) {
        if (savedGamma == null) {
            return;
        }
        gamma.method_41748(savedGamma);
        savedGamma = null;
    }

    public static void onClientStopping() {
        class_310 client = class_310.method_1551();
        if (client != null) {
            restore(client.field_1690.method_42473());
        }
        savedGamma = null;
    }
}

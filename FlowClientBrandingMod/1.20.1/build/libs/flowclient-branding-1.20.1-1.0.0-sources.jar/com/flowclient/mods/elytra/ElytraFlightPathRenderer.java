package com.flowclient.mods.elytra;

import net.minecraft.class_310;

public final class ElytraFlightPathRenderer {
    private ElytraFlightPathRenderer() {
    }

    public static boolean shouldRender() {
        return ElytraFlightPathMod.isEnabled();
    }

    public static void render(class_310 client) {
    }
}

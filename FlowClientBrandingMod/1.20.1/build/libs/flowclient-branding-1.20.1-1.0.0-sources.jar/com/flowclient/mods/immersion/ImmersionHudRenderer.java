package com.flowclient.mods.immersion;

import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class ImmersionHudRenderer {
    private ImmersionHudRenderer() {
    }

    public static void render(class_310 client, class_332 graphics, class_327 font) {
        PortalFxRenderer.render(client, graphics, font);
        ComboCounterRenderer.render(client, graphics, font);
    }
}

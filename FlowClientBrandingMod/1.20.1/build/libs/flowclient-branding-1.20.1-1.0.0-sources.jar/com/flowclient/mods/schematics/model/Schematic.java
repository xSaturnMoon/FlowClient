package com.flowclient.mods.schematics.model;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public final class Schematic {
    private final int width;
    private final int height;
    private final int length;
    private final Map<class_2338, class_2680> blocks;

    public Schematic(int width, int height, int length, Map<class_2338, class_2680> blocks) {
        this.width = width;
        this.height = height;
        this.length = length;
        this.blocks = Collections.unmodifiableMap(blocks);
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public int getLength() {
        return length;
    }

    public Map<class_2338, class_2680> getBlocks() {
        return blocks;
    }

    public int blockCount() {
        return blocks.size();
    }

    public static Schematic empty() {
        return new Schematic(0, 0, 0, Map.of());
    }

    public static Builder builder(int width, int height, int length) {
        return new Builder(width, height, length);
    }

    public static final class Builder {
        private final int width;
        private final int height;
        private final int length;
        private final Map<class_2338, class_2680> blocks = new HashMap<>();

        private Builder(int width, int height, int length) {
            this.width = width;
            this.height = height;
            this.length = length;
        }

        public void put(int x, int y, int z, class_2680 state) {
            if (state == null || state.method_26215()) {
                return;
            }
            blocks.put(new class_2338(x, y, z), state);
        }

        public Schematic build() {
            return new Schematic(width, height, length, blocks);
        }
    }
}

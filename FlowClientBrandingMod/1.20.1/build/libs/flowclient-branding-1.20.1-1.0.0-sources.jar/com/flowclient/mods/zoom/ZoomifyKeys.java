package com.flowclient.mods.zoom;

import com.flowclient.FlowClientKeyCategories;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;

public final class ZoomifyKeys {
    public static final String ZOOM_KEY = "key.flowclient.zoom";

    private static final class_304 ZOOM = new class_304(
            ZOOM_KEY,
            GLFW.GLFW_KEY_C,
            FlowClientKeyCategories.FLOWCLIENT
    );

    private ZoomifyKeys() {
    }

    public static void register() {
        KeyBindingHelper.registerKeyBinding(ZOOM);
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null || client.field_1687 == null) {
                ZoomController.setZoomKeyHeld(false);
                return;
            }

            boolean zoomAllowed = client.field_1755 == null;
            ZoomController.setZoomKeyHeld(zoomAllowed && ZOOM.method_1434());
            ZoomController.updateTargets();
        });
    }
}

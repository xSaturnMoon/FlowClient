package com.flowclient.mods.hud;

import net.minecraft.class_332;

public final class HudRenderHelper {
    private HudRenderHelper() {
    }

    public static void withLayout(
            class_332 graphics,
            int x,
            int y,
            float scale,
            Runnable draw
    ) {
        float clamped = HudScale.clamp(scale);
        if (HudScale.isUnity(clamped)) {
            draw.run();
            return;
        }

        var pose = graphics.method_51448();
        pose.method_22903();
        pose.method_22904(x, y, 0.0D);
        pose.method_22905(clamped, clamped, 1.0F);
        pose.method_22904(-x, -y, 0.0D);
        draw.run();
        pose.method_22909();
    }

    public static int scaledSize(int size, float scale) {
        return Math.max(1, Math.round(size * HudScale.clamp(scale)));
    }
}

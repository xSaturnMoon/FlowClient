package com.flowclient.mods.schematics;

import com.flowclient.mods.schematics.model.Schematic;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_746;
import net.minecraft.server.MinecraftServer;
import java.util.Map;

public final class AutoBuilder {
    private AutoBuilder() {}

    public static void build(class_310 client) {
        class_746 player = client.field_1724;
        if (player == null || !player.method_7337() || !PlacementManager.hasPlacement()) {
            return;
        }

        MinecraftServer server = client.method_1576();
        if (server == null) {
            player.method_43496(
                    class_2561.method_43470("AutoBuild works in single-player creative worlds.")
            );
            return;
        }

        Schematic schematic = PlacementManager.getSchematic();
        class_3218 level = server.method_3847(player.method_37908().method_27983());
        if (level == null) {
            return;
        }

        server.execute(() -> {
            int placed = 0;
            for (Map.Entry<class_2338, class_2680> entry : schematic.getBlocks().entrySet()) {
                class_2338 worldPos = PlacementManager.toWorldPos(entry.getKey());
                level.method_8501(worldPos, entry.getValue());
                placed++;
            }
            int finalPlaced = placed;
            player.method_43496(
                    class_2561.method_43470("AutoBuild placed " + finalPlaced + " blocks.")
            );
        });
    }
}

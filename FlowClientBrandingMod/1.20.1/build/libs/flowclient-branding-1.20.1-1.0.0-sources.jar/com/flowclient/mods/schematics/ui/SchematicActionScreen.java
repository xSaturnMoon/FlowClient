package com.flowclient.mods.schematics.ui;

import com.flowclient.compat.FlowGfx;

import com.flowclient.modpanel.ModPanelScreen;
import com.flowclient.mods.schematics.PlacementManager;
import com.flowclient.mods.schematics.SchematicEntry;
import com.flowclient.mods.schematics.SchematicRepository;
import java.io.IOException;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class SchematicActionScreen extends ModPanelScreen {
    private final SchematicEntry entry;

    public SchematicActionScreen(class_437 parent, SchematicEntry entry) {
        super(class_2561.method_43470(entry.getDisplayName()), parent);
        this.entry = entry;
    }

    @Override
    protected void method_25426() {
        this.initPanel();
    }

    @Override
    protected void initPanel() {
        int bw = 200;
        int x = this.centerX(bw);
        int y = this.frameY() + 24;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Load"), button -> {
            try {
                PlacementManager.load(this.entry);
                if (this.field_22787.field_1724 != null) {
                    int blocks = PlacementManager.getSchematic().blockCount();
                    this.field_22787.field_1724.method_43496(
                            class_2561.method_43470("Loaded schematic with " + blocks + " blocks.")
                    );
                }
                this.field_22787.method_1507(null);
            } catch (IOException ex) {
                if (this.field_22787.field_1724 != null) {
                    this.field_22787.field_1724.method_43496(
                            class_2561.method_43470("Failed to load schematic: " + ex.getMessage())
                    );
                }
                this.field_22787.method_1507(new SchematicBrowserScreen(this.parent));
            }
        }).method_46434(x, y, bw, BUTTON_HEIGHT).method_46431());
        y += BUTTON_HEIGHT + 6;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Rename"), button ->
                this.field_22787.method_1507(new SchematicRenameScreen(this, this.entry)))
                .method_46434(x, y, bw, BUTTON_HEIGHT).method_46431());
        y += BUTTON_HEIGHT + 6;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Delete"), button -> {
            try {
                SchematicRepository.delete(this.entry);
                this.field_22787.method_1507(new SchematicBrowserScreen(this.parent));
            } catch (IOException ignored) {
                this.field_22787.method_1507(new SchematicBrowserScreen(this.parent));
            }
        }).method_46434(x, y, bw, BUTTON_HEIGHT).method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Back"),
                button -> this.field_22787.method_1507(new SchematicBrowserScreen(this.parent))
        ).method_46434(this.centerX(BUTTON_WIDTH), this.field_22790 - 32, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        this.drawContentFrame(graphics, this.frameX(), this.frameY(), this.frameWidth(), this.frameHeight());
        FlowGfx.text(graphics, this.field_22793, class_2561.method_43470(this.entry.getDisplayName()), this.frameX() + 12, this.frameY() + 10, 0xFFFFFFFF, false);
        FlowGfx.text(graphics, this.field_22793, class_2561.method_43470(this.entry.getSizeLabel()), this.frameX() + 12, this.frameY() + 22, 0xFFAAAAAA, false);
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    private int frameWidth() {
        return Math.min(this.field_22789 - 40, 280);
    }

    private int frameHeight() {
        return 180;
    }

    private int frameX() {
        return this.centerX(this.frameWidth());
    }

    private int frameY() {
        return 48;
    }
}

package com.flowclient.mods.preview;

import com.flowclient.mods.elytra.ElytraFlightPathRenderer;
import com.flowclient.mods.explosion.CrystalBedPreviewRenderer;
import com.flowclient.mods.pearl.PearlLandingMarkerRenderer;
import com.flowclient.mods.reach.ReachRingRenderer;
import net.minecraft.class_310;

public final class WorldPreviewTickController {
    private WorldPreviewTickController() {
    }

    public static void tick(class_310 client) {
        if (client == null || client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        if (!PearlLandingMarkerRenderer.shouldRender()
                && !ElytraFlightPathRenderer.shouldRender()
                && !ReachRingRenderer.shouldRender()
                && !CrystalBedPreviewRenderer.shouldRender()) {
            return;
        }

        PearlLandingMarkerRenderer.render(client);
        ElytraFlightPathRenderer.render(client);
        ReachRingRenderer.render(client);
        CrystalBedPreviewRenderer.render(client);
    }
}

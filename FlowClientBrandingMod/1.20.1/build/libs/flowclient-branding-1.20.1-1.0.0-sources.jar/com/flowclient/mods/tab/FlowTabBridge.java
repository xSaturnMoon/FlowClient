package com.flowclient.mods.tab;

import java.util.List;
import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_355;
import net.minecraft.class_640;

public interface FlowTabBridge {
    class_355 overlay();

    class_310 minecraft();

    List<class_640> players();

    class_2561 header();

    class_2561 footer();

    class_2561 nameForDisplay(class_640 info);

    void drawPingIcon(class_332 graphics, int columnWidth, int rowX, int rowY, class_640 info);

    void drawHearts(int x, int y, int columnWidth, UUID playerId, class_332 graphics, int rowIndex);

    void drawObjectiveScore(
            class_266 objective,
            int x,
            int y,
            int columnWidth,
            class_640 info,
            class_332 graphics
    );
}

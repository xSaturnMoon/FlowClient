package com.flowclient.mods.ping;

import com.flowclient.compat.FlowGfx;

import com.flowclient.mods.hud.HudElement;
import com.flowclient.mods.hud.HudLayoutManager;
import com.flowclient.mods.hud.HudRenderHelper;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_640;
import com.flowclient.compat.FlowArgb;

public final class PingHudRenderer {
    private PingHudRenderer() {
    }

    public static int getWidth(class_327 font) {
        return getWidth(font, PingHudSettings.get(), "Ping 42ms");
    }

    public static int getHeight(class_327 font) {
        return getHeight(font, PingHudSettings.get());
    }

    public static int getWidth(class_327 font, PingHudSettings settings, String text) {
        return font.method_1727(text) + settings.paddingX() * 2;
    }

    public static int getHeight(class_327 font, PingHudSettings settings) {
        return font.field_2000 + settings.paddingY() * 2;
    }

    public static void render(class_310 mc, class_332 graphics, class_327 font) {
        render(mc, graphics, font, false);
    }

    public static void render(class_310 mc, class_332 graphics, class_327 font, boolean preview) {
        if (!preview && !PingHudMod.isEnabled()) {
            return;
        }

        PingHudSettings settings = PingHudSettings.get();
        int ping = preview ? 42 : resolvePing(mc);
        String text = settings.format(ping);
        int width = getWidth(font, settings, text);
        int height = getHeight(font, settings);
        int x = HudLayoutManager.get().resolveX(HudElement.PING_HUD, width, height);
        int y = HudLayoutManager.get().resolveY(HudElement.PING_HUD, width, height);
        float scale = HudLayoutManager.get().resolveScale(HudElement.PING_HUD);
        int color = settings.resolveColor(ping);

        HudRenderHelper.withLayout(graphics, x, y, scale, () -> {
            if (settings.showBackground()) {
                int alpha = (settings.backgroundOpacity() * 255) / 100;
                graphics.method_25294(x, y, x + width, y + height, FlowArgb.color(alpha, 8, 8, 12));
            }
            FlowGfx.text(graphics, 
                    font,
                    text,
                    x + settings.paddingX(),
                    y + settings.paddingY(),
                    color,
                    settings.textShadow()
            );
        });
    }

    private static int resolvePing(class_310 mc) {
        if (mc.field_1724 == null || mc.method_1562() == null) {
            return -1;
        }

        class_640 info = mc.method_1562().method_2871(mc.field_1724.method_5667());
        return info != null ? info.method_2959() : -1;
    }
}

package com.flowclient.mods.schematics.ui;

import com.flowclient.modpanel.ModPanelScreen;
import com.flowclient.mods.schematics.SchematicEntry;
import com.flowclient.mods.schematics.SchematicRepository;
import java.io.IOException;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class SchematicRenameScreen extends ModPanelScreen {
    private final SchematicEntry entry;
    private class_342 nameBox;

    public SchematicRenameScreen(class_437 parent, SchematicEntry entry) {
        super(class_2561.method_43470("Rename Schematic"), parent);
        this.entry = entry;
    }

    @Override
    protected void method_25426() {
        this.initPanel();
    }

    @Override
    protected void initPanel() {
        int bw = 220;
        int x = this.centerX(bw);
        int y = this.frameY() + 28;

        this.nameBox = new class_342(this.field_22793, x, y, bw, BUTTON_HEIGHT, class_2561.method_43470("Name"));
        this.nameBox.method_1880(64);
        this.nameBox.method_1852(this.entry.getDisplayName());
        this.method_37063(this.nameBox);
        y += BUTTON_HEIGHT + 10;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Save"), button -> {
            try {
                SchematicRepository.rename(this.entry, this.nameBox.method_1882());
                this.field_22787.method_1507(new SchematicBrowserScreen(this.parent));
            } catch (IOException ignored) {
                this.field_22787.method_1507(new SchematicActionScreen(this.parent, this.entry));
            }
        }).method_46434(x, y, bw, BUTTON_HEIGHT).method_46431());

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Cancel"),
                button -> this.field_22787.method_1507(new SchematicActionScreen(this.parent, this.entry))
        ).method_46434(this.centerX(BUTTON_WIDTH), this.field_22790 - 32, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        this.drawContentFrame(graphics, this.frameX(), this.frameY(), this.frameWidth(), this.frameHeight());
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    private int frameWidth() {
        return Math.min(this.field_22789 - 40, 260);
    }

    private int frameHeight() {
        return 140;
    }

    private int frameX() {
        return this.centerX(this.frameWidth());
    }

    private int frameY() {
        return 56;
    }
}

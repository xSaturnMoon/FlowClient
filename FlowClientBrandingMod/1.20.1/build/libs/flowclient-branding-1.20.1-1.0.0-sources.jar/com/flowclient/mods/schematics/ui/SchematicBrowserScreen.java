package com.flowclient.mods.schematics.ui;

import com.flowclient.compat.FlowGfx;

import com.flowclient.modpanel.ModPanelScreen;
import com.flowclient.mods.schematics.PlacementManager;
import com.flowclient.mods.schematics.SchematicEntry;
import com.flowclient.mods.schematics.SchematicImporter;
import com.flowclient.mods.schematics.SchematicRepository;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class SchematicBrowserScreen extends ModPanelScreen {
    private static final class_2561 TITLE = class_2561.method_43470("AllSchematics");
    private static final int ARROW_WIDTH = 24;
    private static final int COLUMN_GAP = 8;
    private static final int ROW_GAP = 4;

    private class_342 searchBox;
    private String searchQuery = "";
    private List<SchematicEntry> entries = List.of();
    private int scrollOffset;

    public SchematicBrowserScreen(class_437 parent) {
        super(TITLE, parent);
    }

    @Override
    protected void method_25426() {
        this.reloadEntries();
        this.method_41843();
    }

    @Override
    protected void initPanel() {
        int frameX = this.frameX();
        int frameY = this.frameY();
        int frameWidth = this.frameWidth();
        int topY = frameY + 8;
        int addWidth = 116;
        int searchWidth = frameWidth - addWidth - ARROW_WIDTH - (COLUMN_GAP * 2) - 16;
        int addX = frameX + 8;
        int arrowX = addX + addWidth + COLUMN_GAP;
        int searchX = arrowX + ARROW_WIDTH + COLUMN_GAP;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Add Schematic"), button -> {
            if (SchematicImporter.importFromDialog()) {
                this.reloadEntries();
                this.method_41843();
            }
        }).method_46434(addX, topY, addWidth, BUTTON_HEIGHT).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470(">"), button -> {
            if (!PlacementManager.hasPlacement()) {
                if (this.field_22787.field_1724 != null) {
                    this.field_22787.field_1724.method_43496(
                            class_2561.method_43470("Load a schematic first to open placement settings.")
                    );
                }
                return;
            }
            this.field_22787.method_1507(new SchematicPlacementScreen(this));
        }).method_46434(arrowX, topY, ARROW_WIDTH, BUTTON_HEIGHT).method_46431());

        this.searchBox = new class_342(this.field_22793, searchX, topY, searchWidth, BUTTON_HEIGHT, class_2561.method_43470("Search"));
        this.searchBox.method_1880(64);
        this.searchBox.method_1852(this.searchQuery);
        this.searchBox.method_47404(class_2561.method_43470("Search schematics..."));
        this.searchBox.method_1863(value -> {
            this.searchQuery = value;
            this.scrollOffset = 0;
            this.reloadEntries();
            this.method_41843();
        });
        this.method_37063(this.searchBox);

        int listTop = topY + BUTTON_HEIGHT + 8;
        int listHeight = frameY + this.frameHeight() - listTop - 8;
        int columnWidth = (frameWidth - 16 - COLUMN_GAP) / 2;
        int rowHeight = BUTTON_HEIGHT + ROW_GAP;
        int visibleRows = Math.max(1, listHeight / rowHeight);
        int maxScroll = Math.max(0, ((entries.size() + 1) / 2) - visibleRows);
        this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, maxScroll));

        int startIndex = this.scrollOffset * 2;
        for (int i = startIndex; i < entries.size(); i++) {
            int row = (i - startIndex) / 2;
            if (row >= visibleRows) {
                break;
            }
            int column = i % 2;
            int x = frameX + 8 + column * (columnWidth + COLUMN_GAP);
            int y = listTop + row * rowHeight;
            SchematicEntry entry = entries.get(i);
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470(entry.getDisplayName()),
                    button -> this.field_22787.method_1507(new SchematicActionScreen(this, entry))
            ).method_46434(x, y, columnWidth, BUTTON_HEIGHT).method_46431());
        }

        if (entries.isEmpty()) {
            // no entries - hint text rendered in extractRenderState
        }

        if (this.parent != null) {
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("Back"),
                    button -> this.field_22787.method_1507(this.parent)
            ).method_46434(this.centerX(BUTTON_WIDTH), this.field_22790 - 32, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
        }
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollDelta) {
        if (this.isHoveringFrame(mouseX, mouseY)) {
            this.scrollOffset = (int) Math.max(0, this.scrollOffset - (int) scrollDelta);
            this.method_41843();
            return true;
        }
        return super.method_25401(mouseX, mouseY, scrollDelta);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        this.drawContentFrame(graphics, this.frameX(), this.frameY(), this.frameWidth(), this.frameHeight());
        if (this.entries.isEmpty()) {
            FlowGfx.text(graphics, 
                    this.field_22793,
                    class_2561.method_43470("No schematics found. Add files to " + SchematicRepository.getRoot()),
                    this.frameX() + 12,
                    this.frameY() + 64,
                    0xFFAAAAAA,
                    false
            );
        }
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    private void reloadEntries() {
        try {
            this.entries = new ArrayList<>(SchematicRepository.search(this.searchQuery));
        } catch (IOException ex) {
            this.entries = List.of();
        }
    }

    private boolean isHoveringFrame(double mouseX, double mouseY) {
        return mouseX >= this.frameX()
                && mouseX <= this.frameX() + this.frameWidth()
                && mouseY >= this.frameY()
                && mouseY <= this.frameY() + this.frameHeight();
    }

    private int frameWidth() {
        return Math.min(this.field_22789 - 40, 420);
    }

    private int frameHeight() {
        return Math.min(this.field_22790 - 60, this.field_22790 - 80);
    }

    private int frameX() {
        return this.centerX(this.frameWidth());
    }

    private int frameY() {
        return 24;
    }
}

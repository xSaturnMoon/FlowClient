package com.flowclient.mods.otherclient;

import com.mojang.authlib.GameProfile;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2960;
import net.minecraft.class_640;

public final class ClientBadgeHelper {
    private ClientBadgeHelper() {}

    public static void triggerDetection(UUID uuid, String username, class_640 info) {
        if (!OtherClientMod.isEnabled() || !isValidUsername(username)) return;
        ClientDetector.inspectLocal(uuid, username, info);
    }

    public static void triggerDetection(class_1657 player) {
        if (!OtherClientMod.isEnabled() || player == null) return;
        net.minecraft.class_310 mc = net.minecraft.class_310.method_1551();
        class_640 info = mc.method_1562() != null
                ? mc.method_1562().method_2871(player.method_5667())
                : null;
        triggerDetection(player.method_5667(), player.method_7334().getName(), info);
    }

    public static class_2561 decorateTabName(UUID uuid, String username, class_2561 currentName) {
        if (!OtherClientMod.isEnabled()) return currentName;
        triggerDetection(uuid, username, net.minecraft.class_310.method_1551().method_1562() != null
                ? net.minecraft.class_310.method_1551().method_1562().method_2871(uuid)
                : null);
        return appendBadge(uuid, currentName);
    }

    public static class_2561 createTabListName(class_640 info, class_2561 baseName) {
        if (!OtherClientMod.isEnabled() || info == null) {
            return baseName;
        }

        GameProfile profile = info.method_2966();
        String username = cleanUsername(profile.getName());
        triggerDetection(profile.getId(), username, info);
        return appendBadge(profile.getId(), baseName != null ? baseName : class_2561.method_43470(username));
    }

    public static class_2561 appendBadge(UUID uuid, class_2561 baseName) {
        DetectedClient primary = resolvePrimaryBadge(uuid);
        if (primary == null || baseName == null) {
            return baseName;
        }

        class_2561 badgeComponent;
        if (primary.isGameClient()) {
            badgeComponent = class_2561.method_43470(primary.badge).method_27696(
                    class_2583.field_24360.method_27704(new class_2960("flowclient", "badge"))
            );
        } else {
            badgeComponent = class_2561.method_43470("[" + primary.badge + "] ")
                    .method_27696(class_2583.field_24360.method_27703(net.minecraft.class_5251.method_27717(primary.color)));
        }
        return class_2561.method_43473().method_10852(badgeComponent).method_10852(class_2561.method_43470(" ")).method_10852(baseName);
    }

    public static class_2561 decorateDisplayName(class_1657 player, class_2561 currentName) {
        if (!OtherClientMod.isEnabled() || player == null) return currentName;
        triggerDetection(player);
        return currentName;
    }

    public static DetectedClient resolvePrimaryBadge(UUID uuid) {
        if (!OtherClientMod.isEnabled()) return null;

        net.minecraft.class_310 mc = net.minecraft.class_310.method_1551();
        if (mc.field_1724 != null && uuid.equals(mc.field_1724.method_5667())) {
            return DetectedClient.FLOWCLIENT;
        }

        DetectedClient primary = ClientDetector.getPrimary(uuid);
        return primary.isGameClient() ? primary : null;
    }

    public static List<DetectedClient> resolveBadges(UUID uuid) {
        List<DetectedClient> clients = ClientDetector.getClients(uuid);
        if (clients.size() == 1 && clients.get(0) == DetectedClient.LOADING) {
            return List.of();
        }

        return clients.stream()
                .filter(c -> c != DetectedClient.LOADING && c != DetectedClient.VANILLA && c.isGameClient())
                .max(DetectedClient.BY_PRIORITY)
                .map(List::of)
                .orElse(List.of());
    }

    public static boolean isValidUsername(String username) {
        if (username == null) return false;
        String stripped = stripFormatting(username).trim();
        if (stripped.isEmpty() || stripped.length() > 16) return false;
        return stripped.matches("^(?:[\\*\\+\\.][a-zA-Z0-9_]{1,16}|[a-zA-Z0-9_]{1,16})$");
    }

    public static String stripFormatting(String text) {
        if (text == null) return "";
        StringBuilder out = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\u00A7' && i + 1 < text.length()) {
                i++;
                continue;
            }
            out.append(c);
        }
        return out.toString();
    }

    public static String cleanUsername(String username) {
        return stripFormatting(username).trim();
    }
}

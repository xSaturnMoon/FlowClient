package com.flowclient.mods.otherclient;

import com.flowclient.compat.FlowGfx;
import org.joml.Matrix4f;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4588;

public final class ClientBadgeRenderer {
    public static final int BADGE_SIZE = 12;
    public static final int BADGE_GAP = 2;

    private static final Map<class_2561, DetectedClient> PENDING_BADGES = new IdentityHashMap<>();
    private static final Map<String, DetectedClient> PENDING_BADGES_BY_TEXT = new ConcurrentHashMap<>();
    private static final ThreadLocal<Boolean> SEE_THROUGH_PASS = ThreadLocal.withInitial(() -> false);

    private ClientBadgeRenderer() {}

    public static void setSeeThroughPass(boolean seeThrough) {
        SEE_THROUGH_PASS.set(seeThrough);
    }

    public static boolean isSeeThroughPass() {
        return Boolean.TRUE.equals(SEE_THROUGH_PASS.get());
    }

    public static void registerPendingBadge(class_2561 component, DetectedClient client) {
        if (component == null || client == null) {
            return;
        }
        PENDING_BADGES.put(component, client);
        PENDING_BADGES_BY_TEXT.put(component.getString(), client);
    }

    public static DetectedClient getPendingBadge(class_2561 component) {
        if (component == null) {
            return null;
        }

        DetectedClient badge = PENDING_BADGES.get(component);
        if (badge != null) {
            return badge;
        }
        return PENDING_BADGES_BY_TEXT.get(component.getString());
    }

    public static void clearPendingBadges() {
        PENDING_BADGES.clear();
        PENDING_BADGES_BY_TEXT.clear();
        SEE_THROUGH_PASS.remove();
    }

    public static float badgeTextOffset(class_2561 component) {
        return getPendingBadge(component) == null ? 0.0F : (BADGE_SIZE + BADGE_GAP) / 2.0F;
    }

    public static class_1921 badgeRenderType() {
        FlowEmblemTextures.ensureLoaded();
        return isSeeThroughPass()
                ? class_1921.method_23030(FlowEmblem.TEXTURE)
                : class_1921.method_23028(FlowEmblem.TEXTURE);
    }

    public static void drawNametagBadge(
            Matrix4f pose,
            class_4588 consumer,
            float textX,
            float textY,
            int lightCoords
    ) {
        float badgeX = textX - BADGE_SIZE - BADGE_GAP;
        float badgeY = textY - 1.0F;
        drawTexturedQuad(pose, consumer, badgeX, badgeY, BADGE_SIZE, BADGE_SIZE, lightCoords);
    }

    public static void renderTabBadge(class_332 graphics, int x, int y) {
        FlowEmblemTextures.ensureLoaded();
        FlowGfx.blit(graphics, FlowEmblem.TEXTURE, x, y, BADGE_SIZE, BADGE_SIZE, 0.0F, 0.0F, 1.0F, 1.0F);
    }

    public static int tabBadgeWidth() {
        return BADGE_SIZE + BADGE_GAP;
    }

    private static void drawTexturedQuad(
            Matrix4f pose,
            class_4588 consumer,
            float x,
            float y,
            float width,
            float height,
            int lightCoords
    ) {
        float x2 = x + width;
        float y2 = y + height;

        consumer.method_22918(pose, x, y2, 0).method_1336(255, 255, 255, 255).method_22913(0.0F, 1.0F).method_22916(lightCoords).method_22914(0.0F, 0.0F, 1.0F).method_1344();
        consumer.method_22918(pose, x2, y2, 0).method_1336(255, 255, 255, 255).method_22913(1.0F, 1.0F).method_22916(lightCoords).method_22914(0.0F, 0.0F, 1.0F).method_1344();
        consumer.method_22918(pose, x2, y, 0).method_1336(255, 255, 255, 255).method_22913(1.0F, 0.0F).method_22916(lightCoords).method_22914(0.0F, 0.0F, 1.0F).method_1344();
        consumer.method_22918(pose, x, y, 0).method_1336(255, 255, 255, 255).method_22913(0.0F, 0.0F).method_22916(lightCoords).method_22914(0.0F, 0.0F, 1.0F).method_1344();
    }
}

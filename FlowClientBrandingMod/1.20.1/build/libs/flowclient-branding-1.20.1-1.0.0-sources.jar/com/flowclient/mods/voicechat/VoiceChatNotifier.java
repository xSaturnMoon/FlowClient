package com.flowclient.mods.voicechat;

import net.minecraft.class_2561;
import net.minecraft.class_310;

final class VoiceChatNotifier {
    private VoiceChatNotifier() {}

    static void showToggleResult(boolean enabled, boolean success, String error) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) {
            return;
        }

        if (!success) {
            client.field_1724.method_43496(
                    class_2561.method_43470("Simple Voice Chat: failed to update — " + (error == null ? "unknown error" : error)));
            return;
        }

        if (enabled) {
            client.field_1724.method_43496(class_2561.method_43470("Simple Voice Chat enabled."));
        } else {
            client.field_1724.method_43496(class_2561.method_43470("Simple Voice Chat disabled. Microphone released."));
        }
    }
}

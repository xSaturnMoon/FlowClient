package com.flowclient.mods.tooltip;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_5632;

public record ShulkerBoxTooltip(List<class_1799> contents) implements class_5632 {
}

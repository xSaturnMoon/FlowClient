package com.flowclient.mods.inventory;

import com.flowclient.FlowClientKeyCategories;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class InventorySortKeys {
    public static final String SORT_KEY = "key.flowclient.inventory_sort";

    private static final class_304 SORT = new class_304(
            SORT_KEY,
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_R,
            FlowClientKeyCategories.FLOWCLIENT
    );

    private InventorySortKeys() {
    }

    public static void register() {
        KeyBindingHelper.registerKeyBinding(SORT);
        ClientTickEvents.END_CLIENT_TICK.register(InventorySortKeys::tick);
    }

    private static void tick(class_310 client) {
        InventorySortExecutor.tick(client);

        if (!InventorySortMod.isEnabled() || client.field_1724 == null) {
            return;
        }

        while (SORT.method_1436()) {
            InventorySortExecutor.requestSort(client);
        }
    }
}

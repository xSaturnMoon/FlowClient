package com.flowclient.mods.fullbright;

import com.flowclient.FlowClientKeyCategories;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;

public final class FullbrightKeys {
    public static final String FULLBRIGHT_KEY = "key.flowclient.fullbright";

    private static final class_304 TOGGLE = new class_304(
            FULLBRIGHT_KEY,
            GLFW.GLFW_KEY_B,
            FlowClientKeyCategories.FLOWCLIENT
    );

    private FullbrightKeys() {
    }

    public static void register() {
        KeyBindingHelper.registerKeyBinding(TOGGLE);
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1724 == null || client.field_1687 == null) {
                return;
            }
            if (client.field_1755 != null) {
                return;
            }
            while (TOGGLE.method_1436()) {
                FullbrightMod.toggle();
            }
            if (FullbrightMod.isEnabled()) {
                FullbrightController.apply(client);
            }
        });
    }
}

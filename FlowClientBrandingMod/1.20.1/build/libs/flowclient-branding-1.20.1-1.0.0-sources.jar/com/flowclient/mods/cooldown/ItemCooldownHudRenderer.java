package com.flowclient.mods.cooldown;

import com.flowclient.mods.hud.HudElement;
import com.flowclient.mods.hud.HudLayoutManager;
import com.flowclient.mods.hud.HudRenderHelper;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import com.flowclient.compat.FlowArgb;

public final class ItemCooldownHudRenderer {
    private static final int BAR_HEIGHT = 6;
    private static final int ROW_GAP = 4;
    private static final int PADDING = 4;

    private ItemCooldownHudRenderer() {
    }

    public static int getWidth(class_327 font) {
        return getWidth(font, ItemCooldownHudSettings.get(), true, true);
    }

    public static int getHeight(class_327 font) {
        return getHeight(font, ItemCooldownHudSettings.get(), true, true);
    }

    public static int getWidth(class_327 font, ItemCooldownHudSettings settings, boolean showAttack, boolean showItem) {
        return settings.barWidth() + PADDING * 2;
    }

    public static int getHeight(class_327 font, ItemCooldownHudSettings settings, boolean showAttack, boolean showItem) {
        int rows = 0;
        if (showAttack && settings.showAttackCooldown()) {
            rows++;
        }
        if (showItem && settings.showItemCooldown()) {
            rows++;
        }
        if (rows == 0) {
            rows = 1;
        }
        return PADDING * 2 + rows * BAR_HEIGHT + Math.max(0, rows - 1) * ROW_GAP;
    }

    public static void render(class_310 mc, class_332 graphics, class_327 font) {
        render(mc, graphics, font, false);
    }

    public static void render(class_310 mc, class_332 graphics, class_327 font, boolean preview) {
        if (!preview && !ItemCooldownHudMod.isEnabled()) {
            return;
        }

        class_1657 player = mc.field_1724;
        if (!preview && player == null) {
            return;
        }

        float partialTick = mc.method_1488();
        float attackReady = preview ? 0.45f : player.method_7261(partialTick);
        class_1799 mainHand = preview || player == null ? class_1799.field_8037 : player.method_6047();
        float itemCooldown = preview ? 0.35f : (mainHand.method_7960()
                ? 0.0f
                : player.method_7357().method_7905(mainHand.method_7909(), partialTick));

        ItemCooldownHudSettings settings = ItemCooldownHudSettings.get();
        boolean showAttack = settings.showAttackCooldown() && (preview || attackReady < 1.0f);
        boolean showItem = settings.showItemCooldown() && (preview || itemCooldown > 0.0f);
        if (!preview && !showAttack && !showItem) {
            return;
        }

        int width = getWidth(font, settings, showAttack || preview, showItem || preview);
        int height = getHeight(font, settings, showAttack || preview, showItem || preview);
        int x = HudLayoutManager.get().resolveX(HudElement.ITEM_COOLDOWN_HUD, width, height);
        int y = HudLayoutManager.get().resolveY(HudElement.ITEM_COOLDOWN_HUD, width, height);
        float scale = HudLayoutManager.get().resolveScale(HudElement.ITEM_COOLDOWN_HUD);

        HudRenderHelper.withLayout(graphics, x, y, scale, () -> {
            if (settings.showBackground()) {
                int alpha = (settings.backgroundOpacity() * 255) / 100;
                graphics.method_25294(x, y, x + width, y + height, FlowArgb.color(alpha, 8, 8, 12));
            }

            int barX = x + PADDING;
            int barY = y + PADDING;
            int barWidth = settings.barWidth();

            if (showAttack || preview) {
                drawBar(graphics, barX, barY, barWidth, preview ? 0.45f : attackReady, 0xFF55AAFF);
                barY += BAR_HEIGHT + ROW_GAP;
            }

            if (showItem || preview) {
                float fill = preview ? 0.35f : (1.0f - itemCooldown);
                drawBar(graphics, barX, barY, barWidth, fill, 0xFFFFAA55);
            }
        });
    }

    private static void drawBar(class_332 graphics, int x, int y, int width, float fill, int color) {
        graphics.method_25294(x, y, x + width, y + BAR_HEIGHT, FlowArgb.color(255, 30, 30, 30));
        int filled = Math.max(1, (int) (width * Math.max(0.0f, Math.min(1.0f, fill))));
        graphics.method_25294(x, y, x + filled, y + BAR_HEIGHT, color);
        graphics.method_25294(x, y, x + width, y + 1, FlowArgb.color(255, 0, 0, 0));
        graphics.method_25294(x, y + BAR_HEIGHT - 1, x + width, y + BAR_HEIGHT, FlowArgb.color(255, 0, 0, 0));
    }
}

package com.flowclient.mods.reach;

import net.minecraft.class_310;

public final class ReachRingRenderer {
    private ReachRingRenderer() {
    }

    public static boolean shouldRender() {
        return ReachRingMod.isEnabled();
    }

    public static void render(class_310 client) {
    }
}

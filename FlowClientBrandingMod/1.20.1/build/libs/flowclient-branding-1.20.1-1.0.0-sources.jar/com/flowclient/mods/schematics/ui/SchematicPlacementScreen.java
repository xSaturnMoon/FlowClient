package com.flowclient.mods.schematics.ui;

import com.flowclient.compat.FlowGfx;

import com.flowclient.modpanel.ModPanelScreen;
import com.flowclient.mods.schematics.AutoBuilder;
import com.flowclient.mods.schematics.PlacementManager;
import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class SchematicPlacementScreen extends ModPanelScreen {
    private static final class_2561 TITLE = class_2561.method_43470("Schematic Placement");
    private static final int ROW_HEIGHT = 22;

    private int scrollOffset;

    public SchematicPlacementScreen(class_437 parent) {
        super(TITLE, parent);
    }

    @Override
    protected void method_25426() {
        if (!PlacementManager.hasPlacement()) {
            this.field_22787.method_1507(parent);
            return;
        }
        this.method_41843();
    }

    @Override
    protected void initPanel() {
        int frameX = this.frameX();
        int frameY = this.frameY();
        int frameWidth = this.frameWidth();
        int y = frameY + 8 - this.scrollOffset;
        int rowWidth = frameWidth - 16;

        y = this.addRow(frameX, y, rowWidth, "Move X -", () -> PlacementManager.nudge(-1, 0, 0));
        y = this.addRow(frameX, y, rowWidth, "Move X +", () -> PlacementManager.nudge(1, 0, 0));
        y = this.addRow(frameX, y, rowWidth, "Move Y -", () -> PlacementManager.nudge(0, -1, 0));
        y = this.addRow(frameX, y, rowWidth, "Move Y +", () -> PlacementManager.nudge(0, 1, 0));
        y = this.addRow(frameX, y, rowWidth, "Move Z -", () -> PlacementManager.nudge(0, 0, -1));
        y = this.addRow(frameX, y, rowWidth, "Move Z +", () -> PlacementManager.nudge(0, 0, 1));

        y = this.addRow(frameX, y, rowWidth, "Rotate Clockwise", () ->
                PlacementManager.getTransform().rotateClockwise());
        y = this.addRow(frameX, y, rowWidth, "Rotate Counter-Clockwise", () ->
                PlacementManager.getTransform().rotateCounterClockwise());
        y = this.addRow(frameX, y, rowWidth, "Toggle Mirror", () ->
                PlacementManager.getTransform().toggleMirror());

        y = this.addRow(frameX, y, rowWidth, "Set Anchor To Player", () -> {
            if (this.field_22787.field_1724 != null) {
                PlacementManager.setAnchor(this.field_22787.field_1724.method_24515());
            }
        });

        y = this.addRow(frameX, y, rowWidth, "Clear Placement", () -> {
            PlacementManager.clear();
            this.field_22787.method_1507(null);
        });

        if (this.field_22787.field_1724 != null && this.field_22787.field_1724.method_7337()) {
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470("AutoBuild"),
                    button -> AutoBuilder.build(this.field_22787)
            ).method_46434(frameX + 8, frameY + this.frameHeight() - BUTTON_HEIGHT - 40, rowWidth, BUTTON_HEIGHT).method_46431());
        }

        this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Done"),
                button -> {
                    if (this.parent != null) {
                        this.field_22787.method_1507(this.parent);
                    } else {
                        this.field_22787.method_1507(null);
                    }
                }
        ).method_46434(this.centerX(BUTTON_WIDTH), this.field_22790 - 32, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
    }

    private int addRow(int frameX, int y, int rowWidth, String label, Runnable action) {
        if (y + ROW_HEIGHT >= this.frameY() && y <= this.frameY() + this.frameHeight()) {
            this.method_37063(class_4185.method_46430(
                    class_2561.method_43470(label),
                    button -> {
                        action.run();
                        this.method_41843();
                    }
            ).method_46434(frameX + 8, y, rowWidth, ROW_HEIGHT).method_46431());
        }
        return y + ROW_HEIGHT + 2;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollDelta) {
        if (this.isHoveringFrame(mouseX, mouseY)) {
            this.scrollOffset = (int) Math.max(0, this.scrollOffset - scrollDelta * 16);
            this.method_41843();
            return true;
        }
        return super.method_25401(mouseX, mouseY, scrollDelta);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        this.drawContentFrame(graphics, this.frameX(), this.frameY(), this.frameWidth(), this.frameHeight());

        class_2338 anchor = PlacementManager.getAnchor();
        var transform = PlacementManager.getTransform();
        int infoY = this.frameY() + 8;
        FlowGfx.text(graphics, this.field_22793, class_2561.method_43470("Anchor: " + anchor.method_23854()), this.frameX() + 8, infoY, 0xFFCCCCCC, false);
        FlowGfx.text(graphics, this.field_22793, class_2561.method_43470("Offset: "
                + transform.getOffsetX() + ", "
                + transform.getOffsetY() + ", "
                + transform.getOffsetZ()), this.frameX() + 8, infoY + 12, 0xFFAAAAAA, false);
        FlowGfx.text(graphics, this.field_22793, class_2561.method_43470("Rotation: " + labelRotation(transform.getRotation())
                + "  Mirror: " + labelMirror(transform.getMirror())), this.frameX() + 8, infoY + 24, 0xFFAAAAAA, false);

        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    private static String labelRotation(class_2470 rotation) {
        return switch (rotation) {
            case field_11463 -> "90°";
            case field_11464 -> "180°";
            case field_11465 -> "270°";
            default -> "0°";
        };
    }

    private static String labelMirror(class_2415 mirror) {
        return mirror == class_2415.field_11302 ? "Off" : "On";
    }

    private boolean isHoveringFrame(double mouseX, double mouseY) {
        return mouseX >= this.frameX()
                && mouseX <= this.frameX() + this.frameWidth()
                && mouseY >= this.frameY()
                && mouseY <= this.frameY() + this.frameHeight();
    }

    private int frameWidth() {
        return Math.min(this.field_22789 - 40, 360);
    }

    private int frameHeight() {
        return Math.min(this.field_22790 - 80, 300);
    }

    private int frameX() {
        return this.centerX(this.frameWidth());
    }

    private int frameY() {
        return 40;
    }
}

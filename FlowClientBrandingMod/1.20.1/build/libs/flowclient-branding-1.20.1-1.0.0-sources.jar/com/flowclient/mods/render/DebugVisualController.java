package com.flowclient.mods.render;

import net.minecraft.class_310;

public final class DebugVisualController {
    private DebugVisualController() {
    }

    public static void tick(class_310 client) {
    }
}

package com.flowclient.mods.schematics.parser;

import com.flowclient.compat.NbtCompat;

import com.flowclient.mods.schematics.model.Schematic;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;

final class SpongeSchemParser {
    private SpongeSchemParser() {}

    static Schematic parse(class_2487 root) {
        class_2487 schematic = SchematicNbt.resolveSchematicTag(root);

        int width = SchematicNbt.readDimension(schematic, "Width");
        int height = SchematicNbt.readDimension(schematic, "Height");
        int length = SchematicNbt.readDimension(schematic, "Length");
        if (width <= 0 || height <= 0 || length <= 0) {
            return Schematic.empty();
        }

        class_2487 blockSection = resolveBlockSection(schematic);
        class_2487 paletteTag = NbtCompat.getCompoundOrEmpty(blockSection, "Palette");
        if (paletteTag.method_33133()) {
            paletteTag = NbtCompat.getCompoundOrEmpty(schematic, "Palette");
        }

        Map<Integer, class_2680> palette = SchematicLoader.paletteFromSponge(paletteTag);
        if (palette.isEmpty()) {
            return Schematic.empty();
        }

        int expected = width * height * length;
        byte[] blockBytes = readBlockBytes(blockSection, schematic);
        if (blockBytes.length == 0) {
            return Schematic.empty();
        }

        int[] blockData = decodeBlockIndices(blockBytes, expected);
        if (blockData.length == 0) {
            return Schematic.empty();
        }

        Map<class_2338, class_2680> blocks = SchematicLoader.mapFromPaletteInts(
                width, height, length, palette, blockData
        );
        return new Schematic(width, height, length, blocks);
    }

    private static class_2487 resolveBlockSection(class_2487 schematic) {
        if (schematic.method_10545("Blocks")) {
            class_2487 blocks = NbtCompat.getCompoundOrEmpty(schematic, "Blocks");
            if (!blocks.method_33133()) {
                return blocks;
            }
        }
        return schematic;
    }

    private static byte[] readBlockBytes(class_2487 blockSection, class_2487 schematic) {
        byte[] data = NbtCompat.getByteArrayOrEmpty(blockSection, "Data");
        if (data.length > 0) {
            return data;
        }

        data = NbtCompat.getByteArrayOrEmpty(blockSection, "BlockData");
        if (data.length > 0) {
            return data;
        }

        return NbtCompat.getByteArrayOrEmpty(schematic, "BlockData");
    }

    private static int[] decodeBlockIndices(byte[] bytes, int expected) {
        List<Integer> values = new ArrayList<>(Math.min(expected, bytes.length));
        VarIntIterator iterator = new VarIntIterator(bytes);
        while (iterator.hasNext() && values.size() < expected) {
            values.add(iterator.nextInt());
        }

        if (values.isEmpty()) {
            return new int[0];
        }

        int[] out = new int[values.size()];
        for (int i = 0; i < values.size(); i++) {
            out[i] = values.get(i);
        }
        return out;
    }
}

package com.flowclient.mods.immersion;

import net.minecraft.class_310;

public final class TrajectoryArcRenderer {
    private TrajectoryArcRenderer() {
    }

    public static void render(class_310 client) {
    }
}

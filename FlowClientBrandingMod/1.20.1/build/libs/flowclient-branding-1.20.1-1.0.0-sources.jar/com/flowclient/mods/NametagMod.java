package com.flowclient.mods;

import net.minecraft.class_1309;
import net.minecraft.class_1657;

public final class NametagMod {
    private static boolean enabled;

    private NametagMod() {
    }

    public static boolean isEnabled() {
        return enabled;
    }

    public static void setEnabled(boolean value) {
        setEnabled(value, true);
    }

    static void setEnabled(boolean value, boolean persist) {
        enabled = value;
        if (persist) {
            FlowModConfig.save();
        }
    }

    public static void toggle() {
        setEnabled(!enabled);
    }

    public static boolean shouldForceNametag(class_1309 entity) {
        if (!enabled || !(entity instanceof class_1657)) {
            return false;
        }

        var client = net.minecraft.class_310.method_1551();
        return client.field_1724 == null || !entity.method_5756(client.field_1724);
    }
}

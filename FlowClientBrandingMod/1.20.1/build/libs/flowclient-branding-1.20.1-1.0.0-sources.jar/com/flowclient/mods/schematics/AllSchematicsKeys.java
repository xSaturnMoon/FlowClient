package com.flowclient.mods.schematics;

import com.flowclient.mods.schematics.ui.SchematicBrowserScreen;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class AllSchematicsKeys {
    public static final String MENU_KEY = "key.flowclient.all_schematics_menu";

    private static final class_304 MENU = new class_304(
            MENU_KEY,
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_COMMA,
            com.flowclient.FlowClientKeyCategories.FLOWCLIENT
    );

    private AllSchematicsKeys() {}

    public static void register() {
        KeyBindingHelper.registerKeyBinding(MENU);
        ClientTickEvents.END_CLIENT_TICK.register(AllSchematicsKeys::tick);
    }

    public static boolean isMenuKey(int key, int scancode, int action, int modifiers) {
        if (action != GLFW.GLFW_PRESS) {
            return false;
        }
        return MENU.method_1417(key, scancode);
    }

    public static void onMenuKeyPressed() {
        tryOpenMenu(class_310.method_1551());
    }

    private static void tick(class_310 client) {
        if (!AllSchematicsMod.isEnabled() || client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        while (MENU.method_1436()) {
            tryOpenMenu(client);
        }
    }

    private static void tryOpenMenu(class_310 client) {
        if (client.field_1755 != null) {
            return;
        }
        client.method_1507(new SchematicBrowserScreen(null));
    }
}

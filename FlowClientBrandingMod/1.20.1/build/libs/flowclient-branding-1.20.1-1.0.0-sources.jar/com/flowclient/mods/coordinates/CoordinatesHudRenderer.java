package com.flowclient.mods.coordinates;

import com.flowclient.compat.FlowGfx;

import com.flowclient.mods.hud.HudElement;
import com.flowclient.mods.hud.HudLayoutManager;
import com.flowclient.mods.hud.HudRenderHelper;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import com.flowclient.compat.FlowArgb;

public final class CoordinatesHudRenderer {
    private CoordinatesHudRenderer() {
    }

    public static int getWidth(class_327 font) {
        return getWidth(font, CoordinatesHudSettings.get(), "XYZ 123 64 -456 · NORTH");
    }

    public static int getHeight(class_327 font) {
        return getHeight(font, CoordinatesHudSettings.get());
    }

    public static int getWidth(class_327 font, CoordinatesHudSettings settings, String text) {
        return font.method_1727(text) + settings.paddingX() * 2;
    }

    public static int getHeight(class_327 font, CoordinatesHudSettings settings) {
        return font.field_2000 + settings.paddingY() * 2;
    }

    public static void render(class_310 mc, class_332 graphics, class_327 font) {
        render(mc, graphics, font, false);
    }

    public static void render(class_310 mc, class_332 graphics, class_327 font, boolean preview) {
        if (!preview && !CoordinatesHudMod.isEnabled()) {
            return;
        }

        if (!preview && mc.field_1724 == null) {
            return;
        }

        CoordinatesHudSettings settings = CoordinatesHudSettings.get();
        String text = preview
                ? settings.format(123, 64, -456, net.minecraft.class_2350.field_11043)
                : formatLive(mc, settings);
        int width = getWidth(font, settings, text);
        int height = getHeight(font, settings);
        int x = HudLayoutManager.get().resolveX(HudElement.COORDINATES_HUD, width, height);
        int y = HudLayoutManager.get().resolveY(HudElement.COORDINATES_HUD, width, height);
        float scale = HudLayoutManager.get().resolveScale(HudElement.COORDINATES_HUD);

        HudRenderHelper.withLayout(graphics, x, y, scale, () -> {
            if (settings.showBackground()) {
                int alpha = (settings.backgroundOpacity() * 255) / 100;
                graphics.method_25294(x, y, x + width, y + height, FlowArgb.color(alpha, 8, 8, 12));
            }
            FlowGfx.text(graphics, 
                    font,
                    text,
                    x + settings.paddingX(),
                    y + settings.paddingY(),
                    0xFFE0E6F0,
                    settings.textShadow()
            );
        });
    }

    private static String formatLive(class_310 mc, CoordinatesHudSettings settings) {
        class_2338 pos = mc.field_1724.method_24515();
        return settings.format(pos.method_10263(), pos.method_10264(), pos.method_10260(), mc.field_1724.method_5735());
    }
}

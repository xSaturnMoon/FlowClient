package com.flowclient.mods.preview;

import net.minecraft.class_243;

public final class GizmoShapes {
    private GizmoShapes() {
    }

    public static void horizontalCircle(class_243 center, double radius, int color, float lineWidth) {
    }

    public static void wireframeSphere(class_243 center, double radius, int color, float lineWidth) {
    }

    public static void landingCross(class_243 landing, int color, float lineWidth) {
    }
}

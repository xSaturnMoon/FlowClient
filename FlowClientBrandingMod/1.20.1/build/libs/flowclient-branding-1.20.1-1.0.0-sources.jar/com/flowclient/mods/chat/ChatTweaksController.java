package com.flowclient.mods.chat;

import net.minecraft.class_310;

public final class ChatTweaksController {
    private static Double savedChatOpacity;
    private static Double savedChatScale;

    private ChatTweaksController() {
    }

    public static void tick(class_310 client) {
        if (client == null || client.field_1690 == null || !ChatTweaksMod.isEnabled()) {
            return;
        }

        ChatTweaksSettings settings = ChatTweaksSettings.get();
        if (savedChatOpacity == null) {
            savedChatOpacity = client.field_1690.method_42542().method_41753();
        }
        if (savedChatScale == null) {
            savedChatScale = client.field_1690.method_42554().method_41753();
        }

        client.field_1690.method_42542().method_41748(settings.backgroundOpacity() / 100.0D);
        client.field_1690.method_42554().method_41748(settings.chatScalePercent() / 100.0D);
    }

    public static void onDisabled() {
        class_310 client = class_310.method_1551();
        if (client != null && client.field_1690 != null) {
            if (savedChatOpacity != null) {
                client.field_1690.method_42542().method_41748(savedChatOpacity);
            }
            if (savedChatScale != null) {
                client.field_1690.method_42554().method_41748(savedChatScale);
            }
        }
        savedChatOpacity = null;
        savedChatScale = null;
    }
}

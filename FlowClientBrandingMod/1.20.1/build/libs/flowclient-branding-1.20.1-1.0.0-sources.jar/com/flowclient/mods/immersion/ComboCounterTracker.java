package com.flowclient.mods.immersion;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public final class ComboCounterTracker {
    private static final long COMBO_WINDOW_MS = 2200L;
    private static final Map<Integer, Float> LAST_HEALTH = new HashMap<>();

    private static int combo;
    private static long lastHitMs;
    private static float pulse;

    private ComboCounterTracker() {
    }

    public static void reset() {
        LAST_HEALTH.clear();
        combo = 0;
        lastHitMs = 0L;
        pulse = 0.0F;
    }

    public static int combo() {
        return combo;
    }

    public static float pulse() {
        return pulse;
    }

    public static void tick(class_310 client) {
        if (!ComboCounterMod.isEnabled() || client == null || client.field_1687 == null || client.field_1724 == null) {
            LAST_HEALTH.clear();
            return;
        }

        long now = System.currentTimeMillis();
        if (combo > 0 && now - lastHitMs > COMBO_WINDOW_MS) {
            combo = 0;
        }
        if (pulse > 0.0F) {
            pulse = Math.max(0.0F, pulse - 0.08F);
        }

        class_1657 player = client.field_1724;
        for (class_1309 entity : client.field_1687.method_18467(class_1309.class, player.method_5829().method_1014(48.0D))) {
            if (entity == player || !entity.method_5805()) {
                continue;
            }

            int id = entity.method_5628();
            float health = entity.method_6032();
            Float previous = LAST_HEALTH.get(id);
            if (previous != null) {
                float delta = previous - health;
                if (delta > 0.05F && entity.method_6065() == player) {
                    registerHit(now);
                }
            }
            LAST_HEALTH.put(id, health);
        }
    }

    private static void registerHit(long now) {
        if (now - lastHitMs <= COMBO_WINDOW_MS) {
            combo++;
        } else {
            combo = 1;
        }
        lastHitMs = now;
        pulse = 1.0F;
    }
}

package com.flowclient.mods.pearl;

import net.minecraft.class_310;

public final class PearlLandingMarkerRenderer {
    private PearlLandingMarkerRenderer() {
    }

    public static boolean shouldRender() {
        return PearlLandingMarkerMod.isEnabled();
    }

    public static void render(class_310 client) {
    }
}

package com.flowclient.mods.tooltip;

import java.util.List;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2480;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

public final class ShulkerTooltipHelper {
    private ShulkerTooltipHelper() {
    }

    public static boolean isShulkerBox(class_1799 stack) {
        if (stack.method_7960() || !(stack.method_7909() instanceof class_1747 blockItem)) {
            return false;
        }
        return blockItem.method_7711() instanceof class_2480;
    }

    public static List<class_1799> readContents(class_1799 stack) {
        class_2487 tag = stack.method_7969();
        if (tag == null || !tag.method_10573("BlockEntityTag", class_2520.field_33260)) {
            return null;
        }

        class_2487 blockEntityTag = tag.method_10562("BlockEntityTag");
        if (!blockEntityTag.method_10573("Items", class_2520.field_33259)) {
            return null;
        }

        class_2499 items = blockEntityTag.method_10554("Items", class_2520.field_33260);
        if (items.isEmpty()) {
            return null;
        }

        List<class_1799> contents = new java.util.ArrayList<>(items.size());
        for (int i = 0; i < items.size(); i++) {
            class_1799 entry = class_1799.method_7915(items.method_10602(i));
            if (!entry.method_7960()) {
                contents.add(entry);
            }
        }

        return contents.isEmpty() ? null : contents;
    }
}

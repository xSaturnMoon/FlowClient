package com.flowclient.mods.inventory;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_465;
import net.minecraft.class_636;
import net.minecraft.class_746;

public final class InventorySortExecutor {
    private static final List<Runnable> ACTIONS = new ArrayList<>();

    private InventorySortExecutor() {
    }

    public static boolean isRunning() {
        return !ACTIONS.isEmpty();
    }

    public static void cancel() {
        ACTIONS.clear();
    }

    public static void requestSort(class_310 client) {
        if (!InventorySortMod.isEnabled() || client.field_1724 == null || client.field_1761 == null) {
            return;
        }

        if (!(client.field_1755 instanceof class_465<?>)) {
            return;
        }

        class_1703 menu = client.field_1724.field_7512;
        List<Integer> slots = collectSortableSlots(menu, client.field_1724.method_31548());
        if (slots.size() < 2) {
            return;
        }

        ACTIONS.clear();
        if (!menu.method_34255().method_7960()) {
            ACTIONS.add(() -> click(client, class_1703.field_30730, 0, class_1713.field_7790));
        }

        if (InventorySortSettings.get().mergeStacks()) {
            for (int slot : slots) {
                class_1799 stack = menu.method_7611(slot).method_7677();
                if (stack.method_7960() || stack.method_7947() >= stack.method_7914()) {
                    continue;
                }
                int menuSlot = slot;
                ACTIONS.add(() -> click(client, menuSlot, 0, class_1713.field_7794));
            }
        }

        for (int i = 0; i < slots.size(); i++) {
            int best = i;
            for (int j = i + 1; j < slots.size(); j++) {
                if (compareStacks(menu.method_7611(slots.get(j)).method_7677(), menu.method_7611(slots.get(best)).method_7677()) < 0) {
                    best = j;
                }
            }
            if (best != i) {
                int slotA = slots.get(i);
                int slotB = slots.get(best);
                ACTIONS.add(() -> swapSlots(client, slotA, slotB));
                slots.set(i, slotB);
                slots.set(best, slotA);
            }
        }
    }

    public static void tick(class_310 client) {
        if (ACTIONS.isEmpty() || client.field_1724 == null || client.field_1761 == null) {
            ACTIONS.clear();
            return;
        }

        if (!(client.field_1755 instanceof class_465<?>)) {
            ACTIONS.clear();
            return;
        }

        ACTIONS.remove(0).run();
    }

    private static List<Integer> collectSortableSlots(class_1703 menu, class_1661 inventory) {
        List<Integer> slots = new ArrayList<>();
        InventorySortSettings settings = InventorySortSettings.get();

        for (int menuIndex = 0; menuIndex < menu.field_7761.size(); menuIndex++) {
            class_1735 slot = menu.method_7611(menuIndex);
            if (slot.field_7871 != inventory) {
                continue;
            }

            int containerSlot = slot.method_34266();
            boolean hotbar = containerSlot >= 0 && containerSlot < class_1661.method_7368();
            boolean main = containerSlot >= class_1661.method_7368() && containerSlot < 36;
            if (hotbar && !settings.includeHotbar()) {
                continue;
            }
            if (!hotbar && !main) {
                continue;
            }

            slots.add(menuIndex);
        }

        slots.sort(Integer::compareTo);
        return slots;
    }

    private static void swapSlots(class_310 client, int slotA, int slotB) {
        if (slotA == slotB) {
            return;
        }
        click(client, slotA, 0, class_1713.field_7790);
        click(client, slotB, 0, class_1713.field_7790);
        click(client, slotA, 0, class_1713.field_7790);
    }

    private static void click(class_310 client, int slot, int button, class_1713 clickType) {
        class_636 mode = client.field_1761;
        class_746 player = client.field_1724;
        if (mode == null || player == null) {
            return;
        }
        mode.method_2906(player.field_7512.field_7763, slot, button, clickType, player);
    }

    private static int compareStacks(class_1799 left, class_1799 right) {
        if (left.method_7960() && right.method_7960()) {
            return 0;
        }
        if (left.method_7960()) {
            return 1;
        }
        if (right.method_7960()) {
            return -1;
        }

        Comparator<class_1799> comparator = Comparator
                .comparing((class_1799 stack) -> stack.method_7909().method_7876())
                .thenComparing(class_1799::method_7947, Comparator.reverseOrder());
        return comparator.compare(left, right);
    }
}

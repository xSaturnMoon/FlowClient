package com.flowclient.mods.schematics.model;

import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_2470;

public final class PlacementTransform {
    private int offsetX;
    private int offsetY;
    private int offsetZ;
    private class_2470 rotation = class_2470.field_11467;
    private class_2415 mirror = class_2415.field_11302;

    public int getOffsetX() {
        return offsetX;
    }

    public void setOffsetX(int offsetX) {
        this.offsetX = offsetX;
    }

    public int getOffsetY() {
        return offsetY;
    }

    public void setOffsetY(int offsetY) {
        this.offsetY = offsetY;
    }

    public int getOffsetZ() {
        return offsetZ;
    }

    public void setOffsetZ(int offsetZ) {
        this.offsetZ = offsetZ;
    }

    public class_2470 getRotation() {
        return rotation;
    }

    public void setRotation(class_2470 rotation) {
        this.rotation = rotation == null ? class_2470.field_11467 : rotation;
    }

    public class_2415 getMirror() {
        return mirror;
    }

    public void setMirror(class_2415 mirror) {
        this.mirror = mirror == null ? class_2415.field_11302 : mirror;
    }

    public void rotateClockwise() {
        rotation = rotation.method_10501(class_2470.field_11463);
    }

    public void rotateCounterClockwise() {
        rotation = rotation.method_10501(class_2470.field_11465);
    }

    public void toggleMirror() {
        mirror = mirror == class_2415.field_11302 ? class_2415.field_11301 : class_2415.field_11302;
    }

    public class_2338 transformLocal(class_2338 local, int width, int length) {
        int x = local.method_10263();
        int y = local.method_10264();
        int z = local.method_10260();

        if (mirror != class_2415.field_11302) {
            z = mirror.method_10344(z, length);
        }

        int rotatedX = x;
        int rotatedZ = z;
        switch (rotation) {
            case field_11463 -> {
                rotatedX = length - 1 - z;
                rotatedZ = x;
            }
            case field_11464 -> {
                rotatedX = width - 1 - x;
                rotatedZ = length - 1 - z;
            }
            case field_11465 -> {
                rotatedX = z;
                rotatedZ = width - 1 - x;
            }
            default -> {
            }
        }

        return new class_2338(rotatedX + offsetX, y + offsetY, rotatedZ + offsetZ);
    }
}

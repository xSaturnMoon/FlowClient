package com.flowclient.mods.schematics;

import net.minecraft.class_310;

public final class SchematicRenderer {
    private SchematicRenderer() {}

    public static void render(class_310 client) {
        // World-space schematic preview rendering is not available on 1.20.1.
    }
}

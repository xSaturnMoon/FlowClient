package com.flowclient.mods.immersion;

import net.minecraft.class_310;

public final class ImmersionTickController {
    private ImmersionTickController() {
    }

    public static void tick(class_310 client) {
        PortalFxController.tick();
        ComboCounterTracker.tick(client);

        if (!TrajectoryArcMod.isEnabled() || client == null || client.field_1724 == null || client.field_1687 == null) {
            return;
        }

        TrajectoryArcRenderer.render(client);
    }
}

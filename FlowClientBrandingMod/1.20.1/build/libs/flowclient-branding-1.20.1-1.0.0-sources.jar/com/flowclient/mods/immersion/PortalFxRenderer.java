package com.flowclient.mods.immersion;

import com.flowclient.compat.FlowGfx;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class PortalFxRenderer {
    private PortalFxRenderer() {
    }

    public static void render(class_310 client, class_332 graphics, class_327 font) {
        if (!PortalFxMod.isEnabled() || client.field_1724 == null) {
            return;
        }

        float intensity = PortalFxController.intensity();
        if (intensity <= 0.0F) {
            return;
        }

        int width = client.method_22683().method_4486();
        int height = client.method_22683().method_4502();
        int alpha = (int) (intensity * 170.0F) << 24;

        int tint = switch (PortalFxController.activeEffect()) {
            case NETHER -> alpha | 0x00AA2200;
            case END -> alpha | 0x006B1F8A;
            case OVERWORLD -> alpha | 0x00C8E8FF;
            default -> 0;
        };

        if (tint != 0) {
            graphics.method_25294(0, 0, width, height, tint);
            int edge = (int) (intensity * 90.0F) << 24;
            graphics.method_25294(0, 0, width, 18, edge | 0x00000000);
            graphics.method_25294(0, height - 18, width, height, edge | 0x00000000);
            graphics.method_25294(0, 0, 18, height, edge | 0x00000000);
            graphics.method_25294(width - 18, 0, width, height, edge | 0x00000000);
        }

        if (PortalFxController.showTitle()) {
            String title = switch (PortalFxController.activeEffect()) {
                case NETHER -> "NETHER";
                case END -> "THE END";
                case OVERWORLD -> "OVERWORLD";
                default -> "";
            };
            if (!title.isEmpty()) {
                int textAlpha = (int) (Math.min(1.0F, intensity + 0.25F) * 255.0F) << 24;
                FlowGfx.centeredText(graphics, font, class_2561.method_43470(title), width / 2, height / 2 - 24, textAlpha | 0x00FFFFFF);
            }
        }
    }
}

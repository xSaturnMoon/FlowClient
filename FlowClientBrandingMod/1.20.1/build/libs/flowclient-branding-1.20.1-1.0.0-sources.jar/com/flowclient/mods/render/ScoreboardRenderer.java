package com.flowclient.mods.render;

import com.flowclient.compat.FlowGfx;

import com.flowclient.mods.hud.HudElement;
import com.flowclient.mods.hud.HudLayout;
import com.flowclient.mods.hud.HudLayoutManager;
import com.flowclient.mods.hud.HudRenderHelper;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_266;
import net.minecraft.class_267;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5250;
import net.minecraft.class_5481;
import net.minecraft.class_7417;

public final class ScoreboardRenderer {
    private static final Comparator<class_267> SCORE_DISPLAY_ORDER = Comparator
            .comparingInt(class_267::method_1126)
            .reversed()
            .thenComparing(class_267::method_1129, String.CASE_INSENSITIVE_ORDER);
    private static final int LINE_HEIGHT = 9;
    private static final int HORIZONTAL_PADDING = 3;
    private static final int BORDER_INSET = 2;

    private ScoreboardRenderer() {
    }

    public static int getWidth(class_327 font, boolean preview) {
        DisplayData data = buildDisplayData(class_310.method_1551(), font, preview);
        return data == null ? 80 : data.width();
    }

    public static int getHeight(class_327 font, boolean preview) {
        DisplayData data = buildDisplayData(class_310.method_1551(), font, preview);
        return data == null ? 28 : data.height();
    }

    public static int resolveX(class_310 mc, class_327 font, int width, int height, boolean preview) {
        ScoreboardSettings settings = ScoreboardSettings.get();
        int screenW = mc.method_22683().method_4486();
        return switch (settings.anchor()) {
            case RIGHT -> screenW - width - settings.sideMargin();
            case LEFT -> settings.sideMargin();
            case CUSTOM -> {
                int rawX = HudLayoutManager.get().layout(HudElement.SCOREBOARD).getRawX();
                yield rawX != HudLayout.UNSET ? rawX : screenW - width - settings.sideMargin();
            }
        };
    }

    public static void seedCustomLayoutFromCurrentAnchor() {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.field_1772 == null) {
            return;
        }

        ScoreboardSettings settings = ScoreboardSettings.get();
        class_327 font = mc.field_1772;
        int width = getWidth(font, false);
        int height = getHeight(font, false);
        int screenW = mc.method_22683().method_4486();
        int x = switch (settings.anchor()) {
            case RIGHT -> screenW - width - settings.sideMargin();
            case LEFT -> settings.sideMargin();
            case CUSTOM -> {
                int rawX = HudLayoutManager.get().layout(HudElement.SCOREBOARD).getRawX();
                yield rawX != HudLayout.UNSET ? rawX : screenW - width - settings.sideMargin();
            }
        };
        int y = HudLayoutManager.get().resolveY(HudElement.SCOREBOARD, width, height);
        HudLayoutManager.get().setPositionQuiet(HudElement.SCOREBOARD, x, y);
    }

    public static void render(class_310 mc, class_332 graphics, class_327 font) {
        render(mc, graphics, font, false);
    }

    public static void render(class_310 mc, class_332 graphics, class_327 font, boolean preview) {
        if (!preview && !ScoreboardMod.isEnabled()) {
            return;
        }

        DisplayData data = buildDisplayData(mc, font, preview);
        if (data == null) {
            return;
        }

        int x = resolveX(mc, font, data.width(), data.height(), preview);
        int y = HudLayoutManager.get().resolveY(HudElement.SCOREBOARD, data.width(), data.height());
        float scale = HudLayoutManager.get().resolveScale(HudElement.SCOREBOARD);

        HudRenderHelper.withLayout(graphics, x, y, scale, () -> data.draw(graphics, font, x, y));
    }

    private static DisplayData buildDisplayData(class_310 mc, class_327 font, boolean preview) {
        ScoreboardSettings settings = ScoreboardSettings.get();
        if (preview) {
            return previewData(font, settings);
        }

        class_266 objective = resolveObjective(mc);
        if (objective == null) {
            return null;
        }

        return fromObjective(font, objective, settings);
    }

    private static class_266 resolveObjective(class_310 mc) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return null;
        }

        class_269 scoreboard = mc.field_1687.method_8428();
        class_266 teamObjective = null;
        class_268 playerTeam = scoreboard.method_1164(mc.field_1724.method_5820());
        if (playerTeam != null) {
            class_124 color = playerTeam.method_1202();
            if (color != null && color.method_536() >= 0) {
                teamObjective = scoreboard.method_1189(3 + color.method_536());
            }
        }

        return teamObjective != null ? teamObjective : scoreboard.method_1189(1);
    }

    private static DisplayData previewData(class_327 font, ScoreboardSettings settings) {
        int scoreWidth = settings.hideNumbers() ? 0 : font.method_1727("12");
        DisplayEntry[] entries = {
                new DisplayEntry(
                        class_2561.method_43470("Scoreboard preview"),
                        settings.hideNumbers() ? class_2561.method_43473() : class_2561.method_43470("12"),
                        scoreWidth
                ),
                new DisplayEntry(class_2561.method_43470("Drag in Position Editor"), class_2561.method_43473(), 0)
        };
        return createDisplayData(font, class_2561.method_43470("FlowClient"), entries, settings);
    }

    private static DisplayData fromObjective(class_327 font, class_266 objective, ScoreboardSettings settings) {
        class_269 scoreboard = objective.method_1117();

        DisplayEntry[] entries = scoreboard.method_1184(objective).stream()
                .sorted(SCORE_DISPLAY_ORDER)
                .limit(15L)
                .map(score -> {
                    class_268 team = scoreboard.method_1164(score.method_1129());
                    class_2561 name = trimScoreboardLine(
                            class_268.method_1142(team, class_2561.method_43470(score.method_1129())),
                            settings
                    );
                    if (settings.hideNumbers()) {
                        return new DisplayEntry(name, class_2561.method_43473(), 0);
                    }

                    class_2561 scoreString = class_2561.method_43470(String.valueOf(score.method_1126()));
                    return new DisplayEntry(name, scoreString, font.method_27525(scoreString));
                })
                .toArray(DisplayEntry[]::new);

        if (entries.length == 0) {
            return null;
        }

        class_2561 title = trimScoreboardLine(objective.method_1114(), settings);
        return createDisplayData(font, title, entries, settings);
    }

    private static DisplayData createDisplayData(
            class_327 font,
            class_2561 title,
            DisplayEntry[] entries,
            ScoreboardSettings settings
    ) {
        int titleWidth = lineWidth(font, title, settings);
        int contentWidth = titleWidth;
        int spacerWidth = font.method_1727(": ");

        for (DisplayEntry entry : entries) {
            int lineWidth = lineWidth(font, entry.name(), settings);
            if (!settings.hideNumbers() && entry.scoreWidth() > 0) {
                lineWidth += spacerWidth + entry.scoreWidth();
            }
            contentWidth = Math.max(contentWidth, lineWidth);
        }

        int width = contentWidth + HORIZONTAL_PADDING * 2 + BORDER_INSET * 2;
        int height = entries.length * LINE_HEIGHT + LINE_HEIGHT + 2;
        return new DisplayData(width, height, title, titleWidth, entries, contentWidth, settings);
    }

    private record DisplayEntry(class_2561 name, class_2561 score, int scoreWidth) {
    }

    private record DisplayData(
            int width,
            int height,
            class_2561 title,
            int titleWidth,
            DisplayEntry[] entries,
            int contentWidth,
            ScoreboardSettings settings
    ) {
        void draw(class_332 graphics, class_327 font, int x, int y) {
            int contentLeft = x + BORDER_INSET + HORIZONTAL_PADDING;
            int contentCenterX = contentLeft + this.contentWidth / 2;
            int contentRight = x + this.width - BORDER_INSET - HORIZONTAL_PADDING;
            int bottom = y + this.height;
            int headerY = bottom - this.entries.length * LINE_HEIGHT;

            if (this.settings.backgroundOpacity() > 0) {
                int bodyColor = backgroundArgb(this.settings.backgroundOpacity());
                int headerColor = backgroundArgb(Math.min(100, this.settings.backgroundOpacity() + 15));
                graphics.method_25294(x, headerY - LINE_HEIGHT - 1, x + this.width, headerY - 1, headerColor);
                graphics.method_25294(x, headerY - 1, x + this.width, bottom, bodyColor);
            }

            drawLine(
                    graphics,
                    font,
                    this.title,
                    contentCenterX,
                    headerY - LINE_HEIGHT,
                    this.settings.titleColor().argb(),
                    false,
                    this.settings.centerText()
            );

            for (int i = 0; i < this.entries.length; i++) {
                DisplayEntry entry = this.entries[i];
                int lineY = bottom - (this.entries.length - i) * LINE_HEIGHT;
                boolean useTeamColors = this.settings.useTeamColors();
                int nameColor = useTeamColors ? -1 : this.settings.textColor().argb();
                class_2561 displayName = entry.name();
                if (this.settings.centerText()) {
                    drawLine(graphics, font, displayName, contentCenterX, lineY, nameColor, useTeamColors, true);
                } else {
                    class_5481 seq = displayName.method_30937();
                    FlowGfx.text(graphics, font, seq, contentLeft, lineY, nameColor, false);
                }
                if (!this.settings.hideNumbers() && entry.scoreWidth() > 0) {
                    FlowGfx.text(graphics, 
                            font,
                            entry.score(),
                            contentRight - entry.scoreWidth(),
                            lineY,
                            this.settings.scoreColor().argb(),
                            false
                    );
                }
            }
        }

        private static void drawLine(
                class_332 graphics,
                class_327 font,
                class_2561 text,
                int centerX,
                int y,
                int color,
                boolean preserveStyle,
                boolean centered
        ) {
            class_5481 sequence = text.method_30937();
            int drawX = centered ? centerX - font.method_30880(sequence) / 2 : centerX;
            if (preserveStyle && color == -1) {
                FlowGfx.text(graphics, font, sequence, drawX, y, -1, false);
            } else {
                FlowGfx.text(graphics, font, sequence, drawX, y, color, false);
            }
        }

        private static int backgroundArgb(int opacityPercent) {
            int alpha = (opacityPercent * 255 / 100) << 24;
            return alpha | 0x000000;
        }
    }

    private static int lineWidth(class_327 font, class_2561 text, ScoreboardSettings settings) {
        return font.method_30880(trimScoreboardLine(text, settings).method_30937());
    }

    private static class_2561 trimScoreboardLine(class_2561 component, ScoreboardSettings settings) {
        if (!settings.hideNumbers() && !settings.centerText()) {
            return component;
        }

        class_7417 contents = trimContents(component.method_10851(), settings);
        List<class_2561> siblings = trimSiblings(component.method_10855(), settings);
        if (contents == component.method_10851() && siblings.equals(component.method_10855())) {
            return component;
        }

        class_5250 rebuilt = class_5250.method_43477(contents).method_27696(component.method_10866());
        for (class_2561 sibling : siblings) {
            rebuilt.method_10852(sibling);
        }
        return rebuilt;
    }

    private static List<class_2561> trimSiblings(List<class_2561> siblings, ScoreboardSettings settings) {
        List<class_2561> trimmed = new ArrayList<>(siblings.size());
        for (class_2561 sibling : siblings) {
            trimmed.add(trimScoreboardLine(sibling, settings));
        }

        while (!trimmed.isEmpty() && isBlankComponent(trimmed.get(trimmed.size() - 1))) {
            trimmed.remove(trimmed.size() - 1);
        }

        if (settings.centerText()) {
            while (!trimmed.isEmpty() && isBlankComponent(trimmed.get(0))) {
                trimmed.remove(0);
            }
        }

        return trimmed;
    }

    private static class_7417 trimContents(class_7417 contents, ScoreboardSettings settings) {
        if (contents instanceof class_2585 literal) {
            String text = literal.comp_737();
            String normalized = settings.centerText() ? text.strip() : text.stripTrailing();
            if (normalized.equals(text)) {
                return contents;
            }
            return normalized.isEmpty() ? class_2585.field_39004 : new class_2585(normalized);
        }
        return contents;
    }

    private static boolean isBlankComponent(class_2561 component) {
        return component.getString().isBlank();
    }
}

package com.flowclient.mods.blockspeed;

import net.minecraft.class_243;
import net.minecraft.class_310;

public final class BlockSpeedTracker {
    private static float smoothedValue;
    private static long lastSampleMs;

    private BlockSpeedTracker() {
    }

    public static void tick(class_310 mc) {
        if (!BlockSpeedMod.isEnabled()) {
            return;
        }

        if (mc.field_1724 == null) {
            smoothedValue = 0.0f;
            lastSampleMs = 0L;
            return;
        }

        class_243 motion = mc.field_1724.method_18798();
        float current = horizontalBlocksPerSecond(motion);

        long now = System.currentTimeMillis();
        if (settingsSmoothing()) {
            if (lastSampleMs == 0L) {
                smoothedValue = current;
            } else {
                float alpha = Math.min(1.0f, (now - lastSampleMs) / 150.0f);
                smoothedValue += (current - smoothedValue) * alpha;
            }
        } else {
            smoothedValue = current;
        }
        lastSampleMs = now;
    }

    public static float getBlocksPerSecond() {
        return BlockSpeedMod.isEnabled() ? smoothedValue : 0.0f;
    }

    public static void reset() {
        smoothedValue = 0.0f;
        lastSampleMs = 0L;
    }

    private static float horizontalBlocksPerSecond(class_243 motion) {
        double horizontal = Math.sqrt(motion.field_1352 * motion.field_1352 + motion.field_1350 * motion.field_1350);
        return (float) (horizontal * 20.0D);
    }

    private static boolean settingsSmoothing() {
        return BlockSpeedSettings.get().smoothing();
    }
}

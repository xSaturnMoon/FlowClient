package com.flowclient.mods.schematics.parser;

import com.flowclient.compat.NbtCompat;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.zip.GZIPInputStream;
import net.minecraft.class_2487;
import net.minecraft.class_2505;
import net.minecraft.class_2507;

final class SchematicNbt {
    private SchematicNbt() {}

    static class_2487 readRoot(Path file) throws IOException {
        byte[] raw = Files.readAllBytes(file);
        String lower = file.getFileName().toString().toLowerCase(Locale.ROOT);

        if (lower.endsWith(".schem") || lower.endsWith(".litematic") || lower.endsWith(".nbt")) {
            return readPreferGzip(raw, file);
        }

        class_2487 gzipped = tryReadGzip(raw);
        if (isUsable(gzipped)) {
            return gzipped;
        }

        class_2487 plain = tryReadPlain(raw);
        if (isUsable(plain)) {
            return plain;
        }

        throw new IOException("Unable to read schematic NBT: " + file.getFileName());
    }

    private static class_2487 readPreferGzip(byte[] raw, Path file) throws IOException {
        class_2487 gzipped = tryReadGzip(raw);
        if (isUsable(gzipped)) {
            return gzipped;
        }

        class_2487 plain = tryReadPlain(raw);
        if (isUsable(plain)) {
            return plain;
        }

        throw new IOException("Unable to read compressed schematic NBT: " + file.getFileName());
    }

    static class_2487 resolveSchematicTag(class_2487 root) {
        if (root.method_10545("Schematic")) {
            class_2487 nested = NbtCompat.getCompoundOrEmpty(root, "Schematic");
            if (!nested.method_33133()) {
                return nested;
            }
        }
        return root;
    }

    static int readDimension(class_2487 tag, String key) {
        if (!tag.method_10545(key)) {
            return 0;
        }

        int asInt = NbtCompat.getIntOr(tag, key, -1);
        if (asInt > 0) {
            return asInt;
        }

        int asShort = NbtCompat.getShortOr(tag, key, (short) -1) & 0xFFFF;
        return Math.max(asShort, 0);
    }

    private static boolean isUsable(class_2487 root) {
        return root != null && !root.method_33133();
    }

    private static class_2487 tryReadPlain(byte[] raw) {
        try (DataInputStream input = new DataInputStream(new ByteArrayInputStream(raw))) {
            return class_2507.method_10625(input, new class_2505(0x20000000L));
        } catch (IOException ignored) {
            return null;
        }
    }

    private static class_2487 tryReadGzip(byte[] raw) {
        try (GZIPInputStream gzip = new GZIPInputStream(new ByteArrayInputStream(raw));
             DataInputStream input = new DataInputStream(gzip)) {
            return class_2507.method_10625(input, new class_2505(0x20000000L));
        } catch (IOException ignored) {
            return null;
        }
    }
}

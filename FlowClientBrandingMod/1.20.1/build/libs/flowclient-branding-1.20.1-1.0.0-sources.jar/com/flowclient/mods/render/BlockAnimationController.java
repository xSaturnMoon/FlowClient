package com.flowclient.mods.render;

import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2338;
import net.minecraft.class_2388;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2464;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_5819;
import net.minecraft.class_761;
import net.minecraft.class_776;

public final class BlockAnimationController {
    private static final Map<class_2338, AnimationEntry> ANIMATIONS = new ConcurrentHashMap<>();

    private static final long FALL_DURATION_MS = 180;
    private static final long SETTLE_DURATION_MS = 100;
    private static final double START_HEIGHT = 0.45;

    private BlockAnimationController() {}

    public static void onBlockPlaced(class_2338 pos, class_2680 state) {
        if (!BlockAnimationMod.isEnabled()) return;
        if (state == null || state.method_26215() || state.method_26217() == class_2464.field_11455) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            double distSq = client.field_1724.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5);
            if (distSq > 48.0 * 48.0) return;
        }

        class_2338 immPos = pos.method_10062();
        ANIMATIONS.put(immPos, new AnimationEntry(immPos, state, System.currentTimeMillis()));
    }

    public static boolean isAnimating(class_2338 pos) {
        if (!BlockAnimationMod.isEnabled() || ANIMATIONS.isEmpty()) return false;
        AnimationEntry entry = ANIMATIONS.get(pos);
        return entry != null && !entry.landed;
    }

    public static void render(class_4587 poseStack, class_4184 camera, float partialTick) {
        if (!BlockAnimationMod.isEnabled() || ANIMATIONS.isEmpty()) return;

        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) {
            ANIMATIONS.clear();
            return;
        }

        long now = System.currentTimeMillis();
        class_776 dispatcher = client.method_1541();
        class_4597.class_4598 bufferSource = client.method_22940().method_23000();
        class_243 camPos = camera.method_19326();

        Iterator<Map.Entry<class_2338, AnimationEntry>> it = ANIMATIONS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<class_2338, AnimationEntry> mapEntry = it.next();
            AnimationEntry anim = mapEntry.getValue();

            long elapsed = now - anim.startTime;
            if (!anim.landed && elapsed >= FALL_DURATION_MS) {
                anim.landed = true;
                anim.landedTime = now;
                spawnLandingParticles(client, anim.pos, anim.state);
                if (client.field_1769 != null) {
                    client.field_1769.method_18145(
                        anim.pos.method_10263() >> 4,
                        anim.pos.method_10264() >> 4,
                        anim.pos.method_10260() >> 4
                    );
                }
            }

            if (anim.landed && (now - anim.landedTime > SETTLE_DURATION_MS)) {
                it.remove();
                continue;
            }

            float progress = Math.min(1.0f, (float) elapsed / (float) FALL_DURATION_MS);
            // Ease-in gravitational acceleration
            double eased = progress * progress;
            double yOffset = anim.landed ? 0.0 : (1.0 - eased) * START_HEIGHT;

            poseStack.method_22903();
            poseStack.method_22904(
                anim.pos.method_10263() - camPos.field_1352,
                anim.pos.method_10264() + yOffset - camPos.field_1351,
                anim.pos.method_10260() - camPos.field_1350
            );

            int light = class_761.method_23794(client.field_1687, anim.pos);
            dispatcher.method_3353(anim.state, poseStack, bufferSource, light, class_4608.field_21444);
            poseStack.method_22909();
        }

        bufferSource.method_22993();
    }

    private static void spawnLandingParticles(class_310 client, class_2338 pos, class_2680 state) {
        if (client.field_1687 == null) return;
        class_5819 random = client.field_1687.field_9229;
        class_2388 particleOption = new class_2388(class_2398.field_11217, state);

        for (int i = 0; i < 12; i++) {
            double px = pos.method_10263() + 0.12 + random.method_43058() * 0.76;
            double py = pos.method_10264() + 0.04;
            double pz = pos.method_10260() + 0.12 + random.method_43058() * 0.76;

            double vx = (random.method_43058() - 0.5) * 0.16;
            double vy = random.method_43058() * 0.08 + 0.03;
            double vz = (random.method_43058() - 0.5) * 0.16;

            client.field_1687.method_8406(particleOption, px, py, pz, vx, vy, vz);
        }
    }

    private static final class AnimationEntry {
        final class_2338 pos;
        final class_2680 state;
        final long startTime;
        boolean landed;
        long landedTime;

        AnimationEntry(class_2338 pos, class_2680 state, long startTime) {
            this.pos = pos;
            this.state = state;
            this.startTime = startTime;
        }
    }
}

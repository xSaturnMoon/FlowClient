package com.flowclient.mods.immersion;

import com.flowclient.compat.FlowGfx;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class ComboCounterRenderer {
    private ComboCounterRenderer() {
    }

    public static void render(class_310 client, class_332 graphics, class_327 font) {
        if (!ComboCounterMod.isEnabled() || client.field_1724 == null) {
            return;
        }

        int combo = ComboCounterTracker.combo();
        if (combo < 2) {
            return;
        }

        int centerX = client.method_22683().method_4486() / 2;
        int centerY = client.method_22683().method_4502() / 2 + 18;
        float pulse = ComboCounterTracker.pulse();
        int scale = combo >= 10 ? 2 : combo >= 5 ? 1 : 0;
        String text = combo + "x COMBO";
        int color = (0xFF << 24)
                | (combo >= 10 ? 0xFF5555 : combo >= 5 ? 0xFFAA55 : 0xFFFFFF);
        int glow = ((int) (pulse * 120.0F) << 24) | (color & 0x00FFFFFF);

        graphics.method_51448().method_22903();
        float s = 1.0F + pulse * 0.25F + scale * 0.15F;
        graphics.method_51448().method_22904(centerX, centerY, 0.0D);
        graphics.method_51448().method_22905(s, s, 1.0F);
        graphics.method_51448().method_22904(-centerX, -centerY, 0.0D);

        int x = centerX - font.method_1727(text) / 2;
        FlowGfx.text(graphics, font, class_2561.method_43470(text), x + 1, centerY + 1, glow, true);
        FlowGfx.text(graphics, font, class_2561.method_43470(text), x, centerY, color, true);
        graphics.method_51448().method_22909();
    }
}

package com.flowclient.mods.otherclient;

import com.flowclient.FlowClientMod;
import net.minecraft.class_2960;

public final class FlowEmblem {
    public static final class_2960 TEXTURE = new class_2960(
            FlowClientMod.MOD_ID, "textures/gui/flow_badge_icon.png"
    );

    private FlowEmblem() {}
}

package com.flowclient.mods.schematics.parser;

import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

final class BlockStateReader {
    private BlockStateReader() {}

    static class_2680 parse(String stateString) {
        if (stateString == null || stateString.isBlank()) {
            return class_2246.field_10124.method_9564();
        }

        int bracket = stateString.indexOf('[');
        String blockId = bracket > 0 ? stateString.substring(0, bracket) : stateString;
        class_2960 id = class_2960.method_12829(blockId);
        if (id == null) {
            return class_2246.field_10124.method_9564();
        }
        class_2248 block = class_7923.field_41175.method_17966(id).orElse(class_2246.field_10124);
        return block.method_9564();
    }

    static class_2680 fromPaletteEntry(class_2487 entry) {
        String name = entry.method_10573("Name", net.minecraft.class_2520.field_33258)
                ? entry.method_10558("Name")
                : "minecraft:air";
        if (!entry.method_10573("Properties", net.minecraft.class_2520.field_33260)) {
            return parse(name);
        }

        class_2487 properties = entry.method_10562("Properties");
        StringBuilder state = new StringBuilder(name).append('[');
        boolean first = true;
        for (String key : properties.method_10541()) {
            if (!first) {
                state.append(',');
            }
            state.append(key).append('=').append(properties.method_10558(key));
            first = false;
        }
        state.append(']');
        return parse(state.toString());
    }
}

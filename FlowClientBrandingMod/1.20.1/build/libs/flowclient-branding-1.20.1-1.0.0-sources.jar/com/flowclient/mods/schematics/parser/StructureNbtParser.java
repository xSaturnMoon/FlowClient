package com.flowclient.mods.schematics.parser;

import com.flowclient.compat.NbtCompat;

import com.flowclient.mods.schematics.model.Schematic;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2680;

final class StructureNbtParser {
    private StructureNbtParser() {}

    static Schematic parse(class_2487 root) {
        if (!root.method_10545("size")) {
            return Schematic.empty();
        }
        return parseVanillaStructure(root);
    }

    private static Schematic parseVanillaStructure(class_2487 root) {
        class_2499 sizeList = NbtCompat.getListOrEmpty(root, "size");
        if (sizeList.size() < 3) {
            return Schematic.empty();
        }
        int width = NbtCompat.getIntOr(sizeList, 0, 0);
        int height = NbtCompat.getIntOr(sizeList, 1, 0);
        int length = NbtCompat.getIntOr(sizeList, 2, 0);
        if (width <= 0 || height <= 0 || length <= 0) {
            return Schematic.empty();
        }

        class_2499 paletteList = NbtCompat.getListOrEmpty(root, "palette");
        Map<Integer, class_2680> palette = new HashMap<>();
        for (int i = 0; i < paletteList.size(); i++) {
            class_2487 entry = NbtCompat.getCompoundOrEmpty(paletteList, i);
            palette.put(i, BlockStateReader.fromPaletteEntry(entry));
        }

        class_2499 blocks = NbtCompat.getListOrEmpty(root, "blocks");
        Map<class_2338, class_2680> map = new HashMap<>();
        for (int i = 0; i < blocks.size(); i++) {
            class_2487 block = NbtCompat.getCompoundOrEmpty(blocks, i);
            class_2499 posList = NbtCompat.getListOrEmpty(block, "pos");
            if (posList.size() < 3) {
                continue;
            }
            int stateId = NbtCompat.getIntOr(block, "state", 0);
            class_2680 state = palette.getOrDefault(stateId, class_2246.field_10124.method_9564());
            if (state.method_26215()) {
                continue;
            }
            map.put(new class_2338(
                    NbtCompat.getIntOr(posList, 0, 0),
                    NbtCompat.getIntOr(posList, 1, 0),
                    NbtCompat.getIntOr(posList, 2, 0)
            ), state);
        }
        return new Schematic(width, height, length, map);
    }
}

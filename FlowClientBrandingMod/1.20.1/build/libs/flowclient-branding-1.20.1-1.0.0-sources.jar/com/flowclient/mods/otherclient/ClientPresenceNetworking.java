package com.flowclient.mods.otherclient;

import com.flowclient.FlowClientMod;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.Locale;
import java.util.UUID;

/**
 * Announces FlowClient (and reads announcements from other FlowClient users)
 * when the server also runs the FlowClient relay.
 */
public final class ClientPresenceNetworking {
    public static final class_2960 CHANNEL =
            new class_2960(FlowClientMod.MOD_ID, "client_presence");

    private ClientPresenceNetworking() {}

    public static void registerClient() {
        ClientPlayNetworking.registerGlobalReceiver(CHANNEL, (client, handler, buf, responseSender) -> {
            UUID playerId = buf.method_10790();
            String clientId = buf.method_19772();
            client.execute(() -> {
                DetectedClient detected = DetectedClient.fromClientId(clientId);
                ClientDetector.setNetworkClient(playerId, detected);
            });
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            if (!OtherClientMod.isEnabled()) {
                return;
            }
            if (ClientPlayNetworking.canSend(CHANNEL) && client.field_1724 != null) {
                class_2540 packet = PacketByteBufs.create();
                packet.method_10797(client.field_1724.method_5667());
                packet.method_10814(DetectedClient.FLOWCLIENT.clientId);
                ClientPlayNetworking.send(CHANNEL, packet);
            }
        });
    }

    public static void registerServer() {
        ServerPlayNetworking.registerGlobalReceiver(CHANNEL, (server, player, handler, buf, responseSender) -> {
            UUID playerId = buf.method_10790();
            String clientId = buf.method_19772();
            if (!player.method_5667().equals(playerId)) {
                return;
            }

            String normalized = clientId.toLowerCase(Locale.ROOT);
            for (class_3222 target : server.method_3760().method_14571()) {
                class_2540 packet = PacketByteBufs.create();
                packet.method_10797(player.method_5667());
                packet.method_10814(normalized);
                ServerPlayNetworking.send(target, CHANNEL, packet);
            }
        });
    }
}

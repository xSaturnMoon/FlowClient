package com.flowclient.modpanel;

import com.flowclient.ui.UiSprites;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

public final class ModSettingsIconButton extends class_339 {
    public static final int SIZE = 12;

    private final Runnable onPress;

    public ModSettingsIconButton(int x, int y, Runnable onPress) {
        super(x, y, SIZE, SIZE, class_2561.method_43470("Settings"));
        this.onPress = onPress;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        if (this.method_49606()) {
            graphics.method_25294(this.method_46426(), this.method_46427(), this.method_46426() + SIZE, this.method_46427() + SIZE, ModPanelTheme.BG_HOVER);
        }

        UiSprites.drawIcon(
                graphics,
                UiSprites.IconType.GEAR,
                this.method_46426(),
                this.method_46427(),
                SIZE,
                ModPanelTheme.TEXT
        );
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        method_25354(class_310.method_1551().method_1483());
        this.onPress.run();
    }

    @Override
    protected void method_47399(class_6382 narration) {
        narration.method_37034(net.minecraft.class_6381.field_33788, this.method_25369());
    }
}

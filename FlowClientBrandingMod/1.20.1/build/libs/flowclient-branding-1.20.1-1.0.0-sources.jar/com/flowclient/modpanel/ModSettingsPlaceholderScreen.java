package com.flowclient.modpanel;

import com.flowclient.compat.FlowGfx;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class ModSettingsPlaceholderScreen extends ModPanelScreen {
    public ModSettingsPlaceholderScreen(class_437 parent, String modName) {
        super(class_2561.method_43470(modName + " Settings"), parent, modName);
    }

    @Override
    protected void method_25426() {
        this.initPanel();
    }

    @Override
    protected void initPanel() {
        this.addBackButton();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int frameX = this.frameX();
        int frameWidth = this.frameWidth();
        this.drawModDescription(graphics, frameX, frameWidth);
        this.drawContentFrame(graphics, frameX, this.frameY(), frameWidth, this.frameHeight());
        FlowGfx.text(graphics, 
                this.field_22793,
                class_2561.method_43470("No configurable settings yet for this module."),
                frameX + 12,
                this.frameY() + 12,
                0xFF8E97A6,
                false
        );
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    private int frameWidth() {
        return Math.min(this.field_22789 - 40, 420);
    }

    private int frameHeight() {
        return 96;
    }

    private int frameX() {
        return this.centerX(this.frameWidth());
    }

    private int frameY() {
        return this.contentFrameY(24, this.frameWidth());
    }
}

package com.flowclient.modpanel;

import com.flowclient.compat.FlowGfx;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public abstract class ModPanelScreen extends class_437 {
    protected static final int BUTTON_WIDTH = 200;
    protected static final int BUTTON_HEIGHT = 22;
    private static final int DESCRIPTION_TOP = 30;
    private static final int DESCRIPTION_GAP = 10;
    private static final int HEADER_TITLE_GAP = 4;

    protected final class_437 parent;
    protected final String modDescriptionKey;

    protected ModPanelScreen(class_2561 title, class_437 parent) {
        this(title, parent, null);
    }

    protected ModPanelScreen(class_2561 title, class_437 parent, String modDescriptionKey) {
        super(title);
        this.parent = parent;
        this.modDescriptionKey = modDescriptionKey;
    }

    protected int centerX(int width) {
        return (this.field_22789 - width) / 2;
    }

    protected ModPanelButton panelButton(class_2561 label, int x, int y, int width, Runnable onPress) {
        return new ModPanelButton(x, y, width, BUTTON_HEIGHT, label, onPress, false);
    }

    protected void addBackButton() {
        this.method_37063(panelButton(
                class_2561.method_43470("Back"),
                this.centerX(BUTTON_WIDTH),
                this.field_22790 - 32,
                BUTTON_WIDTH,
                this::goBack
        ));
    }

    protected void goBack() {
        class_437 target = this.parent;
        if (target instanceof ModPanelMenuScreen) {
            target = new ModPanelMenuScreen();
        } else if (target instanceof ModListPanelScreen listParent) {
            target = new ModListPanelScreen(listParent.parent);
        }

        if (target == null) {
            this.field_22787.method_1507(null);
        } else {
            this.field_22787.method_1507(target);
        }
    }

    @Override
    protected void method_25426() {
        this.initPanel();
    }

    protected void method_41843() {
        this.method_37067();
        this.initPanel();
    }

    protected void refreshPanel() {
        this.method_41843();
    }

    protected int settingsFrameTop() {
        return 36;
    }

    protected boolean showsModDescription() {
        return this.modDescriptionKey != null && !this.modDescriptionKey.isBlank();
    }

    protected void initPanel() {
    }

    protected String resolveModDescription() {
        return this.modDescriptionKey == null ? null : ModDescriptions.get(this.modDescriptionKey);
    }

    protected int descriptionBlockHeight(int frameWidth) {
        String description = this.resolveModDescription();
        if (description == null || description.isBlank()) {
            return 0;
        }
        return ModDescriptions.blockHeight(this.field_22793, description, frameWidth - 24)
                + this.field_22793.field_2000
                + HEADER_TITLE_GAP
                + DESCRIPTION_GAP;
    }

    protected int contentFrameY(int baseY, int frameWidth) {
        return baseY + this.descriptionBlockHeight(frameWidth);
    }

    protected void drawModDescription(class_332 graphics, int frameX, int frameWidth) {
        if (!this.showsModDescription()) {
            return;
        }

        String description = this.resolveModDescription();
        if (description == null || description.isBlank()) {
            return;
        }

        int textX = frameX + 12;
        int textWidth = frameWidth - 24;
        int titleY = DESCRIPTION_TOP;
        FlowGfx.text(graphics, this.field_22793, class_2561.method_43470(this.modDescriptionKey), textX, titleY, ModPanelTheme.TEXT);

        int descriptionY = titleY + this.field_22793.field_2000 + HEADER_TITLE_GAP;
        ModDescriptions.draw(graphics, this.field_22793, description, textX, descriptionY, textWidth);

        int separatorY = descriptionY + ModDescriptions.blockHeight(this.field_22793, description, textWidth) + 4;
        graphics.method_25294(textX, separatorY, textX + textWidth, separatorY + 1, ModPanelTheme.SEPARATOR);
    }

    protected void drawContentFrame(class_332 graphics, int x, int y, int width, int height) {
        graphics.method_25294(x, y, x + width, y + height, ModPanelTheme.BG);
        ModPanelTheme.drawBorder(graphics, x, y, width, height, ModPanelTheme.BORDER_MUTED);
    }

    @Override
    public void method_25420(class_332 graphics) {
        super.method_25420(graphics);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public void method_25419() {
        com.flowclient.mods.FlowModConfig.flushSave();
        super.method_25419();
    }
}

package com.flowclient.modpanel;

import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_342;

public final class ModPanelField extends class_342 {
    public static final int PAD_X = 6;
    public static final int PAD_Y = 4;

    private final int outerX;
    private final int outerY;
    private final int outerWidth;
    private final int outerHeight;

    public ModPanelField(class_327 font, int x, int y, int width, int height, class_2561 hint) {
        super(
                font,
                x + PAD_X,
                y + PAD_Y,
                width - PAD_X * 2,
                height - PAD_Y * 2,
                hint
        );
        this.outerX = x;
        this.outerY = y;
        this.outerWidth = width;
        this.outerHeight = height;
        this.method_1858(false);
        this.method_1868(ModPanelTheme.TEXT);
    }

    @Override
    public void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        ModPanelTheme.fillBordered(
                graphics,
                this.outerX,
                this.outerY,
                this.outerWidth,
                this.outerHeight,
                ModPanelTheme.BG_INPUT
        );
        super.method_48579(graphics, mouseX, mouseY, partialTick);
    }
}

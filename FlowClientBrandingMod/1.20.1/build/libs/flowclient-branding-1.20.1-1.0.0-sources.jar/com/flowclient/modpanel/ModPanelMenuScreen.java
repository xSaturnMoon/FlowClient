package com.flowclient.modpanel;

import net.minecraft.class_2561;

public final class ModPanelMenuScreen extends ModPanelScreen {
    private static final class_2561 TITLE = class_2561.method_43470("FlowClient");

    public ModPanelMenuScreen() {
        super(TITLE, null);
    }

    @Override
    protected void initPanel() {
        int x = this.centerX(BUTTON_WIDTH);
        int y = this.field_22790 / 2 - BUTTON_HEIGHT - 2;

        this.method_37063(new ModPanelButton(
                x,
                y,
                BUTTON_WIDTH,
                BUTTON_HEIGHT,
                class_2561.method_43470("Mods"),
                () -> this.field_22787.method_1507(new ModListPanelScreen(this)),
                false
        ));

        this.method_37063(new ModPanelButton(
                x,
                y + BUTTON_HEIGHT + 4,
                BUTTON_WIDTH,
                BUTTON_HEIGHT,
                class_2561.method_43470("Position"),
                () -> this.field_22787.method_1507(new ModPositionPanelScreen(this)),
                false
        ));
    }
}

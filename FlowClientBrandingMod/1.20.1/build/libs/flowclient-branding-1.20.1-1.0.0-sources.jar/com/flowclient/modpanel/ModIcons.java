package com.flowclient.modpanel;

import com.flowclient.compat.FlowGfx;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

public final class ModIcons {
    public static final class_2960 JEI = icon("jei");
    public static final class_2960 VOICE_CHAT = icon("voice_chat");
    public static final class_2960 FLOW_CLOCK = icon("flow_clock");
    public static final class_2960 FLOW_TAB = icon("flow_tab");
    public static final class_2960 OTHER_CLIENT = icon("other_client");

    private static final int ICON_SIZE = 16;

    private ModIcons() {
    }

    private static class_2960 icon(String name) {
        return new class_2960("flowclient", "textures/modicons/" + name);
    }

    public static void draw(class_332 graphics, ModEntry entry, int x, int y) {
        class_2960 customIcon = entry.customIcon();
        if (customIcon != null && hasTexture(customIcon)) {
            FlowGfx.blit(graphics, customIcon, x, y, ICON_SIZE, ICON_SIZE, 0.0F, 0.0F, 1.0F, 1.0F);
            return;
        }

        FlowGfx.item(graphics, new class_1799(entry.iconItem()), x, y, ICON_SIZE);
    }

    private static boolean hasTexture(class_2960 id) {
        return class_310.method_1551().method_1478().method_14486(id).isPresent();
    }
}

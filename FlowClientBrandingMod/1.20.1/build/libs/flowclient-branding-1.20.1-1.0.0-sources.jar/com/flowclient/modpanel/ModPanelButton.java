package com.flowclient.modpanel;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

public final class ModPanelButton extends class_339 {
    private final Runnable onPress;
    private final boolean alignLeft;

    public ModPanelButton(int x, int y, int width, int height, class_2561 message, Runnable onPress) {
        this(x, y, width, height, message, onPress, true);
    }

    public ModPanelButton(int x, int y, int width, int height, class_2561 message, Runnable onPress, boolean alignLeft) {
        super(x, y, width, height, message);
        this.onPress = onPress;
        this.alignLeft = alignLeft;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int fill = this.method_49606() ? ModPanelTheme.BG_HOVER : ModPanelTheme.BG_INPUT;
        ModPanelTheme.fillBordered(graphics, this.method_46426(), this.method_46427(), this.field_22758, this.field_22759, fill);

        class_327 font = class_310.method_1551().field_1772;
        int textX = this.alignLeft
                ? this.method_46426() + 6
                : this.method_46426() + (this.field_22758 - font.method_27525(this.method_25369())) / 2;
        int textY = this.method_46427() + (this.field_22759 - font.field_2000) / 2;
        com.flowclient.compat.FlowGfx.text(graphics, font, this.method_25369(), textX, textY, ModPanelTheme.TEXT);
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        method_25354(class_310.method_1551().method_1483());
        this.onPress.run();
    }

    @Override
    protected void method_47399(class_6382 narration) {
        narration.method_37034(net.minecraft.class_6381.field_33788, this.method_25369());
    }
}

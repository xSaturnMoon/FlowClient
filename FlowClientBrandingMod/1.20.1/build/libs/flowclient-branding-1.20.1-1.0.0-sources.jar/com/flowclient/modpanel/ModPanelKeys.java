package com.flowclient.modpanel;

import com.flowclient.FlowClientKeyCategories;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

public final class ModPanelKeys {
    public static final String OPEN_PANEL_KEY = "key.flowclient.mod_panel";
    private static final class_304 OPEN_PANEL = new class_304(
            OPEN_PANEL_KEY,
            class_3675.class_307.field_1668,
            class_3675.field_31955,
            FlowClientKeyCategories.FLOWCLIENT
    );

    private ModPanelKeys() {
    }

    public static void register() {
        KeyBindingHelper.registerKeyBinding(OPEN_PANEL);
    }

    public static void onRightShiftPressed() {
        class_310 client = class_310.method_1551();
        if (client == null || client.field_1687 == null) {
            return;
        }

        togglePanel(client);
    }

    private static void togglePanel(class_310 client) {
        class_437 current = client.field_1755;
        if (isModPanelScreen(current)) {
            client.method_1507(null);
            return;
        }

        if (current != null && current.method_25421()) {
            return;
        }

        client.method_1507(new ModPanelMenuScreen());
    }

    private static boolean isModPanelScreen(class_437 screen) {
        return screen instanceof ModPanelScreen;
    }

    public static boolean isOpenKey(int key, int action) {
        return action == GLFW.GLFW_PRESS && key == class_3675.field_31955;
    }
}

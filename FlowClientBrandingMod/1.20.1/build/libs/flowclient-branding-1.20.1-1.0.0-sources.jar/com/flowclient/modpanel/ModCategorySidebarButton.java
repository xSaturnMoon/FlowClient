package com.flowclient.modpanel;

import com.flowclient.compat.FlowGfx;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

public final class ModCategorySidebarButton extends class_339 {
    private final Runnable onPress;
    private boolean selected;
    private boolean dimmed;

    public ModCategorySidebarButton(int x, int y, int width, int height, class_2561 message, Runnable onPress) {
        super(x, y, width, height, message);
        this.onPress = onPress;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public void setDimmed(boolean dimmed) {
        this.dimmed = dimmed;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int x = this.method_46426();
        int y = this.method_46427();
        boolean hovered = this.method_49606() && !this.dimmed;

        int fill;
        if (this.selected && !this.dimmed) {
            fill = ModPanelTheme.ACCENT_BLUE;
        } else if (hovered) {
            fill = ModPanelTheme.BG_HOVER;
        } else {
            fill = ModPanelTheme.BG;
        }

        ModPanelTheme.fillBordered(graphics, x, y, this.field_22758, this.field_22759, fill);

        class_327 font = class_310.method_1551().field_1772;
        int textColor = this.dimmed
                ? ModPanelTheme.TEXT_DIM
                : (this.selected ? ModPanelTheme.KNOB : ModPanelTheme.TEXT);
        int textX = x + 6;
        int textY = y + (this.field_22759 - font.field_2000) / 2;
        FlowGfx.text(graphics, font, this.method_25369(), textX, textY, textColor);
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        if (!this.dimmed) {
            method_25354(class_310.method_1551().method_1483());
            this.onPress.run();
        }
    }

    @Override
    protected void method_47399(class_6382 output) {
        output.method_37034(net.minecraft.class_6381.field_33788, this.method_25369());
    }
}

package com.flowclient.modpanel;

import com.flowclient.compat.FlowGfx;

import com.flowclient.mods.FlowModConfig;
import com.flowclient.mods.armor.ArmorHudRenderer;
import com.flowclient.mods.fps.FpsCounterRenderer;
import com.flowclient.mods.blockspeed.BlockSpeedRenderer;
import com.flowclient.mods.blockbreak.BlockBreakProgressRenderer;
import com.flowclient.mods.armordurability.ArmorDurabilityAlertRenderer;
import com.flowclient.mods.cooldown.ItemCooldownHudRenderer;
import com.flowclient.mods.battery.BatteryHudRenderer;
import com.flowclient.mods.serveraddress.ServerAddressHudRenderer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import com.flowclient.mods.clock.FlowClockRenderer;
import com.flowclient.mods.media.MediaHudRenderer;
import com.flowclient.mods.hud.HudElement;
import com.flowclient.mods.hud.HudLayout;
import com.flowclient.mods.hud.HudLayoutManager;
import com.flowclient.mods.hud.HudScale;
import com.flowclient.mods.keystrokes.KeystrokesRenderer;

public final class HudModSettingsScreen extends ModPanelScreen {
    private final HudElement element;

    private ModPanelField xField;
    private ModPanelField yField;
    private ModPanelField scaleField;
    private boolean suppressResponder;

    public HudModSettingsScreen(class_437 parent, HudElement element) {
        super(class_2561.method_43470(element.getDisplayName() + " HUD"), parent, element.getDisplayName());
        this.element = element;
    }

    @Override
    protected String resolveModDescription() {
        return ModDescriptions.forHudElement(this.element);
    }

    @Override
    protected void method_25426() {
        this.initPanel();
    }

    @Override
    protected void initPanel() {
        int frameX = this.frameX();
        int frameY = this.frameY();
        int frameWidth = this.frameWidth();
        int fieldWidth = frameWidth - 24;
        int y = frameY + 12;

        this.method_37063(new ModPanelButton(
                frameX + 12,
                y,
                fieldWidth,
                BUTTON_HEIGHT,
                class_2561.method_43470("Reset Position"),
                () -> {
                    HudLayoutManager.get().resetPosition(this.element);
                    this.method_41843();
                }
        ));
        y += BUTTON_HEIGHT + 6;

        this.method_37063(new ModPanelButton(
                frameX + 12,
                y,
                fieldWidth,
                BUTTON_HEIGHT,
                class_2561.method_43470("Reset Size"),
                () -> {
                    HudLayoutManager.get().resetScale(this.element);
                    this.method_41843();
                }
        ));
        y += BUTTON_HEIGHT + 12;

        HudLayout layout = HudLayoutManager.get().layout(this.element);
        int width = this.elementWidth();
        int height = this.elementHeight();

        int currentX = layout.getRawX() == HudLayout.UNSET
                ? HudLayoutManager.get().resolveX(this.element, width, height)
                : layout.getRawX();
        int currentY = layout.getRawY() == HudLayout.UNSET
                ? HudLayoutManager.get().resolveY(this.element, width, height)
                : layout.getRawY();

        this.xField = this.addNumericField("Position X", frameX + 12, y, fieldWidth, String.valueOf(currentX));
        y += 28;
        this.yField = this.addNumericField("Position Y", frameX + 12, y, fieldWidth, String.valueOf(currentY));
        y += 28;
        this.scaleField = this.addDecimalField("Size", frameX + 12, y, fieldWidth, HudScale.format(layout.getScale()));
        y += 36;

        this.method_37063(new ModPanelButton(
                frameX + 12,
                y,
                fieldWidth,
                BUTTON_HEIGHT,
                class_2561.method_43470("Open Position Editor"),
                () -> this.field_22787.method_1507(new ModPositionPanelScreen(this))
        ));

        this.addBackButton();
    }

    private ModPanelField addNumericField(String label, int x, int y, int width, String value) {
        ModPanelField field = new ModPanelField(this.field_22793, x, y + 12, width, 18, class_2561.method_43470(label));
        field.method_1852(value);
        field.method_1863(text -> this.onFieldChanged());
        this.method_37063(field);
        return field;
    }

    private ModPanelField addDecimalField(String label, int x, int y, int width, String value) {
        ModPanelField field = new ModPanelField(this.field_22793, x, y + 12, width, 18, class_2561.method_43470(label));
        field.method_1852(value);
        field.method_1863(text -> this.onFieldChanged());
        this.method_37063(field);
        return field;
    }

    private void onFieldChanged() {
        if (this.suppressResponder) {
            return;
        }
        this.applyFields(false);
    }

    private void applyFields(boolean strict) {
        if (this.xField == null || this.yField == null || this.scaleField == null) {
            return;
        }

        try {
            String xText = this.xField.method_1882().trim();
            String yText = this.yField.method_1882().trim();
            String scaleText = this.scaleField.method_1882().trim();

            Integer x = tryParseInt(xText);
            Integer y = tryParseInt(yText);
            Float scale = HudScale.tryParse(scaleText);

            if (x != null && y != null) {
                HudLayoutManager.get().setPositionQuiet(this.element, x, y);
            }

            if (scale != null) {
                HudLayoutManager.get().setScaleQuiet(this.element, scale);
            } else if (strict) {
                this.suppressResponder = true;
                this.scaleField.method_1852(HudScale.format(HudLayoutManager.get().layout(this.element).getScale()));
                this.suppressResponder = false;
            }

            if (strict) {
                FlowModConfig.flushSave();
            }
        } catch (Exception ignored) {
            if (strict) {
                this.method_41843();
            }
        }
    }

    private static Integer tryParseInt(String text) {
        if (text == null || text.isEmpty()) {
            return null;
        }
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    @Override
    public void method_25419() {
        this.applyFields(true);
        super.method_25419();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        this.renderPreview(graphics);
        this.drawModDescription(graphics, this.frameX(), this.frameWidth());
        this.drawContentFrame(graphics, this.frameX(), this.frameY(), this.frameWidth(), this.frameHeight());

        int labelX = this.frameX() + 12;
        int y = this.frameY() + 12 + (BUTTON_HEIGHT + 6) * 2 + 12;
        FlowGfx.text(graphics, this.field_22793, "Position X", labelX, y, 0xFFCCCCCC, false);
        y += 28;
        FlowGfx.text(graphics, this.field_22793, "Position Y", labelX, y, 0xFFCCCCCC, false);
        y += 28;
        FlowGfx.text(graphics, this.field_22793, "Size", labelX, y, 0xFFCCCCCC, false);

        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    private void renderPreview(class_332 graphics) {
        switch (this.element) {
            case ARMOR_HUD -> ArmorHudRenderer.render(this.field_22787, graphics, this.field_22793, true);
            case KEYSTROKES -> KeystrokesRenderer.render(this.field_22787, graphics, this.field_22793, true);
            case FPS_COUNTER -> FpsCounterRenderer.render(this.field_22787, graphics, this.field_22793, true);
            case FLOW_CLOCK -> FlowClockRenderer.render(this.field_22787, graphics, this.field_22793, true);
            case BLOCK_SPEED -> BlockSpeedRenderer.render(this.field_22787, graphics, this.field_22793, true);
            case BLOCK_BREAK_PROGRESS -> BlockBreakProgressRenderer.render(this.field_22787, graphics, this.field_22793, true);
            case ARMOR_DURABILITY_ALERT -> ArmorDurabilityAlertRenderer.render(this.field_22787, graphics, this.field_22793, true);
            case ITEM_COOLDOWN_HUD -> ItemCooldownHudRenderer.render(this.field_22787, graphics, this.field_22793, true);
            case SERVER_ADDRESS_HUD -> ServerAddressHudRenderer.render(this.field_22787, graphics, this.field_22793, true);
            case BATTERY_HUD -> BatteryHudRenderer.render(this.field_22787, graphics, this.field_22793, true);
            case MEDIA_HUD -> MediaHudRenderer.render(this.field_22787, graphics, this.field_22793, true);
            case SCOREBOARD -> com.flowclient.mods.render.ScoreboardRenderer.render(this.field_22787, graphics, this.field_22793, true);
        }
    }

    @Override
    public void method_25420(class_332 graphics) {
        graphics.method_25294(0, 0, this.field_22789, this.field_22790, 0x88000000);
    }

    private int elementWidth() {
        return this.element.getWidth(this.field_22787, this.field_22793, true);
    }

    private int elementHeight() {
        return this.element.getHeight(this.field_22787, this.field_22793, true);
    }

    private int frameWidth() {
        return Math.min(this.field_22789 - 40, 280);
    }

    private int frameHeight() {
        return 250;
    }

    private int frameX() {
        return this.centerX(this.frameWidth());
    }

    private int frameY() {
        return this.contentFrameY(24, this.frameWidth());
    }
}

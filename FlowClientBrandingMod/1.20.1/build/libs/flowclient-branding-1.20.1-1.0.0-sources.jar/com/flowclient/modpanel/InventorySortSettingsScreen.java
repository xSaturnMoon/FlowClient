package com.flowclient.modpanel;

import com.flowclient.mods.inventory.InventorySortSettings;
import net.minecraft.class_2561;
import net.minecraft.class_437;

public final class InventorySortSettingsScreen extends ModSettingsPanelScreen<InventorySortSettings> {
    private static final class_2561 TITLE = class_2561.method_43470("Inventory Sort");

    public InventorySortSettingsScreen(class_437 parent) {
        super(TITLE, parent, "Inventory Sort");
    }

    @Override
    protected InventorySortSettings settings() {
        return InventorySortSettings.get();
    }

    @Override
    protected void persistSettings() {
        InventorySortSettings.get().persist();
    }

    @Override
    protected void buildSettingRows() {
        this.addHeader("Sorting");
        this.addRow("Include hotbar", s -> s.includeHotbar() ? "ON" : "OFF", s -> s.setIncludeHotbar(!s.includeHotbar()), s -> s.setIncludeHotbar(true));
        this.addRow("Merge stacks", s -> s.mergeStacks() ? "ON" : "OFF", s -> s.setMergeStacks(!s.mergeStacks()), s -> s.setMergeStacks(true));
        this.addHeader("Controls");
        this.addHeader("Press R while inventory is open");
    }
}

package com.flowclient.modpanel;

import net.minecraft.class_2561;

public enum ModCategory {
    VISUAL("Visual"),
    COMBAT("Combat"),
    HUD("HUD"),
    UTILITY("Utility"),
    WORLD("World"),
    MISC("Misc");

    private final String label;

    ModCategory(String label) {
        this.label = label;
    }

    public String label() {
        return this.label;
    }

    public class_2561 displayName() {
        return class_2561.method_43470(this.label);
    }
}

package com.flowclient.modpanel;

import com.flowclient.mods.blockbreak.BlockBreakProgressSettings;
import com.flowclient.mods.hud.HudElement;
import net.minecraft.class_2561;
import net.minecraft.class_437;

public final class BlockBreakProgressSettingsScreen extends ModSettingsPanelScreen<BlockBreakProgressSettings> {
    private static final class_2561 TITLE = class_2561.method_43470("Block Break Progress");

    public BlockBreakProgressSettingsScreen(class_437 parent) {
        super(TITLE, parent, "Block Break Progress");
    }

    @Override
    protected BlockBreakProgressSettings settings() {
        return BlockBreakProgressSettings.get();
    }

    @Override
    protected void persistSettings() {
        BlockBreakProgressSettings.get().persist();
    }

    @Override
    protected int extraRowsReserved() {
        return 1;
    }

    @Override
    protected void addExtraWidgets(int frameX, int frameY, int frameWidth, int visibleHeight, int startIndex) {
        this.addHudPositionButton(frameX, frameY, frameWidth, visibleHeight, startIndex, HudElement.BLOCK_BREAK_PROGRESS);
    }

    @Override
    protected void buildSettingRows() {
        this.addRow("Bar width", s -> s.barWidth() + "px", s -> s.cycleBarWidth(), BlockBreakProgressSettings::resetBarWidth);
        this.addRow("Show percentage", s -> bool(s.showPercentage()), s -> s.toggleShowPercentage(), BlockBreakProgressSettings::resetShowPercentage);
        this.addRow("Background", s -> bool(s.showBackground()), s -> s.toggleShowBackground(), BlockBreakProgressSettings::resetShowBackground);
        this.addRow("Background opacity", s -> s.backgroundOpacity() + "%", s -> s.cycleBackgroundOpacity(), BlockBreakProgressSettings::resetBackgroundOpacity);
    }

    private static String bool(boolean value) {
        return value ? "ON" : "OFF";
    }
}

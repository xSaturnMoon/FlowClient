package com.flowclient.modpanel;

import com.flowclient.compat.FlowGfx;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class ModListPanelScreen extends ModPanelScreen {
    private static final class_2561 TITLE = class_2561.method_43470("Mods");

    private static final int FRAME_WIDTH = 540;
    private static final int FRAME_HEIGHT = 380;
    private static final int PADDING = 8;
    private static final int SIDEBAR_WIDTH = 96;
    private static final int SEARCH_HEIGHT = 18;
    private static final int SEARCH_GAP = 6;
    private static final int SIDEBAR_BUTTON_HEIGHT = 22;
    private static final int SIDEBAR_GAP = 4;
    private static final int ICON_SIZE = 16;
    private static final int ICON_LEFT = 6;
    private static final int ICON_TEXT_GAP = 6;
    private static final int CONTROL_PADDING = 6;
    private static final int GEAR_SWITCH_GAP = 6;
    private static final int COLUMN_GAP = 6;

    private ModCategory selectedCategory = ModCategory.VISUAL;
    private String searchQuery = "";
    private int scrollOffset;
    private ModSearchField searchField;

    private ModEntryListWidget listWidget;
    private int switchX;
    private int gearX;

    public ModListPanelScreen(class_437 parent) {
        super(TITLE, parent);
    }

    @Override
    protected void method_41843() {
        boolean searchFocused = this.searchField != null && this.searchField.method_25370();
        int cursor = searchFocused ? this.searchField.method_1881() : 0;
        super.method_41843();
        if (searchFocused && this.searchField != null) {
            this.method_25395(this.searchField);
            this.searchField.method_1875(cursor);
        }
    }

    @Override
    protected void initPanel() {
        int frameX = this.frameX();
        int frameY = this.frameY();
        int innerX = frameX + PADDING;
        int innerY = frameY + PADDING;
        int innerWidth = FRAME_WIDTH - PADDING * 2;
        int searchBlockHeight = SEARCH_HEIGHT + SEARCH_GAP;

        this.searchField = new ModSearchField(this.field_22793, innerX, innerY, innerWidth, SEARCH_HEIGHT, class_2561.method_43470("Search"));
        this.searchField.method_1880(64);
        this.searchField.method_47404(class_2561.method_43470("Search flow mods..."));
        this.searchField.method_1852(this.searchQuery);
        this.searchField.method_1863(value -> {
            this.searchQuery = value;
            this.scrollOffset = 0;
            this.method_41843();
        });
        this.method_37063(this.searchField);

        this.listWidget = ModEntryListWidget.layout(
                this.field_22793,
                frameX,
                frameY,
                FRAME_WIDTH,
                FRAME_HEIGHT,
                PADDING,
                searchBlockHeight,
                SIDEBAR_WIDTH,
                COLUMN_GAP
        );

        int bodyTop = innerY + searchBlockHeight;
        this.switchX = this.listWidget.x() + this.listWidget.width() - CONTROL_PADDING - ToggleSwitchWidget.TRACK_WIDTH;
        this.gearX = this.switchX - GEAR_SWITCH_GAP - ModSettingsIconButton.SIZE;

        boolean searchActive = this.isSearchActive();
        int sidebarY = bodyTop;
        for (ModCategory category : ModCategory.values()) {
            ModCategorySidebarButton button = new ModCategorySidebarButton(
                    innerX,
                    sidebarY,
                    SIDEBAR_WIDTH,
                    SIDEBAR_BUTTON_HEIGHT,
                    category.displayName(),
                    () -> {
                        this.selectedCategory = category;
                        this.scrollOffset = 0;
                        this.method_41843();
                    }
            );
            button.setSelected(!searchActive && category == this.selectedCategory);
            button.setDimmed(searchActive);
            this.method_37063(button);
            sidebarY += SIDEBAR_BUTTON_HEIGHT + SIDEBAR_GAP;
        }

        List<ModEntry> visibleEntries = ModRegistry.visible(this.selectedCategory, this.searchQuery);
        this.scrollOffset = Math.max(0, Math.min(this.scrollOffset, this.listWidget.maxScroll(visibleEntries.size())));

        for (int index = 0; index < visibleEntries.size(); index++) {
            ModEntry entry = visibleEntries.get(index);
            int rowY = this.listWidget.rowY(index, this.scrollOffset);
            if (!this.listWidget.isRowVisible(rowY)) {
                continue;
            }

            if (entry.hasDedicatedSettingsScreen()) {
                this.method_37063(ModSettingsButtons.create(
                        this.gearX,
                        rowY + (ModEntryListWidget.ROW_HEIGHT - ModSettingsIconButton.SIZE) / 2,
                        () -> this.field_22787.method_1507(entry.openSettings(this))
                ));
            }

            this.method_37063(new ToggleSwitchWidget(
                    this.switchX,
                    rowY + (ModEntryListWidget.ROW_HEIGHT - ToggleSwitchWidget.TRACK_HEIGHT) / 2,
                    entry::isEnabled,
                    () -> {
                        entry.toggle();
                        this.method_41843();
                    }
            ));
        }

        this.addBackButton();
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollDelta) {
        if (this.listWidget != null && this.listWidget.contains(mouseX, mouseY)) {
            this.scrollOffset = (int) Math.max(0, this.scrollOffset - scrollDelta * ModEntryListWidget.ROW_HEIGHT);
            this.method_41843();
            return true;
        }
        return super.method_25401(mouseX, mouseY, scrollDelta);
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int frameX = this.frameX();
        int frameY = this.frameY();
        this.drawPanelFrame(graphics, frameX, frameY, FRAME_WIDTH, FRAME_HEIGHT);

        int innerX = frameX + PADDING;
        int bodyTop = frameY + PADDING + SEARCH_HEIGHT + SEARCH_GAP;
        int separatorX = innerX + SIDEBAR_WIDTH + 2;
        graphics.method_25294(separatorX, bodyTop, separatorX + 1, this.listWidget.bottom(), ModPanelTheme.SEPARATOR);

        List<ModEntry> visibleEntries = ModRegistry.visible(this.selectedCategory, this.searchQuery);
        class_327 font = class_310.method_1551().field_1772;
        boolean showCategoryBadge = this.isSearchActive();

        for (int index = 0; index < visibleEntries.size(); index++) {
            ModEntry entry = visibleEntries.get(index);
            int rowY = this.listWidget.rowY(index, this.scrollOffset);
            if (!this.listWidget.isRowVisible(rowY)) {
                continue;
            }

            boolean hovered = mouseX >= this.listWidget.x()
                    && mouseX <= this.listWidget.x() + this.listWidget.width()
                    && mouseY >= rowY
                    && mouseY <= rowY + ModEntryListWidget.ROW_HEIGHT;
            if (hovered) {
                graphics.method_25294(
                        this.listWidget.x(),
                        rowY,
                        this.listWidget.x() + this.listWidget.width(),
                        rowY + ModEntryListWidget.ROW_HEIGHT,
                        ModPanelTheme.BG_HOVER
                );
            }

            if (index > 0) {
                graphics.method_25294(this.listWidget.x(), rowY, this.listWidget.x() + this.listWidget.width(), rowY + 1, ModPanelTheme.SEPARATOR);
            }

            int iconY = rowY + (ModEntryListWidget.ROW_HEIGHT - ICON_SIZE) / 2;
            ModIcons.draw(graphics, entry, this.listWidget.x() + ICON_LEFT, iconY);

            int textX = this.listWidget.x() + ICON_LEFT + ICON_SIZE + ICON_TEXT_GAP;
            int textY = rowY + (ModEntryListWidget.ROW_HEIGHT - font.field_2000) / 2;
            FlowGfx.text(graphics, font, class_2561.method_43470(entry.displayName()), textX, textY, ModPanelTheme.TEXT);

            if (showCategoryBadge) {
                String badge = " · " + entry.category().label();
                int badgeX = textX + font.method_1727(entry.displayName());
                FlowGfx.text(graphics, font, badge, badgeX, textY, ModPanelTheme.TEXT_MUTED);
            }
        }

        graphics.method_25294(
                this.listWidget.x(),
                this.listWidget.footerSeparatorY(),
                this.listWidget.x() + this.listWidget.width(),
                this.listWidget.footerSeparatorY() + ModEntryListWidget.FOOTER_SEPARATOR,
                ModPanelTheme.SEPARATOR
        );
        this.drawFooter(graphics, visibleEntries);
        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    private void drawPanelFrame(class_332 graphics, int x, int y, int width, int height) {
        graphics.method_25294(x, y, x + width, y + height, ModPanelTheme.BG);
        ModPanelTheme.drawBorder(graphics, x, y, width, height, ModPanelTheme.BORDER_MUTED);
    }

    private void drawFooter(class_332 graphics, List<ModEntry> visibleEntries) {
        class_327 font = class_310.method_1551().field_1772;
        String footer;
        if (this.isSearchActive()) {
            long enabledCount = visibleEntries.stream().filter(ModEntry::isEnabled).count();
            footer = "Search · " + visibleEntries.size() + " mods · " + enabledCount + " on";
        } else {
            long enabledCount = visibleEntries.stream().filter(ModEntry::isEnabled).count();
            footer = this.selectedCategory.label() + " · " + visibleEntries.size() + " mods · " + enabledCount + " on";
        }
        FlowGfx.text(graphics, font, footer, this.listWidget.x(), this.listWidget.footerTextY(), ModPanelTheme.TEXT_MUTED);
    }

    private boolean isSearchActive() {
        return this.searchQuery != null && !this.searchQuery.isBlank();
    }

    private int frameX() {
        return this.centerX(FRAME_WIDTH);
    }

    private int frameY() {
        return 32;
    }
}

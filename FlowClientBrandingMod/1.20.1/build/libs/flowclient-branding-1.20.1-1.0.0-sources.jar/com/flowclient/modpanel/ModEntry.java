package com.flowclient.modpanel;

import org.jetbrains.annotations.Nullable;

import java.util.function.BooleanSupplier;
import java.util.function.Function;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_437;

public final class ModEntry {
    private final String id;
    private final String displayName;
    private final ModCategory category;
    private final int priority;
    private final class_1792 iconItem;
    @Nullable
    private final class_2960 customIcon;
    private final BooleanSupplier enabled;
    private final Runnable toggle;
    @Nullable
    private final Function<class_437, class_437> settingsScreenFactory;

    public ModEntry(
            String id,
            String displayName,
            ModCategory category,
            int priority,
            class_1792 iconItem,
            @Nullable class_2960 customIcon,
            BooleanSupplier enabled,
            Runnable toggle,
            @Nullable Function<class_437, class_437> settingsScreenFactory
    ) {
        this.id = id;
        this.displayName = displayName;
        this.category = category;
        this.priority = priority;
        this.iconItem = iconItem;
        this.customIcon = customIcon;
        this.enabled = enabled;
        this.toggle = toggle;
        this.settingsScreenFactory = settingsScreenFactory;
    }

    public String id() {
        return this.id;
    }

    public String displayName() {
        return this.displayName;
    }

    public ModCategory category() {
        return this.category;
    }

    public int priority() {
        return this.priority;
    }

    public class_1792 iconItem() {
        return this.iconItem;
    }

    @Nullable
    public class_2960 customIcon() {
        return this.customIcon;
    }

    public boolean isEnabled() {
        return this.enabled.getAsBoolean();
    }

    public void toggle() {
        this.toggle.run();
    }

    public class_437 openSettings(class_437 parent) {
        if (this.settingsScreenFactory != null) {
            return this.settingsScreenFactory.apply(parent);
        }
        return new ModSettingsPlaceholderScreen(parent, this.displayName);
    }

    public boolean hasDedicatedSettingsScreen() {
        return this.settingsScreenFactory != null;
    }
}

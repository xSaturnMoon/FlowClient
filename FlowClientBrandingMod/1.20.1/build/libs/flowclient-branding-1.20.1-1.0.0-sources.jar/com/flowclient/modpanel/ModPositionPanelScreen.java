package com.flowclient.modpanel;

import com.flowclient.compat.FlowGfx;

import com.flowclient.mods.hud.HudBounds;
import com.flowclient.mods.hud.HudEdgeGuides;
import com.flowclient.mods.hud.HudElement;
import com.flowclient.mods.hud.HudLayout;
import com.flowclient.mods.hud.HudLayoutManager;
import com.flowclient.mods.render.ScoreboardAnchor;
import com.flowclient.mods.render.ScoreboardSettings;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;

public final class ModPositionPanelScreen extends ModPanelScreen {
    private static final class_2561 TITLE = class_2561.method_43470("Position");

    private HudElement dragging;
    private int dragOffsetX;
    private int dragOffsetY;

    public ModPositionPanelScreen(class_437 parent) {
        super(TITLE, parent);
    }

    @Override
    protected void initPanel() {
        this.addBackButton();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        List<HudElement> enabled = HudElement.enabledElements();
        for (HudElement element : enabled) {
            element.renderPreview(this.field_22787, graphics, this.field_22793);
        }

        for (HudElement element : enabled) {
            HudBounds.Bounds bounds = HudBounds.get(element, this.field_22787, true);
            boolean hovered = bounds.contains(mouseX, mouseY);
            boolean selected = element == this.dragging;
            int color = selected ? 0xFF4A9EE0 : (hovered ? 0xCCFFFFFF : 0x88FFFFFF);

            graphics.method_25294(bounds.x(), bounds.y(), bounds.x() + bounds.width(), bounds.y() + 1, color);
            graphics.method_25294(bounds.x(), bounds.y() + bounds.height() - 1, bounds.x() + bounds.width(), bounds.y() + bounds.height(), color);
            graphics.method_25294(bounds.x(), bounds.y(), bounds.x() + 1, bounds.y() + bounds.height(), color);
            graphics.method_25294(bounds.x() + bounds.width() - 1, bounds.y(), bounds.x() + bounds.width(), bounds.y() + bounds.height(), color);

            FlowGfx.text(graphics, 
                    this.field_22793,
                    element.getDisplayName(),
                    bounds.x() + 4,
                    bounds.y() - 10,
                    0xFFFFFFFF,
                    true
            );
        }

        if (this.dragging != null) {
            this.drawEdgeGuides(graphics, HudBounds.get(this.dragging, this.field_22787, true));
        }

        String hint = enabled.isEmpty()
                ? "No active HUD mods. Enable mods from the mod list first."
                : "Drag HUD elements to reposition them.";
        FlowGfx.text(graphics, 
                this.field_22793,
                hint,
                this.centerX(this.field_22793.method_1727(hint)),
                12,
                0xFFDDDDDD,
                false
        );

        super.method_25394(graphics, mouseX, mouseY, partialTick);
    }

    private void drawEdgeGuides(class_332 graphics, HudBounds.Bounds bounds) {
        HudEdgeGuides.EdgeDistances distances = HudEdgeGuides.distances(bounds, this.field_22789, this.field_22790);
        int guideColor = 0xAA4A9EE0;
        int centerX = bounds.x() + bounds.width() / 2;
        int centerY = bounds.y() + bounds.height() / 2;

        this.drawDashedLine(graphics, bounds.x(), centerY, 0, centerY, guideColor);
        this.drawDashedLine(graphics, bounds.x() + bounds.width(), centerY, this.field_22789, centerY, guideColor);
        this.drawDashedLine(graphics, centerX, bounds.y(), centerX, 0, guideColor);
        this.drawDashedLine(graphics, centerX, bounds.y() + bounds.height(), centerX, this.field_22790, guideColor);

        this.drawEdgeLabel(graphics, "L " + distances.left() + "px", bounds.x() / 2 - 16, centerY - 4, distances.left());
        this.drawEdgeLabel(graphics, "R " + distances.right() + "px", bounds.x() + bounds.width() + (this.field_22789 - bounds.x() - bounds.width()) / 2 - 16, centerY - 4, distances.right());
        this.drawEdgeLabel(graphics, "T " + distances.top() + "px", centerX - 16, bounds.y() / 2 - 4, distances.top());
        this.drawEdgeLabel(graphics, "B " + distances.bottom() + "px", centerX - 16, bounds.y() + bounds.height() + (this.field_22790 - bounds.y() - bounds.height()) / 2 - 4, distances.bottom());

        String nearestText = distances.nearest() + "px from " + distances.nearestEdgeName();
        int labelWidth = this.field_22793.method_1727(nearestText);
        int labelX = bounds.x() + (bounds.width() - labelWidth) / 2;
        int labelY = bounds.y() + bounds.height() + 6;
        graphics.method_25294(labelX - 4, labelY - 2, labelX + labelWidth + 4, labelY + 10, 0xCC101018);
        FlowGfx.text(graphics, this.field_22793, nearestText, labelX, labelY, 0xFF4A9EE0, false);
    }

    private void drawEdgeLabel(class_332 graphics, String text, int x, int y, int distance) {
        int color = distance == HudEdgeGuides.distances(
                HudBounds.get(this.dragging, this.field_22787, true),
                this.field_22789,
                this.field_22790
        ).nearest() ? 0xFF4A9EE0 : 0xFFCCCCCC;
        FlowGfx.text(graphics, this.field_22793, text, x, y, color, true);
    }

    private void drawDashedLine(class_332 graphics, int x1, int y1, int x2, int y2, int color) {
        if (x1 == x2) {
            int minY = Math.min(y1, y2);
            int maxY = Math.max(y1, y2);
            for (int y = minY; y < maxY; y += 4) {
                graphics.method_25294(x1, y, x1 + 1, Math.min(y + 2, maxY), color);
            }
            return;
        }

        int minX = Math.min(x1, x2);
        int maxX = Math.max(x1, x2);
        for (int x = minX; x < maxX; x += 4) {
            graphics.method_25294(x, y1, Math.min(x + 2, maxX), y1 + 1, color);
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (HudElement element : HudElement.enabledElements()) {
                HudBounds.Bounds bounds = HudBounds.get(element, this.field_22787, true);
                if (bounds.contains((int) mouseX, (int) mouseY)) {
                    this.dragging = element;
                    this.dragOffsetX = (int) mouseX - bounds.x();
                    this.dragOffsetY = (int) mouseY - bounds.y();
                    return true;
                }
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (button == 0 && this.dragging != null) {
            int newY = (int) mouseY - this.dragOffsetY;
            if (this.dragging == HudElement.SCOREBOARD && ScoreboardSettings.get().anchor() != ScoreboardAnchor.CUSTOM) {
                HudLayoutManager.get().setPositionQuiet(this.dragging, HudLayout.UNSET, newY);
            } else {
                HudLayoutManager.get().setPositionQuiet(
                        this.dragging,
                        (int) mouseX - this.dragOffsetX,
                        newY
                );
            }
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        if (button == 0 && this.dragging != null) {
            HudElement released = this.dragging;
            this.dragging = null;
            HudLayoutManager.get().flushPosition(released);
            return true;
        }
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public void method_25420(class_332 graphics) {
        graphics.method_25294(0, 0, this.field_22789, this.field_22790, 0x88000000);
    }
}

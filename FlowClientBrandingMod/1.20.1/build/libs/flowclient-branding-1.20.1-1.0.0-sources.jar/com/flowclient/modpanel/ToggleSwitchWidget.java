package com.flowclient.modpanel;

import java.util.function.BooleanSupplier;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

public final class ToggleSwitchWidget extends class_339 {
    public static final int TRACK_WIDTH = 28;
    public static final int TRACK_HEIGHT = 14;

    private static final int KNOB_SIZE = 10;
    private static final int KNOB_INSET = 2;

    private final BooleanSupplier enabled;
    private final Runnable onToggle;

    public ToggleSwitchWidget(int x, int y, BooleanSupplier enabled, Runnable onToggle) {
        super(x, y, TRACK_WIDTH, TRACK_HEIGHT, class_2561.method_43473());
        this.enabled = enabled;
        this.onToggle = onToggle;
    }

    @Override
    protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        int x = this.method_46426();
        int y = this.method_46427();
        boolean on = this.enabled.getAsBoolean();

        ModPanelTheme.fillBordered(
                graphics,
                x,
                y,
                this.field_22758,
                this.field_22759,
                on ? ModPanelTheme.ACCENT_GREEN : ModPanelTheme.TRACK_OFF
        );

        int knobY = y + KNOB_INSET;
        int knobX = on
                ? x + this.field_22758 - KNOB_INSET - KNOB_SIZE
                : x + KNOB_INSET;
        graphics.method_25294(knobX, knobY, knobX + KNOB_SIZE, knobY + KNOB_SIZE, ModPanelTheme.KNOB);
    }

    @Override
    public void method_25348(double mouseX, double mouseY) {
        method_25354(class_310.method_1551().method_1483());
        this.onToggle.run();
    }

    @Override
    protected void method_47399(class_6382 narration) {
        narration.method_37034(
                net.minecraft.class_6381.field_33788,
                class_2561.method_43470(this.enabled.getAsBoolean() ? "On" : "Off")
        );
    }
}

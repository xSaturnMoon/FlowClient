package com.flowclient.mixin;

import com.flowclient.mods.render.BlockOverlayMod;
import com.flowclient.mods.render.BlockOverlayRenderer;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelRenderer.class)
public abstract class LevelRendererMixin {
    @Inject(method = "renderHitOutline", at = @At("HEAD"), cancellable = true)
    private void flowclient$customBlockOutline(
            PoseStack poseStack,
            VertexConsumer consumer,
            Entity entity,
            double camX,
            double camY,
            double camZ,
            BlockPos pos,
            BlockState state,
            CallbackInfo ci
    ) {
        if (!BlockOverlayMod.isEnabled()) {
            return;
        }

        ci.cancel();
        BlockOverlayRenderer.render(poseStack, consumer, camX, camY, camZ, pos, state);
    }
}
